
#include <AK/Function.h>
#include <LibIDL/Types.h>
#include <LibJS/Runtime/Array.h>
#include <LibJS/Runtime/ArrayBuffer.h>
#include <LibJS/Runtime/DataView.h>
#include <LibJS/Runtime/Error.h>
#include <LibJS/Runtime/FunctionObject.h>
#include <LibJS/Runtime/GlobalObject.h>
#include <LibJS/Runtime/Iterator.h>
#include <LibJS/Runtime/PromiseConstructor.h>
#include <LibJS/Runtime/TypedArray.h>
#include <LibJS/Runtime/Value.h>
#include <LibJS/Runtime/ValueInlines.h>
#include <LibURL/Origin.h>
#include <LibWeb/Bindings/NavigatorPrototype.h>
#include <LibWeb/Bindings/ExceptionOrUtils.h>
#include <LibWeb/Bindings/Intrinsics.h>
#include <LibWeb/DOM/Element.h>
#include <LibWeb/DOM/Event.h>
#include <LibWeb/DOM/IDLEventListener.h>
#include <LibWeb/DOM/NodeFilter.h>
#include <LibWeb/DOM/Range.h>
#include <LibWeb/HTML/Numbers.h>
#include <LibWeb/HTML/Scripting/Agent.h>
#include <LibWeb/HTML/Scripting/Environments.h>
#include <LibWeb/HTML/Window.h>
#include <LibWeb/HTML/WindowProxy.h>
#include <LibWeb/Infra/Strings.h>
#include <LibWeb/WebIDL/AbstractOperations.h>
#include <LibWeb/WebIDL/Buffers.h>
#include <LibWeb/WebIDL/OverloadResolution.h>
#include <LibWeb/WebIDL/Promise.h>
#include <LibWeb/WebIDL/Tracing.h>
#include <LibWeb/WebIDL/Types.h>

#if __has_include(<LibWeb/Bindings/ObjectPrototype.h>)
#    include <LibWeb/Bindings/ObjectPrototype.h>
#endif


#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Navigator.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Clipboard/Clipboard.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CredentialManagement/CredentialsContainer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/MimeTypeArray.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/PluginArray.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/UserActivation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/MediaCapabilitiesAPI/MediaCapabilities.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/ServiceWorker/ServiceWorkerContainer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/EventTarget.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CredentialManagement/Credential.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CredentialManagement/FederatedCredential.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CredentialManagement/PasswordCredential.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/MimeType.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Plugin.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/EncryptedMediaExtensions/EncryptedMediaExtensions.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Worker.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/ServiceWorker/ServiceWorkerRegistration.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/StorageAPI/StorageManager.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/AbortSignal.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/FileAPI/Blob.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/ReadableStream.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOMURL/URLSearchParams.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/XHR/FormData.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Event.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/MessagePort.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Fetch/Request.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/ServiceWorker/ServiceWorker.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/ReadableStreamBYOBReader.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/ReadableStreamDefaultReader.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/WritableStream.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/FileAPI/File.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Fetch/Headers.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/WritableStreamDefaultWriter.h>

// FIXME: This is a total hack until we can figure out the namespace for a given type somehow.
using namespace Web::Animations;
using namespace Web::Clipboard;
using namespace Web::CredentialManagement;
using namespace Web::Crypto;
using namespace Web::CSS;
using namespace Web::DOM;
using namespace Web::DOMURL;
using namespace Web::Encoding;
using namespace Web::EntriesAPI;
using namespace Web::EventTiming;
using namespace Web::Fetch;
using namespace Web::FileAPI;
using namespace Web::Geometry;
using namespace Web::HighResolutionTime;
using namespace Web::HTML;
using namespace Web::IndexedDB;
using namespace Web::Internals;
using namespace Web::IntersectionObserver;
using namespace Web::MediaCapabilitiesAPI;
using namespace Web::MediaSourceExtensions;
using namespace Web::NavigationTiming;
using namespace Web::PerformanceTimeline;
using namespace Web::RequestIdleCallback;
using namespace Web::ResizeObserver;
using namespace Web::Selection;
using namespace Web::ServiceWorker;
using namespace Web::StorageAPI;
using namespace Web::Streams;
using namespace Web::SVG;
using namespace Web::UIEvents;
using namespace Web::URLPattern;
using namespace Web::UserTiming;
using namespace Web::WebAssembly;
using namespace Web::WebAudio;
using namespace Web::WebGL;
using namespace Web::WebGL::Extensions;
using namespace Web::WebIDL;
using namespace Web::WebVTT;
using namespace Web::XHR;

namespace Web::Bindings {

GC_DEFINE_ALLOCATOR(NavigatorPrototype);

NavigatorPrototype::NavigatorPrototype([[maybe_unused]] JS::Realm& realm)
    : Object(ConstructWithPrototypeTag::Tag, realm.intrinsics().object_prototype())

{
}

NavigatorPrototype::~NavigatorPrototype()
{
}

void NavigatorPrototype::initialize(JS::Realm& realm)
{


    [[maybe_unused]] auto& vm = realm.vm();
    [[maybe_unused]] u8 default_attributes = JS::Attribute::Enumerable | JS::Attribute::Configurable | JS::Attribute::Writable;



    set_prototype(realm.intrinsics().object_prototype());


    define_native_accessor(realm, "clipboard", clipboard_getter, nullptr, default_attributes);

    define_native_accessor(realm, "maxTouchPoints", max_touch_points_getter, nullptr, default_attributes);

    define_native_accessor(realm, "userActivation", user_activation_getter, nullptr, default_attributes);

    define_native_accessor(realm, "doNotTrack", do_not_track_getter, nullptr, default_attributes);

    define_native_accessor(realm, "serviceWorker", service_worker_getter, nullptr, default_attributes);

    define_native_accessor(realm, "mediaCapabilities", media_capabilities_getter, nullptr, default_attributes);

    define_native_accessor(realm, "credentials", credentials_getter, nullptr, default_attributes);

    define_native_accessor(realm, "appCodeName", app_code_name_getter, nullptr, default_attributes);

    define_native_accessor(realm, "appName", app_name_getter, nullptr, default_attributes);

    define_native_accessor(realm, "appVersion", app_version_getter, nullptr, default_attributes);

    define_native_accessor(realm, "platform", platform_getter, nullptr, default_attributes);

    define_native_accessor(realm, "product", product_getter, nullptr, default_attributes);

    define_native_accessor(realm, "productSub", product_sub_getter, nullptr, default_attributes);

    define_native_accessor(realm, "userAgent", user_agent_getter, nullptr, default_attributes);

    define_native_accessor(realm, "vendor", vendor_getter, nullptr, default_attributes);

    define_native_accessor(realm, "vendorSub", vendor_sub_getter, nullptr, default_attributes);

    define_native_accessor(realm, "plugins", plugins_getter, nullptr, default_attributes);

    define_native_accessor(realm, "mimeTypes", mime_types_getter, nullptr, default_attributes);

    define_native_accessor(realm, "pdfViewerEnabled", pdf_viewer_enabled_getter, nullptr, default_attributes);

    define_native_accessor(realm, "webdriver", webdriver_getter, nullptr, default_attributes);

    define_native_accessor(realm, "cookieEnabled", cookie_enabled_getter, nullptr, default_attributes);

    define_native_accessor(realm, "onLine", on_line_getter, nullptr, default_attributes);

    define_native_accessor(realm, "storage", storage_getter, nullptr, default_attributes);

    define_native_accessor(realm, "language", language_getter, nullptr, default_attributes);

    define_native_accessor(realm, "languages", languages_getter, nullptr, default_attributes);

    define_native_accessor(realm, "hardwareConcurrency", hardware_concurrency_getter, nullptr, default_attributes);

    define_native_accessor(realm, "deviceMemory", device_memory_getter, nullptr, default_attributes);

        define_direct_property("registerProtocolHandler", JS::js_undefined(), default_attributes | JS::Attribute::Unimplemented);
            
        define_direct_property("unregisterProtocolHandler", JS::js_undefined(), default_attributes | JS::Attribute::Unimplemented);
            
    define_native_function(realm, "javaEnabled", java_enabled, 0, default_attributes);

    define_native_function(realm, "sendBeacon", send_beacon, 1, default_attributes);

    define_direct_property(vm.well_known_symbol_to_string_tag(), JS::PrimitiveString::create(vm, "Navigator"_string), JS::Attribute::Configurable);

    Base::initialize(realm);

}

[[maybe_unused]] static JS::ThrowCompletionOr<HTML::Navigator*> impl_from(JS::VM& vm)
{
    auto this_value = vm.this_value();
    JS::Object* this_object = nullptr;
    if (this_value.is_nullish())
        this_object = &vm.current_realm()->global_object();
    else
        this_object = TRY(this_value.to_object(vm));

    if (!is<HTML::Navigator>(this_object))
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "Navigator");
    return static_cast<HTML::Navigator*>(this_object);
}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::clipboard_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::clipboard_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->clipboard(); }));

    return &const_cast<Clipboard::Clipboard&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::max_touch_points_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::max_touch_points_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->max_touch_points(); }));

    return JS::Value(static_cast<WebIDL::Long>(retval));

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::user_activation_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::user_activation_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->user_activation(); }));

    return &const_cast<UserActivation&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::do_not_track_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::do_not_track_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->do_not_track(); }));

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::service_worker_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::service_worker_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->service_worker(); }));

    return &const_cast<ServiceWorkerContainer&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::media_capabilities_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::media_capabilities_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->media_capabilities(); }));

    return &const_cast<MediaCapabilities&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::credentials_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::credentials_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->credentials(); }));

    return &const_cast<CredentialsContainer&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::app_code_name_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::app_code_name_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->app_code_name(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::app_name_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::app_name_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->app_name(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::app_version_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::app_version_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->app_version(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::platform_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::platform_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->platform(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::product_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::product_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->product(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::product_sub_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::product_sub_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->product_sub(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::user_agent_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::user_agent_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->user_agent(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::vendor_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::vendor_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->vendor(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::vendor_sub_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::vendor_sub_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->vendor_sub(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::plugins_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::plugins_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->plugins(); }));

    return &const_cast<PluginArray&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::mime_types_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::mime_types_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->mime_types(); }));

    return &const_cast<MimeTypeArray&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::pdf_viewer_enabled_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::pdf_viewer_enabled_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->pdf_viewer_enabled(); }));

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::webdriver_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::webdriver_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->webdriver(); }));

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::cookie_enabled_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::cookie_enabled_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->cookie_enabled(); }));

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::on_line_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::on_line_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->on_line(); }));

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::storage_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::storage_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->storage(); }));

    return &const_cast<StorageManager&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::language_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::language_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->language(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::languages_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::languages_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->languages(); }));

    auto new_array0 = MUST(JS::Array::create(realm, 0));

    for (size_t i0 = 0; i0 < retval.size(); ++i0) {
        auto& element0 = retval.at(i0);

    auto wrapped_element0 = JS::PrimitiveString::create(vm, element0);

        auto property_index0 = JS::PropertyKey { i0 };
        MUST(new_array0->create_data_property(property_index0, wrapped_element0));
    }

    return new_array0;

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::hardware_concurrency_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::hardware_concurrency_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->hardware_concurrency(); }));

    return JS::Value(static_cast<double>(retval));

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::device_memory_getter)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::device_memory_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->device_memory(); }));

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::java_enabled)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::java_enabled");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->java_enabled(); }));

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(NavigatorPrototype::send_beacon)
{
    WebIDL::log_trace(vm, "NavigatorPrototype::send_beacon");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "sendBeacon");

    auto arg0 = vm.argument(0);

    String url;
    if (!false || !arg0.is_null()) {
        url = TRY(WebIDL::to_usv_string(vm, arg0));
    }

    auto arg1 = vm.argument(1);

    auto arg1_to_variant = [&vm, &realm](JS::Value arg1) -> JS::ThrowCompletionOr<Variant<GC::Root<ReadableStream>, GC::Root<Blob>, GC::Root<WebIDL::BufferSource>, GC::Root<FormData>, GC::Root<URLSearchParams>, String>> {
        // These might be unused.
        (void)vm;
        (void)realm;

        if (arg1.is_object()) {
            [[maybe_unused]] auto& arg1_object = arg1.as_object();

            if (is<PlatformObject>(arg1_object)) {

                if (is<ReadableStream>(arg1_object))
                    return GC::make_root(static_cast<ReadableStream&>(arg1_object));

                if (is<Blob>(arg1_object))
                    return GC::make_root(static_cast<Blob&>(arg1_object));

                if (is<FormData>(arg1_object))
                    return GC::make_root(static_cast<FormData&>(arg1_object));

                if (is<URLSearchParams>(arg1_object))
                    return GC::make_root(static_cast<URLSearchParams&>(arg1_object));

            }

            if (is<JS::ArrayBuffer>(arg1_object) || is<JS::DataView>(arg1_object) || is<JS::TypedArrayBase>(arg1_object)) {
                GC::Ref<WebIDL::BufferSource> source_object = realm.create<WebIDL::BufferSource>(arg1_object);
                return GC::make_root(source_object);
            }

        }

    String arg1_string;
    if (!false || !arg1.is_null()) {
        arg1_string = TRY(WebIDL::to_usv_string(vm, arg1));
    }

        return { arg1_string };

    };

    Optional<Variant<GC::Root<ReadableStream>, GC::Root<Blob>, GC::Root<WebIDL::BufferSource>, GC::Root<FormData>, GC::Root<URLSearchParams>, String>> data;
    if (!arg1.is_nullish())
        data = TRY(arg1_to_variant(arg1));

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->send_beacon(url, data); }));

    return JS::Value(retval);

}

} // namespace Web::Bindings
