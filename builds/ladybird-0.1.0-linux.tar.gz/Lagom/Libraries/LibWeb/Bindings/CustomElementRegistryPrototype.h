
#pragma once

#include <LibJS/Runtime/Object.h>

namespace Web::Bindings {

class CustomElementRegistryPrototype : public JS::Object {
    JS_OBJECT(CustomElementRegistryPrototype, JS::Object);
    GC_DECLARE_ALLOCATOR(CustomElementRegistryPrototype);
public:
    explicit CustomElementRegistryPrototype(JS::Realm&);
    virtual void initialize(JS::Realm&) override;
    virtual ~CustomElementRegistryPrototype() override;
private:

    JS_DECLARE_NATIVE_FUNCTION(get_name);
        
    JS_DECLARE_NATIVE_FUNCTION(get);
        
    JS_DECLARE_NATIVE_FUNCTION(when_defined);
        
    JS_DECLARE_NATIVE_FUNCTION(upgrade);
        
    JS_DECLARE_NATIVE_FUNCTION(define);
        

};


} // namespace Web::Bindings
    