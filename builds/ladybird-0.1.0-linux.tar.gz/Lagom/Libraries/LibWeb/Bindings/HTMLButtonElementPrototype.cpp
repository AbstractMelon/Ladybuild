
#include <AK/Function.h>
#include <LibIDL/Types.h>
#include <LibJS/Runtime/Array.h>
#include <LibJS/Runtime/ArrayBuffer.h>
#include <LibJS/Runtime/DataView.h>
#include <LibJS/Runtime/Error.h>
#include <LibJS/Runtime/FunctionObject.h>
#include <LibJS/Runtime/GlobalObject.h>
#include <LibJS/Runtime/Iterator.h>
#include <LibJS/Runtime/PromiseConstructor.h>
#include <LibJS/Runtime/TypedArray.h>
#include <LibJS/Runtime/Value.h>
#include <LibJS/Runtime/ValueInlines.h>
#include <LibURL/Origin.h>
#include <LibWeb/Bindings/HTMLButtonElementPrototype.h>
#include <LibWeb/Bindings/ExceptionOrUtils.h>
#include <LibWeb/Bindings/Intrinsics.h>
#include <LibWeb/DOM/Element.h>
#include <LibWeb/DOM/Event.h>
#include <LibWeb/DOM/IDLEventListener.h>
#include <LibWeb/DOM/NodeFilter.h>
#include <LibWeb/DOM/Range.h>
#include <LibWeb/HTML/Numbers.h>
#include <LibWeb/HTML/Scripting/Agent.h>
#include <LibWeb/HTML/Scripting/Environments.h>
#include <LibWeb/HTML/Window.h>
#include <LibWeb/HTML/WindowProxy.h>
#include <LibWeb/Infra/Strings.h>
#include <LibWeb/WebIDL/AbstractOperations.h>
#include <LibWeb/WebIDL/Buffers.h>
#include <LibWeb/WebIDL/OverloadResolution.h>
#include <LibWeb/WebIDL/Promise.h>
#include <LibWeb/WebIDL/Tracing.h>
#include <LibWeb/WebIDL/Types.h>

#if __has_include(<LibWeb/Bindings/HTMLElementPrototype.h>)
#    include <LibWeb/Bindings/HTMLElementPrototype.h>
#endif


#include <LibWeb/Bindings/MainThreadVM.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLButtonElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLFormElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/PopoverInvokerElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/ValidityState.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/DOMStringMap.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/ElementInternals.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Element.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLFormControlsCollection.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/CSSStyleDeclaration.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/ShadowRoot.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Attr.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/DOMTokenList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/NamedNodeMap.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Node.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/NodeList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMRect.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMRectList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLSlotElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Window.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Event.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/HTMLCollection.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/RadioNodeList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/DocumentFragment.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Animations/Animation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Animations/KeyframeEffect.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Document.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/EventTarget.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMRectReadOnly.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Text.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/MediaQueryList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/Screen.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/VisualViewport.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/CustomElements/CustomElementRegistry.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/History.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Navigation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Navigator.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/StyleSheetList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Animations/AnimationEffect.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Animations/AnimationTimeline.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Animations/DocumentTimeline.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/FontFaceSet.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/CDATASection.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Comment.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/DOMImplementation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/DocumentType.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/NodeFilter.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/NodeIterator.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/ProcessingInstruction.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Range.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/TreeWalker.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLAllCollection.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLHeadElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLScriptElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Location.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Selection/Selection.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/AbortSignal.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/CharacterData.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/ScreenOrientation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/NavigationHistoryEntry.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/NavigationTransition.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Clipboard/Clipboard.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CredentialManagement/CredentialsContainer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/MimeTypeArray.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/PluginArray.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/UserActivation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/MediaCapabilitiesAPI/MediaCapabilities.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/ServiceWorker/ServiceWorkerContainer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/MessagePort.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Storage.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Crypto/Crypto.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Fetch/Request.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Fetch/Response.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HighResolutionTime/Performance.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/ImageBitmap.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/IndexedDB/IDBFactory.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/RequestIdleCallback/IdleDeadline.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/CSSStyleSheet.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/FontFace.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/XMLDocument.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/AbstractRange.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Scripting/Fetching.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/NavigationType.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CredentialManagement/Credential.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CredentialManagement/FederatedCredential.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CredentialManagement/PasswordCredential.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/MimeType.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Plugin.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/EncryptedMediaExtensions/EncryptedMediaExtensions.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Worker.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/ServiceWorker/ServiceWorkerRegistration.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/StorageAPI/StorageManager.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Crypto/SubtleCrypto.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Fetch/Headers.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/NavigationTiming/PerformanceNavigation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/NavigationTiming/PerformanceTiming.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/PerformanceTimeline/PerformanceEntry.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/UserTiming/PerformanceMark.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/UserTiming/PerformanceMeasure.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/FileAPI/Blob.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/ImageData.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/CanvasRenderingContext2D.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/CSSRule.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/CSSRuleList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/MediaList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/StyleSheet.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/ReadableStream.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOMURL/URLSearchParams.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/XHR/FormData.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/ServiceWorker/ServiceWorker.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Crypto/CryptoKey.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLCanvasElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Canvas/CanvasDrawPath.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Canvas/CanvasTextDrawingStyles.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLImageElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLVideoElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGImageElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/ReadableStreamBYOBReader.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/ReadableStreamDefaultReader.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/WritableStream.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/FileAPI/File.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLRenderingContext.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGL2RenderingContext.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Path2D.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/CanvasGradient.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/CanvasPattern.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMPointReadOnly.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/TextMetrics.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMMatrix.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLMediaElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGGraphicsElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/WritableStreamDefaultWriter.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMMatrixReadOnly.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMPoint.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/AudioTrackList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/MediaError.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/TextTrack.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/TextTrackList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/TimeRanges.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/VideoTrackList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGAnimatedString.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLActiveInfo.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLBuffer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLFramebuffer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLObject.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLProgram.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLRenderbuffer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLShader.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLShaderPrecisionFormat.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLTexture.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLUniformLocation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLQuery.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLSampler.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLSync.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLTransformFeedback.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLVertexArrayObject.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/AudioTrack.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/VideoTrack.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGSVGElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGAnimatedRect.h>

// FIXME: This is a total hack until we can figure out the namespace for a given type somehow.
using namespace Web::Animations;
using namespace Web::Clipboard;
using namespace Web::CredentialManagement;
using namespace Web::Crypto;
using namespace Web::CSS;
using namespace Web::DOM;
using namespace Web::DOMURL;
using namespace Web::Encoding;
using namespace Web::EntriesAPI;
using namespace Web::EventTiming;
using namespace Web::Fetch;
using namespace Web::FileAPI;
using namespace Web::Geometry;
using namespace Web::HighResolutionTime;
using namespace Web::HTML;
using namespace Web::IndexedDB;
using namespace Web::Internals;
using namespace Web::IntersectionObserver;
using namespace Web::MediaCapabilitiesAPI;
using namespace Web::MediaSourceExtensions;
using namespace Web::NavigationTiming;
using namespace Web::PerformanceTimeline;
using namespace Web::RequestIdleCallback;
using namespace Web::ResizeObserver;
using namespace Web::Selection;
using namespace Web::ServiceWorker;
using namespace Web::StorageAPI;
using namespace Web::Streams;
using namespace Web::SVG;
using namespace Web::UIEvents;
using namespace Web::URLPattern;
using namespace Web::UserTiming;
using namespace Web::WebAssembly;
using namespace Web::WebAudio;
using namespace Web::WebGL;
using namespace Web::WebGL::Extensions;
using namespace Web::WebIDL;
using namespace Web::WebVTT;
using namespace Web::XHR;

namespace Web::Bindings {

GC_DEFINE_ALLOCATOR(HTMLButtonElementPrototype);

HTMLButtonElementPrototype::HTMLButtonElementPrototype([[maybe_unused]] JS::Realm& realm)
    : Object(realm, nullptr)

{
}

HTMLButtonElementPrototype::~HTMLButtonElementPrototype()
{
}

void HTMLButtonElementPrototype::initialize(JS::Realm& realm)
{


    [[maybe_unused]] auto& vm = realm.vm();
    [[maybe_unused]] u8 default_attributes = JS::Attribute::Enumerable | JS::Attribute::Configurable | JS::Attribute::Writable;



    set_prototype(&ensure_web_prototype<HTMLElementPrototype>(realm, "HTMLElement"_fly_string));


    define_native_accessor(realm, "disabled", disabled_getter, disabled_setter, default_attributes);

    define_native_accessor(realm, "form", form_getter, nullptr, default_attributes);

    define_native_accessor(realm, "formAction", form_action_getter, form_action_setter, default_attributes);

    define_native_accessor(realm, "formEnctype", form_enctype_getter, form_enctype_setter, default_attributes);

    define_native_accessor(realm, "formMethod", form_method_getter, form_method_setter, default_attributes);

    define_native_accessor(realm, "formNoValidate", form_no_validate_getter, form_no_validate_setter, default_attributes);

    define_native_accessor(realm, "formTarget", form_target_getter, form_target_setter, default_attributes);

    define_native_accessor(realm, "name", name_getter, name_setter, default_attributes);

    define_native_accessor(realm, "type", type_getter, type_setter, default_attributes);

    define_native_accessor(realm, "value", value_getter, value_setter, default_attributes);

    define_native_accessor(realm, "willValidate", will_validate_getter, nullptr, default_attributes);

    define_native_accessor(realm, "validity", validity_getter, nullptr, default_attributes);

    define_direct_property("validationMessage", JS::js_undefined(), default_attributes | JS::Attribute::Unimplemented);
            
    define_native_accessor(realm, "labels", labels_getter, nullptr, default_attributes);

    define_native_accessor(realm, "popoverTargetElement", popover_target_element_getter, popover_target_element_setter, default_attributes);

    define_native_accessor(realm, "popoverTargetAction", popover_target_action_getter, popover_target_action_setter, default_attributes);

        define_direct_property("checkValidity", JS::js_undefined(), default_attributes | JS::Attribute::Unimplemented);
            
        define_direct_property("reportValidity", JS::js_undefined(), default_attributes | JS::Attribute::Unimplemented);
            
    define_native_function(realm, "setCustomValidity", set_custom_validity, 1, default_attributes);

    define_direct_property(vm.well_known_symbol_to_string_tag(), JS::PrimitiveString::create(vm, "HTMLButtonElement"_string), JS::Attribute::Configurable);

    Base::initialize(realm);

}

[[maybe_unused]] static JS::ThrowCompletionOr<HTML::HTMLButtonElement*> impl_from(JS::VM& vm)
{
    auto this_value = vm.this_value();
    JS::Object* this_object = nullptr;
    if (this_value.is_nullish())
        this_object = &vm.current_realm()->global_object();
    else
        this_object = TRY(this_value.to_object(vm));

    if (!is<HTML::HTMLButtonElement>(this_object))
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "HTMLButtonElement");
    return static_cast<HTML::HTMLButtonElement*>(this_object);
}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::disabled_getter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::disabled_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval = impl->has_attribute("disabled"_fly_string);

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::disabled_setter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::disabled_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "HTMLButtonElement setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    bool cpp_value;

    cpp_value = value.to_boolean();

    if (!cpp_value)
        impl->remove_attribute("disabled"_fly_string);
    else
        MUST(impl->set_attribute("disabled"_fly_string, String {}));

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::form_getter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::form_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->form(); }));

    if (!retval) {
        return JS::js_null();
    } else {

    return &const_cast<HTMLFormElement&>(*retval);

    }

}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::form_action_getter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::form_action_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->form_action(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::form_action_setter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::form_action_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "HTMLButtonElement setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    String cpp_value;
    if (!false || !value.is_null()) {
        cpp_value = TRY(WebIDL::to_usv_string(vm, value));
    }

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_form_action(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::form_enctype_getter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::form_enctype_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto contentAttributeValue = impl->attribute("formenctype"_fly_string);

    auto retval = contentAttributeValue.value_or(String {});

    auto did_set_to_missing_value = false;
    if (!contentAttributeValue.has_value()) {
        retval = ""_string;
        did_set_to_missing_value = true;
    }

    Array valid_values { "application/x-www-form-urlencoded"_string, "multipart/form-data"_string, "text/plain"_string };

    auto has_keyword = false;
    for (auto const& value : valid_values) {
        if (value.equals_ignoring_ascii_case(retval)) {
            has_keyword = true;
            retval = value;
            break;
        }
    }

    if (!has_keyword && !did_set_to_missing_value)
        retval = "application/x-www-form-urlencoded"_string;
    
    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::form_enctype_setter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::form_enctype_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "HTMLButtonElement setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    String cpp_value;
    if (!false || !value.is_null()) {
        cpp_value = TRY(WebIDL::to_string(vm, value));
    }

MUST(impl->set_attribute("formenctype"_fly_string, cpp_value));

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::form_method_getter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::form_method_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto contentAttributeValue = impl->attribute("formmethod"_fly_string);

    auto retval = contentAttributeValue.value_or(String {});

    auto did_set_to_missing_value = false;
    if (!contentAttributeValue.has_value()) {
        retval = ""_string;
        did_set_to_missing_value = true;
    }

    Array valid_values { "get"_string, "post"_string, "dialog"_string };

    auto has_keyword = false;
    for (auto const& value : valid_values) {
        if (value.equals_ignoring_ascii_case(retval)) {
            has_keyword = true;
            retval = value;
            break;
        }
    }

    if (!has_keyword && !did_set_to_missing_value)
        retval = "get"_string;
    
    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::form_method_setter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::form_method_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "HTMLButtonElement setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    String cpp_value;
    if (!false || !value.is_null()) {
        cpp_value = TRY(WebIDL::to_string(vm, value));
    }

MUST(impl->set_attribute("formmethod"_fly_string, cpp_value));

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::form_no_validate_getter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::form_no_validate_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval = impl->has_attribute("formnovalidate"_fly_string);

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::form_no_validate_setter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::form_no_validate_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "HTMLButtonElement setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    bool cpp_value;

    cpp_value = value.to_boolean();

    if (!cpp_value)
        impl->remove_attribute("formnovalidate"_fly_string);
    else
        MUST(impl->set_attribute("formnovalidate"_fly_string, String {}));

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::form_target_getter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::form_target_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto contentAttributeValue = impl->attribute("formtarget"_fly_string);

    auto retval = contentAttributeValue.value_or(String {});

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::form_target_setter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::form_target_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "HTMLButtonElement setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    String cpp_value;
    if (!false || !value.is_null()) {
        cpp_value = TRY(WebIDL::to_string(vm, value));
    }

MUST(impl->set_attribute("formtarget"_fly_string, cpp_value));

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::name_getter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::name_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto contentAttributeValue = impl->attribute("name"_fly_string);

    auto retval = contentAttributeValue.value_or(String {});

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::name_setter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::name_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "HTMLButtonElement setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    String cpp_value;
    if (!false || !value.is_null()) {
        cpp_value = TRY(WebIDL::to_string(vm, value));
    }

MUST(impl->set_attribute("name"_fly_string, cpp_value));

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::type_getter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::type_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->type_for_bindings(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::type_setter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::type_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "HTMLButtonElement setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    String cpp_value;
    if (!false || !value.is_null()) {
        cpp_value = TRY(WebIDL::to_string(vm, value));
    }

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_type_for_bindings(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::value_getter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::value_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto contentAttributeValue = impl->attribute("value"_fly_string);

    auto retval = contentAttributeValue.value_or(String {});

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::value_setter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::value_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "HTMLButtonElement setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    String cpp_value;
    if (!false || !value.is_null()) {
        cpp_value = TRY(WebIDL::to_string(vm, value));
    }

MUST(impl->set_attribute("value"_fly_string, cpp_value));

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::will_validate_getter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::will_validate_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->will_validate(); }));

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::validity_getter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::validity_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->validity(); }));

    return &const_cast<ValidityState&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::labels_getter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::labels_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->labels(); }));

    return &const_cast<NodeList&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::popover_target_element_getter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::popover_target_element_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval = GC::Ptr<Element> {};

    auto contentAttributeValue = impl->attribute("popovertarget"_fly_string);

    auto const explicitly_set_attr = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->popover_target_element(); }));
    if (explicitly_set_attr) {
        if (&impl->shadow_including_root() == &explicitly_set_attr->root()) {
            retval = explicitly_set_attr;
        } else {
            retval = GC::Ptr<Element> {};
        }
    }

    else if (contentAttributeValue.has_value()) {
        impl->root().for_each_in_inclusive_subtree_of_type<DOM::Element>([&](auto& candidate) {
            if (candidate.attribute(HTML::AttributeNames::id) == contentAttributeValue.value()) {
                retval = &candidate;
                return TraversalDecision::Break;
            }
            return TraversalDecision::Continue;
        });
    }

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (!retval) {
        return JS::js_null();
    } else {

    return &const_cast<Element&>(*retval);

    }

}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::popover_target_element_setter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::popover_target_element_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "HTMLButtonElement setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    GC::Ptr<Element> cpp_value;

    if (!value.is_nullish()) {
        if (!value.is_object() || !is<Element>(value.as_object()))
            return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "Element");

        cpp_value = &static_cast<Element&>(value.as_object());
    }

    if (!cpp_value) {
        TRY(throw_dom_exception_if_needed(vm, [&] { return impl->set_popover_target_element(nullptr); }));
        impl->remove_attribute("popovertarget"_fly_string);
        return JS::js_undefined();
    }

    MUST(impl->set_attribute("popovertarget"_fly_string, String {}));

    TRY(throw_dom_exception_if_needed(vm, [&] { return impl->set_popover_target_element(cpp_value); }));

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::popover_target_action_getter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::popover_target_action_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto contentAttributeValue = impl->attribute("popovertargetaction"_fly_string);

    auto retval = contentAttributeValue.value_or(String {});

    auto did_set_to_missing_value = false;
    if (!contentAttributeValue.has_value()) {
        retval = "toggle"_string;
        did_set_to_missing_value = true;
    }

    Array valid_values { "toggle"_string, "show"_string, "hide"_string };

    auto has_keyword = false;
    for (auto const& value : valid_values) {
        if (value.equals_ignoring_ascii_case(retval)) {
            has_keyword = true;
            retval = value;
            break;
        }
    }

    if (!has_keyword && !did_set_to_missing_value)
        retval = "toggle"_string;
    
    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::popover_target_action_setter)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::popover_target_action_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "HTMLButtonElement setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    String cpp_value;
    if (!false || !value.is_null()) {
        cpp_value = TRY(WebIDL::to_string(vm, value));
    }

MUST(impl->set_attribute("popovertargetaction"_fly_string, cpp_value));

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(HTMLButtonElementPrototype::set_custom_validity)
{
    WebIDL::log_trace(vm, "HTMLButtonElementPrototype::set_custom_validity");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "setCustomValidity");

    auto arg0 = vm.argument(0);

    String error;
    if (!false || !arg0.is_null()) {
        error = TRY(WebIDL::to_string(vm, arg0));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->set_custom_validity(error); }));

    return JS::js_undefined();

}

} // namespace Web::Bindings
