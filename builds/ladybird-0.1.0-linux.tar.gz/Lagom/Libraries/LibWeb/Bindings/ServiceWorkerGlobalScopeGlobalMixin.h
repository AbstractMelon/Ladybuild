
#pragma once

#include <LibJS/Runtime/Object.h>

namespace Web::Bindings {

class ServiceWorkerGlobalScopeGlobalMixin {
public:
    void initialize(JS::Realm&, JS::Object&);
    ServiceWorkerGlobalScopeGlobalMixin();
    virtual ~ServiceWorkerGlobalScopeGlobalMixin();

private:


};


} // namespace Web::Bindings
    