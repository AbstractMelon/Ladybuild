
#pragma once

#include <LibJS/Runtime/Object.h>

namespace Web::Bindings {

class ElementInternalsPrototype : public JS::Object {
    JS_OBJECT(ElementInternalsPrototype, JS::Object);
    GC_DECLARE_ALLOCATOR(ElementInternalsPrototype);
public:
    explicit ElementInternalsPrototype(JS::Realm&);
    virtual void initialize(JS::Realm&) override;
    virtual ~ElementInternalsPrototype() override;
private:

    JS_DECLARE_NATIVE_FUNCTION(shadow_root_getter);


};


} // namespace Web::Bindings
    