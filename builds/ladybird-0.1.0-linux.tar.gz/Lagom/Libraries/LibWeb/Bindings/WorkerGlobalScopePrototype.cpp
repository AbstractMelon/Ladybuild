
#include <AK/Function.h>
#include <LibIDL/Types.h>
#include <LibJS/Runtime/Array.h>
#include <LibJS/Runtime/ArrayBuffer.h>
#include <LibJS/Runtime/DataView.h>
#include <LibJS/Runtime/Error.h>
#include <LibJS/Runtime/FunctionObject.h>
#include <LibJS/Runtime/GlobalObject.h>
#include <LibJS/Runtime/Iterator.h>
#include <LibJS/Runtime/PromiseConstructor.h>
#include <LibJS/Runtime/TypedArray.h>
#include <LibJS/Runtime/Value.h>
#include <LibJS/Runtime/ValueInlines.h>
#include <LibURL/Origin.h>
#include <LibWeb/Bindings/WorkerGlobalScopePrototype.h>
#include <LibWeb/Bindings/ExceptionOrUtils.h>
#include <LibWeb/Bindings/Intrinsics.h>
#include <LibWeb/DOM/Element.h>
#include <LibWeb/DOM/Event.h>
#include <LibWeb/DOM/IDLEventListener.h>
#include <LibWeb/DOM/NodeFilter.h>
#include <LibWeb/DOM/Range.h>
#include <LibWeb/HTML/Numbers.h>
#include <LibWeb/HTML/Scripting/Agent.h>
#include <LibWeb/HTML/Scripting/Environments.h>
#include <LibWeb/HTML/Window.h>
#include <LibWeb/HTML/WindowProxy.h>
#include <LibWeb/Infra/Strings.h>
#include <LibWeb/WebIDL/AbstractOperations.h>
#include <LibWeb/WebIDL/Buffers.h>
#include <LibWeb/WebIDL/OverloadResolution.h>
#include <LibWeb/WebIDL/Promise.h>
#include <LibWeb/WebIDL/Tracing.h>
#include <LibWeb/WebIDL/Types.h>

#if __has_include(<LibWeb/Bindings/EventTargetPrototype.h>)
#    include <LibWeb/Bindings/EventTargetPrototype.h>
#endif


#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/WorkerGlobalScope.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/FontFaceSet.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/EventTarget.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/MessagePort.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Window.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/WorkerLocation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/WorkerNavigator.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/FontFace.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/AbortSignal.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Event.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/MediaQueryList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/Screen.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/VisualViewport.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Document.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/CustomElements/CustomElementRegistry.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/History.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Navigation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Navigator.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Crypto/Crypto.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Fetch/Request.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Fetch/Response.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HighResolutionTime/Performance.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/ImageBitmap.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/IndexedDB/IDBFactory.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/MediaCapabilitiesAPI/MediaCapabilities.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/ScreenOrientation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Animations/DocumentTimeline.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/StyleSheetList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/CDATASection.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Comment.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/DOMImplementation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/DocumentFragment.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/DocumentType.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Element.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/HTMLCollection.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Node.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/NodeFilter.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/NodeIterator.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/NodeList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/ProcessingInstruction.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Range.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Text.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/TreeWalker.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLAllCollection.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLHeadElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLScriptElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Location.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Selection/Selection.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/NavigationHistoryEntry.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/NavigationTransition.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Clipboard/Clipboard.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CredentialManagement/CredentialsContainer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/MimeTypeArray.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/PluginArray.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/UserActivation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/ServiceWorker/ServiceWorkerContainer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Storage.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/RequestIdleCallback/IdleDeadline.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Crypto/SubtleCrypto.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Fetch/Headers.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/NavigationTiming/PerformanceNavigation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/NavigationTiming/PerformanceTiming.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/PerformanceTimeline/PerformanceEntry.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/UserTiming/PerformanceMark.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/UserTiming/PerformanceMeasure.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/FileAPI/Blob.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/ImageData.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/CanvasRenderingContext2D.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/EncryptedMediaExtensions/EncryptedMediaExtensions.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/StorageAPI/StorageManager.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Animations/AnimationTimeline.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/CSSStyleSheet.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/CharacterData.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/XMLDocument.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Attr.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/DOMTokenList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/NamedNodeMap.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/ShadowRoot.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMRect.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMRectList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLSlotElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/AbstractRange.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/DOMStringMap.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/ElementInternals.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Scripting/Fetching.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/NavigationType.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CredentialManagement/Credential.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CredentialManagement/FederatedCredential.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CredentialManagement/PasswordCredential.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/MimeType.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Plugin.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Worker.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/ServiceWorker/ServiceWorkerRegistration.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Crypto/CryptoKey.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/ReadableStream.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/XHR/FormData.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOMURL/URLSearchParams.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLCanvasElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Canvas/CanvasDrawPath.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Canvas/CanvasTextDrawingStyles.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLImageElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLVideoElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGImageElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/CSSRule.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/CSSRuleList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/MediaList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/StyleSheet.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Animations/Animation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Animations/KeyframeEffect.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMRectReadOnly.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/CSSStyleDeclaration.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/ServiceWorker/ServiceWorker.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/ReadableStreamBYOBReader.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/ReadableStreamDefaultReader.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/WritableStream.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/FileAPI/File.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLRenderingContext.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGL2RenderingContext.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Path2D.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/CanvasGradient.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/CanvasPattern.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMPointReadOnly.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/TextMetrics.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMMatrix.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLMediaElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGGraphicsElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Animations/AnimationEffect.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/WritableStreamDefaultWriter.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMMatrixReadOnly.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMPoint.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/AudioTrackList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/MediaError.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/TextTrack.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/TextTrackList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/TimeRanges.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/VideoTrackList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGAnimatedString.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLActiveInfo.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLBuffer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLFramebuffer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLObject.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLProgram.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLRenderbuffer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLShader.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLShaderPrecisionFormat.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLTexture.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLUniformLocation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLQuery.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLSampler.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLSync.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLTransformFeedback.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLVertexArrayObject.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/AudioTrack.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/VideoTrack.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGSVGElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGAnimatedRect.h>

// FIXME: This is a total hack until we can figure out the namespace for a given type somehow.
using namespace Web::Animations;
using namespace Web::Clipboard;
using namespace Web::CredentialManagement;
using namespace Web::Crypto;
using namespace Web::CSS;
using namespace Web::DOM;
using namespace Web::DOMURL;
using namespace Web::Encoding;
using namespace Web::EntriesAPI;
using namespace Web::EventTiming;
using namespace Web::Fetch;
using namespace Web::FileAPI;
using namespace Web::Geometry;
using namespace Web::HighResolutionTime;
using namespace Web::HTML;
using namespace Web::IndexedDB;
using namespace Web::Internals;
using namespace Web::IntersectionObserver;
using namespace Web::MediaCapabilitiesAPI;
using namespace Web::MediaSourceExtensions;
using namespace Web::NavigationTiming;
using namespace Web::PerformanceTimeline;
using namespace Web::RequestIdleCallback;
using namespace Web::ResizeObserver;
using namespace Web::Selection;
using namespace Web::ServiceWorker;
using namespace Web::StorageAPI;
using namespace Web::Streams;
using namespace Web::SVG;
using namespace Web::UIEvents;
using namespace Web::URLPattern;
using namespace Web::UserTiming;
using namespace Web::WebAssembly;
using namespace Web::WebAudio;
using namespace Web::WebGL;
using namespace Web::WebGL::Extensions;
using namespace Web::WebIDL;
using namespace Web::WebVTT;
using namespace Web::XHR;

namespace Web::Bindings {

GC_DEFINE_ALLOCATOR(WorkerGlobalScopePrototype);

WorkerGlobalScopePrototype::WorkerGlobalScopePrototype([[maybe_unused]] JS::Realm& realm)
    : Object(realm, nullptr)

{
}

WorkerGlobalScopePrototype::~WorkerGlobalScopePrototype()
{
}

void WorkerGlobalScopePrototype::initialize(JS::Realm& realm)
{


    [[maybe_unused]] auto& vm = realm.vm();
    [[maybe_unused]] u8 default_attributes = JS::Attribute::Enumerable | JS::Attribute::Configurable | JS::Attribute::Writable;



    set_prototype(&ensure_web_prototype<EventTargetPrototype>(realm, "EventTarget"_fly_string));


    define_native_accessor(realm, "self", self_getter, nullptr, default_attributes);

    define_native_accessor(realm, "location", location_getter, nullptr, default_attributes);

    define_native_accessor(realm, "navigator", navigator_getter, nullptr, default_attributes);

    define_native_accessor(realm, "onerror", onerror_getter, onerror_setter, default_attributes);

    define_native_accessor(realm, "onlanguagechange", onlanguagechange_getter, onlanguagechange_setter, default_attributes);

    define_native_accessor(realm, "onoffline", onoffline_getter, onoffline_setter, default_attributes);

    define_native_accessor(realm, "ononline", ononline_getter, ononline_setter, default_attributes);

    define_native_accessor(realm, "onrejectionhandled", onrejectionhandled_getter, onrejectionhandled_setter, default_attributes);

    define_native_accessor(realm, "onunhandledrejection", onunhandledrejection_getter, onunhandledrejection_setter, default_attributes);

    define_native_accessor(realm, "origin", origin_getter, origin_setter, default_attributes);

    define_native_accessor(realm, "isSecureContext", is_secure_context_getter, nullptr, default_attributes);

    define_native_accessor(realm, "crossOriginIsolated", cross_origin_isolated_getter, nullptr, default_attributes);

    define_native_accessor(realm, "performance", performance_getter, performance_setter, default_attributes);

    define_native_accessor(realm, "indexedDB", indexed_db_getter, nullptr, default_attributes);

    define_native_accessor(realm, "crypto", crypto_getter, nullptr, default_attributes);

    define_native_accessor(realm, "fonts", fonts_getter, nullptr, default_attributes);

    define_native_function(realm, "queueMicrotask", queue_microtask, 1, default_attributes);

    define_native_function(realm, "importScripts", import_scripts, 0, default_attributes);

    define_native_function(realm, "clearTimeout", clear_timeout, 0, default_attributes);

    define_native_function(realm, "btoa", btoa, 1, default_attributes);

    define_native_function(realm, "setTimeout", set_timeout, 1, default_attributes);

    define_native_function(realm, "reportError", report_error, 1, default_attributes);

    define_native_function(realm, "atob", atob, 1, default_attributes);

    define_native_function(realm, "setInterval", set_interval, 1, default_attributes);

    define_native_function(realm, "structuredClone", structured_clone, 1, default_attributes);

    define_native_function(realm, "clearInterval", clear_interval, 0, default_attributes);

    define_native_function(realm, "createImageBitmap", create_image_bitmap, 1, default_attributes);

    define_native_function(realm, "fetch", fetch, 1, default_attributes);

    define_direct_property(vm.well_known_symbol_to_string_tag(), JS::PrimitiveString::create(vm, "WorkerGlobalScope"_string), JS::Attribute::Configurable);

    Base::initialize(realm);

}

[[maybe_unused]] static JS::ThrowCompletionOr<HTML::WorkerGlobalScope*> impl_from(JS::VM& vm)
{
    auto this_value = vm.this_value();
    JS::Object* this_object = nullptr;
    if (this_value.is_nullish())
        this_object = &vm.current_realm()->global_object();
    else
        this_object = TRY(this_value.to_object(vm));

    if (!is<HTML::WorkerGlobalScope>(this_object))
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "WorkerGlobalScope");
    return static_cast<HTML::WorkerGlobalScope*>(this_object);
}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::self_getter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::self_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->self(); }));

    return &const_cast<WorkerGlobalScope&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::location_getter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::location_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->location(); }));

    return &const_cast<WorkerLocation&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::navigator_getter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::navigator_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->navigator(); }));

    return &const_cast<WorkerNavigator&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::onerror_getter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::onerror_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->onerror(); }));

  if (!retval) {
      return JS::js_null();
  } else {
      return retval->callback;
  }

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::onerror_setter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::onerror_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "WorkerGlobalScope setter");

    auto value = vm.argument(0);

    GC::Ptr<WebIDL::CallbackType> cpp_value;
    if (value.is_object())
        cpp_value = vm.heap().allocate<WebIDL::CallbackType>(value.as_object(), HTML::incumbent_realm(), WebIDL::OperationReturnsPromise::No);

    TRY(throw_dom_exception_if_needed(vm, [&] { return impl->set_onerror(cpp_value); }));

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::onlanguagechange_getter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::onlanguagechange_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->onlanguagechange(); }));

  if (!retval) {
      return JS::js_null();
  } else {
      return retval->callback;
  }

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::onlanguagechange_setter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::onlanguagechange_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "WorkerGlobalScope setter");

    auto value = vm.argument(0);

    GC::Ptr<WebIDL::CallbackType> cpp_value;
    if (value.is_object())
        cpp_value = vm.heap().allocate<WebIDL::CallbackType>(value.as_object(), HTML::incumbent_realm(), WebIDL::OperationReturnsPromise::No);

    TRY(throw_dom_exception_if_needed(vm, [&] { return impl->set_onlanguagechange(cpp_value); }));

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::onoffline_getter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::onoffline_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->onoffline(); }));

  if (!retval) {
      return JS::js_null();
  } else {
      return retval->callback;
  }

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::onoffline_setter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::onoffline_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "WorkerGlobalScope setter");

    auto value = vm.argument(0);

    GC::Ptr<WebIDL::CallbackType> cpp_value;
    if (value.is_object())
        cpp_value = vm.heap().allocate<WebIDL::CallbackType>(value.as_object(), HTML::incumbent_realm(), WebIDL::OperationReturnsPromise::No);

    TRY(throw_dom_exception_if_needed(vm, [&] { return impl->set_onoffline(cpp_value); }));

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::ononline_getter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::ononline_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->ononline(); }));

  if (!retval) {
      return JS::js_null();
  } else {
      return retval->callback;
  }

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::ononline_setter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::ononline_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "WorkerGlobalScope setter");

    auto value = vm.argument(0);

    GC::Ptr<WebIDL::CallbackType> cpp_value;
    if (value.is_object())
        cpp_value = vm.heap().allocate<WebIDL::CallbackType>(value.as_object(), HTML::incumbent_realm(), WebIDL::OperationReturnsPromise::No);

    TRY(throw_dom_exception_if_needed(vm, [&] { return impl->set_ononline(cpp_value); }));

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::onrejectionhandled_getter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::onrejectionhandled_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->onrejectionhandled(); }));

  if (!retval) {
      return JS::js_null();
  } else {
      return retval->callback;
  }

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::onrejectionhandled_setter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::onrejectionhandled_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "WorkerGlobalScope setter");

    auto value = vm.argument(0);

    GC::Ptr<WebIDL::CallbackType> cpp_value;
    if (value.is_object())
        cpp_value = vm.heap().allocate<WebIDL::CallbackType>(value.as_object(), HTML::incumbent_realm(), WebIDL::OperationReturnsPromise::No);

    TRY(throw_dom_exception_if_needed(vm, [&] { return impl->set_onrejectionhandled(cpp_value); }));

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::onunhandledrejection_getter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::onunhandledrejection_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->onunhandledrejection(); }));

  if (!retval) {
      return JS::js_null();
  } else {
      return retval->callback;
  }

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::onunhandledrejection_setter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::onunhandledrejection_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "WorkerGlobalScope setter");

    auto value = vm.argument(0);

    GC::Ptr<WebIDL::CallbackType> cpp_value;
    if (value.is_object())
        cpp_value = vm.heap().allocate<WebIDL::CallbackType>(value.as_object(), HTML::incumbent_realm(), WebIDL::OperationReturnsPromise::No);

    TRY(throw_dom_exception_if_needed(vm, [&] { return impl->set_onunhandledrejection(cpp_value); }));

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::origin_getter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::origin_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->origin(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::origin_setter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::origin_setter");
    auto this_value = vm.this_value();
    if (!this_value.is_object() || !is<HTML::WorkerGlobalScope>(this_value.as_object()))
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "WorkerGlobalScope");
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "WorkerGlobalScope setter");
    TRY(this_value.as_object().internal_define_own_property("origin", JS::PropertyDescriptor { .value = vm.argument(0), .writable = true }));
    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::is_secure_context_getter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::is_secure_context_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->is_secure_context(); }));

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::cross_origin_isolated_getter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::cross_origin_isolated_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->cross_origin_isolated(); }));

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::performance_getter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::performance_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->performance(); }));

    return &const_cast<Performance&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::performance_setter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::performance_setter");
    auto this_value = vm.this_value();
    if (!this_value.is_object() || !is<HTML::WorkerGlobalScope>(this_value.as_object()))
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "WorkerGlobalScope");
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "WorkerGlobalScope setter");
    TRY(this_value.as_object().internal_define_own_property("performance", JS::PropertyDescriptor { .value = vm.argument(0), .writable = true }));
    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::indexed_db_getter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::indexed_db_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->indexed_db(); }));

    return &const_cast<IDBFactory&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::crypto_getter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::crypto_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->crypto(); }));

    return &const_cast<Crypto::Crypto&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::fonts_getter)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::fonts_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->fonts(); }));

    return &const_cast<FontFaceSet&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::import_scripts)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::import_scripts");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    Vector<String> urls;

    if (vm.argument_count() > 0) {
        urls.ensure_capacity(vm.argument_count() - 0);

        for (size_t i = 0; i < vm.argument_count(); ++i) {
            auto to_string_result = TRY(WebIDL::to_usv_string(vm, vm.argument(i)));
            urls.unchecked_append(move(to_string_result));
        }
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->import_scripts(move(urls)); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::btoa)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::btoa");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "btoa");

    auto arg0 = vm.argument(0);

    String data;
    if (!false || !arg0.is_null()) {
        data = TRY(WebIDL::to_string(vm, arg0));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->btoa(data); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::atob)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::atob");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "atob");

    auto arg0 = vm.argument(0);

    String data;
    if (!false || !arg0.is_null()) {
        data = TRY(WebIDL::to_string(vm, arg0));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->atob(data); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::queue_microtask)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::queue_microtask");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "queueMicrotask");

    auto arg0 = vm.argument(0);

    if (!arg0.is_function())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAFunction, arg0.to_string_without_side_effects());

    auto callback = vm.heap().allocate<WebIDL::CallbackType>(arg0.as_object(), HTML::incumbent_realm(), WebIDL::OperationReturnsPromise::No);

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->queue_microtask(callback); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::structured_clone)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::structured_clone");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "structuredClone");

    auto arg0 = vm.argument(0);

    auto value = arg0;

    auto arg1 = vm.argument(1);

    if (!arg1.is_nullish() && !arg1.is_object())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "StructuredSerializeOptions");

    StructuredSerializeOptions options {};

    auto transfer_property_value_0 = JS::js_undefined();
    if (arg1.is_object())
        transfer_property_value_0 = TRY(arg1.as_object().get("transfer"));

    Vector<GC::Root<JS::Object>> transfer_value_0;

    if (!transfer_property_value_0.is_undefined()) {

    if (!transfer_property_value_0.is_object())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObject, transfer_property_value_0.to_string_without_side_effects());

    auto transfer_property_value_0_iterator_method0 = TRY(transfer_property_value_0.get_method(vm, vm.well_known_symbol_iterator()));
    if (!transfer_property_value_0_iterator_method0)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotIterable, transfer_property_value_0.to_string_without_side_effects());

    auto transfer_property_value_0_iterator1 = TRY(JS::get_iterator_from_method(vm, transfer_property_value_0, *transfer_property_value_0_iterator_method0));

    Vector<GC::Root<JS::Object>> transfer_value_0_non_optional;

    for (;;) {
        auto next1 = TRY(JS::iterator_step(vm, transfer_property_value_0_iterator1));
        if (!next1)
            break;

        auto next_item1 = TRY(JS::iterator_value(vm, *next1));

    auto sequence_item1 = GC::make_root(TRY(next_item1.to_object(vm)));

    transfer_value_0_non_optional.append(sequence_item1);
    }

        transfer_value_0 = move(transfer_value_0_non_optional);
    }

    options.transfer = transfer_value_0;

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->structured_clone(value, options); }));

    return retval;

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::report_error)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::report_error");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "reportError");

    auto arg0 = vm.argument(0);

    auto e = arg0;

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->report_error(e); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::set_timeout)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::set_timeout");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "setTimeout");

    auto arg0 = vm.argument(0);

    auto arg0_to_variant = [&vm, &realm](JS::Value arg0) -> JS::ThrowCompletionOr<Variant<String, GC::Ref<WebIDL::CallbackType>>> {
        // These might be unused.
        (void)vm;
        (void)realm;

        if (arg0.is_object()) {
            [[maybe_unused]] auto& arg0_object = arg0.as_object();

            if (arg0_object.is_function())
                return vm.heap().allocate<WebIDL::CallbackType>(arg0.as_function(), HTML::incumbent_realm());

        }

    String arg0_string;
    if (!false || !arg0.is_null()) {
        arg0_string = TRY(WebIDL::to_string(vm, arg0));
    }

        return { arg0_string };

    };

    Variant<String, GC::Ref<WebIDL::CallbackType>> handler = TRY(arg0_to_variant(arg0));

    auto arg1 = vm.argument(1);

    WebIDL::Long timeout;

    if (!arg1.is_undefined())

    timeout = TRY(WebIDL::convert_to_int<WebIDL::Long>(vm, arg1, WebIDL::EnforceRange::No, WebIDL::Clamp::No));

    else
        timeout = static_cast<WebIDL::Long>(0);

    GC::RootVector<JS::Value> arguments { vm.heap() };

    if (vm.argument_count() > 2) {
        arguments.ensure_capacity(vm.argument_count() - 2);

        for (size_t i = 2; i < vm.argument_count(); ++i)
            arguments.unchecked_append(vm.argument(i));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->set_timeout(handler, timeout, move(arguments)); }));

    return JS::Value(static_cast<WebIDL::Long>(retval));

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::clear_timeout)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::clear_timeout");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    auto arg0 = vm.argument(0);

    WebIDL::Long id;

    if (!arg0.is_undefined())

    id = TRY(WebIDL::convert_to_int<WebIDL::Long>(vm, arg0, WebIDL::EnforceRange::No, WebIDL::Clamp::No));

    else
        id = static_cast<WebIDL::Long>(0);

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->clear_timeout(id); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::set_interval)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::set_interval");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "setInterval");

    auto arg0 = vm.argument(0);

    auto arg0_to_variant = [&vm, &realm](JS::Value arg0) -> JS::ThrowCompletionOr<Variant<String, GC::Ref<WebIDL::CallbackType>>> {
        // These might be unused.
        (void)vm;
        (void)realm;

        if (arg0.is_object()) {
            [[maybe_unused]] auto& arg0_object = arg0.as_object();

            if (arg0_object.is_function())
                return vm.heap().allocate<WebIDL::CallbackType>(arg0.as_function(), HTML::incumbent_realm());

        }

    String arg0_string;
    if (!false || !arg0.is_null()) {
        arg0_string = TRY(WebIDL::to_string(vm, arg0));
    }

        return { arg0_string };

    };

    Variant<String, GC::Ref<WebIDL::CallbackType>> handler = TRY(arg0_to_variant(arg0));

    auto arg1 = vm.argument(1);

    WebIDL::Long timeout;

    if (!arg1.is_undefined())

    timeout = TRY(WebIDL::convert_to_int<WebIDL::Long>(vm, arg1, WebIDL::EnforceRange::No, WebIDL::Clamp::No));

    else
        timeout = static_cast<WebIDL::Long>(0);

    GC::RootVector<JS::Value> arguments { vm.heap() };

    if (vm.argument_count() > 2) {
        arguments.ensure_capacity(vm.argument_count() - 2);

        for (size_t i = 2; i < vm.argument_count(); ++i)
            arguments.unchecked_append(vm.argument(i));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->set_interval(handler, timeout, move(arguments)); }));

    return JS::Value(static_cast<WebIDL::Long>(retval));

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::clear_interval)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::clear_interval");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    auto arg0 = vm.argument(0);

    WebIDL::Long id;

    if (!arg0.is_undefined())

    id = TRY(WebIDL::convert_to_int<WebIDL::Long>(vm, arg0, WebIDL::EnforceRange::No, WebIDL::Clamp::No));

    else
        id = static_cast<WebIDL::Long>(0);

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->clear_interval(id); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::create_image_bitmap0)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::create_image_bitmap0");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto steps = [&realm, &vm]() -> JS::ThrowCompletionOr<GC::Ref<WebIDL::Promise>> {
        (void)realm;

    auto* impl = TRY(impl_from(vm));

    auto arg0 = vm.argument(0);

    auto arg0_to_variant = [&vm, &realm](JS::Value arg0) -> JS::ThrowCompletionOr<Variant<GC::Root<HTMLImageElement>, GC::Root<SVGImageElement>, GC::Root<HTMLVideoElement>, GC::Root<HTMLCanvasElement>, GC::Root<ImageBitmap>, GC::Root<Blob>, GC::Root<ImageData>>> {
        // These might be unused.
        (void)vm;
        (void)realm;

        if (arg0.is_object()) {
            [[maybe_unused]] auto& arg0_object = arg0.as_object();

            if (is<PlatformObject>(arg0_object)) {

                if (is<HTMLImageElement>(arg0_object))
                    return GC::make_root(static_cast<HTMLImageElement&>(arg0_object));

                if (is<SVGImageElement>(arg0_object))
                    return GC::make_root(static_cast<SVGImageElement&>(arg0_object));

                if (is<HTMLVideoElement>(arg0_object))
                    return GC::make_root(static_cast<HTMLVideoElement&>(arg0_object));

                if (is<HTMLCanvasElement>(arg0_object))
                    return GC::make_root(static_cast<HTMLCanvasElement&>(arg0_object));

                if (is<ImageBitmap>(arg0_object))
                    return GC::make_root(static_cast<ImageBitmap&>(arg0_object));

                if (is<Blob>(arg0_object))
                    return GC::make_root(static_cast<Blob&>(arg0_object));

                if (is<ImageData>(arg0_object))
                    return GC::make_root(static_cast<ImageData&>(arg0_object));

            }

        }

        return vm.throw_completion<JS::TypeError>("No union types matched"sv);

    };

    Variant<GC::Root<HTMLImageElement>, GC::Root<SVGImageElement>, GC::Root<HTMLVideoElement>, GC::Root<HTMLCanvasElement>, GC::Root<ImageBitmap>, GC::Root<Blob>, GC::Root<ImageData>> image = TRY(arg0_to_variant(arg0));

    auto arg1 = vm.argument(1);

    if (!arg1.is_nullish() && !arg1.is_object())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "ImageBitmapOptions");

    ImageBitmapOptions options {};

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->create_image_bitmap(image, options); }));

        return retval;
    };

    auto maybe_retval = steps();

    // And then, if an exception E was thrown:
    // 1. If op has a return type that is a promise type, then return ! Call(%Promise.reject%, %Promise%, «E»).
    // 2. Otherwise, end these steps and allow the exception to propagate.
    // NOTE: We know that this is a Promise return type statically by the IDL.
    if (maybe_retval.is_throw_completion())
        return WebIDL::create_rejected_promise(realm, maybe_retval.error_value())->promise();

    auto retval = maybe_retval.release_value();

    return GC::Ref { as<JS::Promise>(*retval->promise()) };

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::create_image_bitmap1)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::create_image_bitmap1");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto steps = [&realm, &vm]() -> JS::ThrowCompletionOr<GC::Ref<WebIDL::Promise>> {
        (void)realm;

    auto* impl = TRY(impl_from(vm));

    auto arg0 = vm.argument(0);

    auto arg0_to_variant = [&vm, &realm](JS::Value arg0) -> JS::ThrowCompletionOr<Variant<GC::Root<HTMLImageElement>, GC::Root<SVGImageElement>, GC::Root<HTMLVideoElement>, GC::Root<HTMLCanvasElement>, GC::Root<ImageBitmap>, GC::Root<Blob>, GC::Root<ImageData>>> {
        // These might be unused.
        (void)vm;
        (void)realm;

        if (arg0.is_object()) {
            [[maybe_unused]] auto& arg0_object = arg0.as_object();

            if (is<PlatformObject>(arg0_object)) {

                if (is<HTMLImageElement>(arg0_object))
                    return GC::make_root(static_cast<HTMLImageElement&>(arg0_object));

                if (is<SVGImageElement>(arg0_object))
                    return GC::make_root(static_cast<SVGImageElement&>(arg0_object));

                if (is<HTMLVideoElement>(arg0_object))
                    return GC::make_root(static_cast<HTMLVideoElement&>(arg0_object));

                if (is<HTMLCanvasElement>(arg0_object))
                    return GC::make_root(static_cast<HTMLCanvasElement&>(arg0_object));

                if (is<ImageBitmap>(arg0_object))
                    return GC::make_root(static_cast<ImageBitmap&>(arg0_object));

                if (is<Blob>(arg0_object))
                    return GC::make_root(static_cast<Blob&>(arg0_object));

                if (is<ImageData>(arg0_object))
                    return GC::make_root(static_cast<ImageData&>(arg0_object));

            }

        }

        return vm.throw_completion<JS::TypeError>("No union types matched"sv);

    };

    Variant<GC::Root<HTMLImageElement>, GC::Root<SVGImageElement>, GC::Root<HTMLVideoElement>, GC::Root<HTMLCanvasElement>, GC::Root<ImageBitmap>, GC::Root<Blob>, GC::Root<ImageData>> image = TRY(arg0_to_variant(arg0));

    auto arg1 = vm.argument(1);

    WebIDL::Long sx;

    sx = TRY(WebIDL::convert_to_int<WebIDL::Long>(vm, arg1, WebIDL::EnforceRange::No, WebIDL::Clamp::No));

    auto arg2 = vm.argument(2);

    WebIDL::Long sy;

    sy = TRY(WebIDL::convert_to_int<WebIDL::Long>(vm, arg2, WebIDL::EnforceRange::No, WebIDL::Clamp::No));

    auto arg3 = vm.argument(3);

    WebIDL::Long sw;

    sw = TRY(WebIDL::convert_to_int<WebIDL::Long>(vm, arg3, WebIDL::EnforceRange::No, WebIDL::Clamp::No));

    auto arg4 = vm.argument(4);

    WebIDL::Long sh;

    sh = TRY(WebIDL::convert_to_int<WebIDL::Long>(vm, arg4, WebIDL::EnforceRange::No, WebIDL::Clamp::No));

    auto arg5 = vm.argument(5);

    if (!arg5.is_nullish() && !arg5.is_object())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "ImageBitmapOptions");

    ImageBitmapOptions options {};

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->create_image_bitmap(image, sx, sy, sw, sh, options); }));

        return retval;
    };

    auto maybe_retval = steps();

    // And then, if an exception E was thrown:
    // 1. If op has a return type that is a promise type, then return ! Call(%Promise.reject%, %Promise%, «E»).
    // 2. Otherwise, end these steps and allow the exception to propagate.
    // NOTE: We know that this is a Promise return type statically by the IDL.
    if (maybe_retval.is_throw_completion())
        return WebIDL::create_rejected_promise(realm, maybe_retval.error_value())->promise();

    auto retval = maybe_retval.release_value();

    return GC::Ref { as<JS::Promise>(*retval->promise()) };

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::fetch)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::fetch");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto steps = [&realm, &vm]() -> JS::ThrowCompletionOr<GC::Ref<WebIDL::Promise>> {
        (void)realm;

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "fetch");

    auto arg0 = vm.argument(0);

    auto arg0_to_variant = [&vm, &realm](JS::Value arg0) -> JS::ThrowCompletionOr<Variant<GC::Root<Request>, String>> {
        // These might be unused.
        (void)vm;
        (void)realm;

        if (arg0.is_object()) {
            [[maybe_unused]] auto& arg0_object = arg0.as_object();

            if (is<PlatformObject>(arg0_object)) {

                if (is<Request>(arg0_object))
                    return GC::make_root(static_cast<Request&>(arg0_object));

            }

        }

    String arg0_string;
    if (!false || !arg0.is_null()) {
        arg0_string = TRY(WebIDL::to_usv_string(vm, arg0));
    }

        return { arg0_string };

    };

    Variant<GC::Root<Request>, String> input = TRY(arg0_to_variant(arg0));

    auto arg1 = vm.argument(1);

    if (!arg1.is_nullish() && !arg1.is_object())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "RequestInit");

    RequestInit init {};

    auto body_property_value_1 = JS::js_undefined();
    if (arg1.is_object())
        body_property_value_1 = TRY(arg1.as_object().get("body"));

    if (!body_property_value_1.is_undefined()) {

    auto body_property_value_1_to_variant = [&vm, &realm](JS::Value body_property_value_1) -> JS::ThrowCompletionOr<Variant<GC::Root<ReadableStream>, GC::Root<Blob>, GC::Root<WebIDL::BufferSource>, GC::Root<FormData>, GC::Root<URLSearchParams>, String>> {
        // These might be unused.
        (void)vm;
        (void)realm;

        if (body_property_value_1.is_object()) {
            [[maybe_unused]] auto& body_property_value_1_object = body_property_value_1.as_object();

            if (is<PlatformObject>(body_property_value_1_object)) {

                if (is<ReadableStream>(body_property_value_1_object))
                    return GC::make_root(static_cast<ReadableStream&>(body_property_value_1_object));

                if (is<Blob>(body_property_value_1_object))
                    return GC::make_root(static_cast<Blob&>(body_property_value_1_object));

                if (is<FormData>(body_property_value_1_object))
                    return GC::make_root(static_cast<FormData&>(body_property_value_1_object));

                if (is<URLSearchParams>(body_property_value_1_object))
                    return GC::make_root(static_cast<URLSearchParams&>(body_property_value_1_object));

            }

            if (is<JS::ArrayBuffer>(body_property_value_1_object) || is<JS::DataView>(body_property_value_1_object) || is<JS::TypedArrayBase>(body_property_value_1_object)) {
                GC::Ref<WebIDL::BufferSource> source_object = realm.create<WebIDL::BufferSource>(body_property_value_1_object);
                return GC::make_root(source_object);
            }

        }

    String body_property_value_1_string;
    if (!false || !body_property_value_1.is_null()) {
        body_property_value_1_string = TRY(WebIDL::to_usv_string(vm, body_property_value_1));
    }

        return { body_property_value_1_string };

    };

    Optional<Variant<GC::Root<ReadableStream>, GC::Root<Blob>, GC::Root<WebIDL::BufferSource>, GC::Root<FormData>, GC::Root<URLSearchParams>, String>> body_value_1;
    if (!body_property_value_1.is_nullish())
        body_value_1 = TRY(body_property_value_1_to_variant(body_property_value_1));

    init.body = body_value_1;

    }

    auto cache_property_value_2 = JS::js_undefined();
    if (arg1.is_object())
        cache_property_value_2 = TRY(arg1.as_object().get("cache"));

    if (!cache_property_value_2.is_undefined()) {

    RequestCache cache_value_2 { RequestCache::Default };

    if (!cache_property_value_2.is_undefined()) {

    auto cache_property_value_2_string = TRY(cache_property_value_2.to_string(vm));

    if (cache_property_value_2_string == "default"sv)
        cache_value_2 = RequestCache::Default;

    else if (cache_property_value_2_string == "no-store"sv)
        cache_value_2 = RequestCache::NoStore;

    else if (cache_property_value_2_string == "reload"sv)
        cache_value_2 = RequestCache::Reload;

    else if (cache_property_value_2_string == "no-cache"sv)
        cache_value_2 = RequestCache::NoCache;

    else if (cache_property_value_2_string == "force-cache"sv)
        cache_value_2 = RequestCache::ForceCache;

    else if (cache_property_value_2_string == "only-if-cached"sv)
        cache_value_2 = RequestCache::OnlyIfCached;

    else
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidEnumerationValue, cache_property_value_2_string, "RequestCache");

    }

    init.cache = cache_value_2;

    }

    auto credentials_property_value_3 = JS::js_undefined();
    if (arg1.is_object())
        credentials_property_value_3 = TRY(arg1.as_object().get("credentials"));

    if (!credentials_property_value_3.is_undefined()) {

    RequestCredentials credentials_value_3 { RequestCredentials::Omit };

    if (!credentials_property_value_3.is_undefined()) {

    auto credentials_property_value_3_string = TRY(credentials_property_value_3.to_string(vm));

    if (credentials_property_value_3_string == "omit"sv)
        credentials_value_3 = RequestCredentials::Omit;

    else if (credentials_property_value_3_string == "same-origin"sv)
        credentials_value_3 = RequestCredentials::SameOrigin;

    else if (credentials_property_value_3_string == "include"sv)
        credentials_value_3 = RequestCredentials::Include;

    else
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidEnumerationValue, credentials_property_value_3_string, "RequestCredentials");

    }

    init.credentials = credentials_value_3;

    }

    auto duplex_property_value_4 = JS::js_undefined();
    if (arg1.is_object())
        duplex_property_value_4 = TRY(arg1.as_object().get("duplex"));

    if (!duplex_property_value_4.is_undefined()) {

    RequestDuplex duplex_value_4 { RequestDuplex::Half };

    if (!duplex_property_value_4.is_undefined()) {

    auto duplex_property_value_4_string = TRY(duplex_property_value_4.to_string(vm));

    if (duplex_property_value_4_string == "half"sv)
        duplex_value_4 = RequestDuplex::Half;

    else
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidEnumerationValue, duplex_property_value_4_string, "RequestDuplex");

    }

    init.duplex = duplex_value_4;

    }

    auto headers_property_value_5 = JS::js_undefined();
    if (arg1.is_object())
        headers_property_value_5 = TRY(arg1.as_object().get("headers"));

    if (!headers_property_value_5.is_undefined()) {

    auto headers_property_value_5_to_variant = [&vm, &realm](JS::Value headers_property_value_5) -> JS::ThrowCompletionOr<Variant<Vector<Vector<String>>, OrderedHashMap<String, String>>> {
        // These might be unused.
        (void)vm;
        (void)realm;

        if (headers_property_value_5.is_object()) {
            [[maybe_unused]] auto& headers_property_value_5_object = headers_property_value_5.as_object();

        auto method = TRY(headers_property_value_5.get_method(vm, vm.well_known_symbol_iterator()));

        if (method) {

    auto headers_property_value_5_iterator1 = TRY(JS::get_iterator_from_method(vm, headers_property_value_5, *method));

    Vector<Vector<String>> headers_value_5;

    for (;;) {
        auto next1 = TRY(JS::iterator_step(vm, headers_property_value_5_iterator1));
        if (!next1)
            break;

        auto next_item1 = TRY(JS::iterator_value(vm, *next1));

    if (!next_item1.is_object())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObject, next_item1.to_string_without_side_effects());

    auto next_item1_iterator_method1 = TRY(next_item1.get_method(vm, vm.well_known_symbol_iterator()));
    if (!next_item1_iterator_method1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotIterable, next_item1.to_string_without_side_effects());

    auto next_item1_iterator2 = TRY(JS::get_iterator_from_method(vm, next_item1, *next_item1_iterator_method1));

    Vector<String> sequence_item1;

    for (;;) {
        auto next2 = TRY(JS::iterator_step(vm, next_item1_iterator2));
        if (!next2)
            break;

        auto next_item2 = TRY(JS::iterator_value(vm, *next2));

    String sequence_item2;
    if (!false || !next_item2.is_null()) {
        sequence_item2 = TRY(WebIDL::to_byte_string(vm, next_item2));
    }

    sequence_item1.append(sequence_item2);
    }

    headers_value_5.append(sequence_item1);
    }


            return headers_value_5;
        }

    OrderedHashMap<String, String> record_union_type;

    auto record_keys1 = TRY(headers_property_value_5_object.internal_own_property_keys());

    for (auto& key1 : record_keys1) {
        auto property_key1 = MUST(JS::PropertyKey::from_value(vm, key1));

        auto descriptor1 = TRY(headers_property_value_5_object.internal_get_own_property(property_key1));

        if (!descriptor1.has_value() || !descriptor1->enumerable.has_value() || !descriptor1->enumerable.value())
            continue;

    String typed_key1;
    if (!false || !key1.is_null()) {
        typed_key1 = TRY(WebIDL::to_byte_string(vm, key1));
    }

        auto value1 = TRY(headers_property_value_5_object.get(property_key1));

    String typed_value1;
    if (!false || !value1.is_null()) {
        typed_value1 = TRY(WebIDL::to_byte_string(vm, value1));
    }

        record_union_type.set(typed_key1, typed_value1);
    }

        return record_union_type;

        }

        return vm.throw_completion<JS::TypeError>("No union types matched"sv);

    };

    Optional<Variant<Vector<Vector<String>>, OrderedHashMap<String, String>>> headers_value_5;
    if (!headers_property_value_5.is_undefined())
        headers_value_5 = TRY(headers_property_value_5_to_variant(headers_property_value_5));

    init.headers = headers_value_5;

    }

    auto integrity_property_value_6 = JS::js_undefined();
    if (arg1.is_object())
        integrity_property_value_6 = TRY(arg1.as_object().get("integrity"));

    if (!integrity_property_value_6.is_undefined()) {

    Optional<String> integrity_value_6;

    if (!integrity_property_value_6.is_undefined()) {
        if (!false || !integrity_property_value_6.is_null())
            integrity_value_6 = TRY(WebIDL::to_string(vm, integrity_property_value_6));
    }

    init.integrity = integrity_value_6;

    }

    auto keepalive_property_value_7 = JS::js_undefined();
    if (arg1.is_object())
        keepalive_property_value_7 = TRY(arg1.as_object().get("keepalive"));

    if (!keepalive_property_value_7.is_undefined()) {

    Optional<bool> keepalive_value_7;

    if (!keepalive_property_value_7.is_undefined())

    keepalive_value_7 = keepalive_property_value_7.to_boolean();

    init.keepalive = keepalive_value_7;

    }

    auto method_property_value_8 = JS::js_undefined();
    if (arg1.is_object())
        method_property_value_8 = TRY(arg1.as_object().get("method"));

    if (!method_property_value_8.is_undefined()) {

    Optional<String> method_value_8;

    if (!method_property_value_8.is_undefined()) {
        if (!false || !method_property_value_8.is_null())
            method_value_8 = TRY(WebIDL::to_byte_string(vm, method_property_value_8));
    }

    init.method = method_value_8;

    }

    auto mode_property_value_9 = JS::js_undefined();
    if (arg1.is_object())
        mode_property_value_9 = TRY(arg1.as_object().get("mode"));

    if (!mode_property_value_9.is_undefined()) {

    RequestMode mode_value_9 { RequestMode::Navigate };

    if (!mode_property_value_9.is_undefined()) {

    auto mode_property_value_9_string = TRY(mode_property_value_9.to_string(vm));

    if (mode_property_value_9_string == "navigate"sv)
        mode_value_9 = RequestMode::Navigate;

    else if (mode_property_value_9_string == "same-origin"sv)
        mode_value_9 = RequestMode::SameOrigin;

    else if (mode_property_value_9_string == "no-cors"sv)
        mode_value_9 = RequestMode::NoCors;

    else if (mode_property_value_9_string == "cors"sv)
        mode_value_9 = RequestMode::Cors;

    else
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidEnumerationValue, mode_property_value_9_string, "RequestMode");

    }

    init.mode = mode_value_9;

    }

    auto priority_property_value_10 = JS::js_undefined();
    if (arg1.is_object())
        priority_property_value_10 = TRY(arg1.as_object().get("priority"));

    if (!priority_property_value_10.is_undefined()) {

    RequestPriority priority_value_10 { RequestPriority::High };

    if (!priority_property_value_10.is_undefined()) {

    auto priority_property_value_10_string = TRY(priority_property_value_10.to_string(vm));

    if (priority_property_value_10_string == "high"sv)
        priority_value_10 = RequestPriority::High;

    else if (priority_property_value_10_string == "low"sv)
        priority_value_10 = RequestPriority::Low;

    else if (priority_property_value_10_string == "auto"sv)
        priority_value_10 = RequestPriority::Auto;

    else
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidEnumerationValue, priority_property_value_10_string, "RequestPriority");

    }

    init.priority = priority_value_10;

    }

    auto redirect_property_value_11 = JS::js_undefined();
    if (arg1.is_object())
        redirect_property_value_11 = TRY(arg1.as_object().get("redirect"));

    if (!redirect_property_value_11.is_undefined()) {

    RequestRedirect redirect_value_11 { RequestRedirect::Follow };

    if (!redirect_property_value_11.is_undefined()) {

    auto redirect_property_value_11_string = TRY(redirect_property_value_11.to_string(vm));

    if (redirect_property_value_11_string == "follow"sv)
        redirect_value_11 = RequestRedirect::Follow;

    else if (redirect_property_value_11_string == "error"sv)
        redirect_value_11 = RequestRedirect::Error;

    else if (redirect_property_value_11_string == "manual"sv)
        redirect_value_11 = RequestRedirect::Manual;

    else
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidEnumerationValue, redirect_property_value_11_string, "RequestRedirect");

    }

    init.redirect = redirect_value_11;

    }

    auto referrer_property_value_12 = JS::js_undefined();
    if (arg1.is_object())
        referrer_property_value_12 = TRY(arg1.as_object().get("referrer"));

    if (!referrer_property_value_12.is_undefined()) {

    Optional<String> referrer_value_12;

    if (!referrer_property_value_12.is_undefined()) {
        if (!false || !referrer_property_value_12.is_null())
            referrer_value_12 = TRY(WebIDL::to_usv_string(vm, referrer_property_value_12));
    }

    init.referrer = referrer_value_12;

    }

    auto referrer_policy_property_value_13 = JS::js_undefined();
    if (arg1.is_object())
        referrer_policy_property_value_13 = TRY(arg1.as_object().get("referrerPolicy"));

    if (!referrer_policy_property_value_13.is_undefined()) {

    ReferrerPolicy referrer_policy_value_13 { ReferrerPolicy::NoReferrer };

    if (!referrer_policy_property_value_13.is_undefined()) {

    auto referrer_policy_property_value_13_string = TRY(referrer_policy_property_value_13.to_string(vm));

    if (referrer_policy_property_value_13_string == ""sv)
        referrer_policy_value_13 = ReferrerPolicy::Empty;

    else if (referrer_policy_property_value_13_string == "no-referrer"sv)
        referrer_policy_value_13 = ReferrerPolicy::NoReferrer;

    else if (referrer_policy_property_value_13_string == "no-referrer-when-downgrade"sv)
        referrer_policy_value_13 = ReferrerPolicy::NoReferrerWhenDowngrade;

    else if (referrer_policy_property_value_13_string == "same-origin"sv)
        referrer_policy_value_13 = ReferrerPolicy::SameOrigin;

    else if (referrer_policy_property_value_13_string == "origin"sv)
        referrer_policy_value_13 = ReferrerPolicy::Origin;

    else if (referrer_policy_property_value_13_string == "strict-origin"sv)
        referrer_policy_value_13 = ReferrerPolicy::StrictOrigin;

    else if (referrer_policy_property_value_13_string == "origin-when-cross-origin"sv)
        referrer_policy_value_13 = ReferrerPolicy::OriginWhenCrossOrigin;

    else if (referrer_policy_property_value_13_string == "strict-origin-when-cross-origin"sv)
        referrer_policy_value_13 = ReferrerPolicy::StrictOriginWhenCrossOrigin;

    else if (referrer_policy_property_value_13_string == "unsafe-url"sv)
        referrer_policy_value_13 = ReferrerPolicy::UnsafeUrl;

    else
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidEnumerationValue, referrer_policy_property_value_13_string, "ReferrerPolicy");

    }

    init.referrer_policy = referrer_policy_value_13;

    }

    auto signal_property_value_14 = JS::js_undefined();
    if (arg1.is_object())
        signal_property_value_14 = TRY(arg1.as_object().get("signal"));

    if (!signal_property_value_14.is_undefined()) {

    GC::Ptr<AbortSignal> signal_value_14;

    if (!signal_property_value_14.is_nullish()) {
        if (!signal_property_value_14.is_object() || !is<AbortSignal>(signal_property_value_14.as_object()))
            return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "AbortSignal");

        signal_value_14 = &static_cast<AbortSignal&>(signal_property_value_14.as_object());
    }

    init.signal = signal_value_14;

    }

    auto window_property_value_15 = JS::js_undefined();
    if (arg1.is_object())
        window_property_value_15 = TRY(arg1.as_object().get("window"));

    if (!window_property_value_15.is_undefined()) {

    JS::Value window_value_15 = JS::js_undefined();
    if (!window_property_value_15.is_undefined())
        window_value_15 = window_property_value_15;

    init.window = window_value_15;

    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->fetch(input, init); }));

        return retval;
    };

    auto maybe_retval = steps();

    // And then, if an exception E was thrown:
    // 1. If op has a return type that is a promise type, then return ! Call(%Promise.reject%, %Promise%, «E»).
    // 2. Otherwise, end these steps and allow the exception to propagate.
    // NOTE: We know that this is a Promise return type statically by the IDL.
    if (maybe_retval.is_throw_completion())
        return WebIDL::create_rejected_promise(realm, maybe_retval.error_value())->promise();

    auto retval = maybe_retval.release_value();

    return GC::Ref { as<JS::Promise>(*retval->promise()) };

}

JS_DEFINE_NATIVE_FUNCTION(WorkerGlobalScopePrototype::create_image_bitmap)
{
    WebIDL::log_trace(vm, "WorkerGlobalScopePrototype::create_image_bitmap");

    Optional<IDL::EffectiveOverloadSet> effective_overload_set;
    switch (min(6, vm.argument_count())) {

    case 1: {
        Vector<IDL::EffectiveOverloadSet::Item> overloads;
        overloads.ensure_capacity(1);

        overloads.empend(0, Vector<NonnullRefPtr<IDL::Type const>> { make_ref_counted<IDL::UnionType>("", false, Vector<NonnullRefPtr<IDL::Type const>> {make_ref_counted<IDL::UnionType>("", false, Vector<NonnullRefPtr<IDL::Type const>> {make_ref_counted<IDL::Type>("HTMLImageElement", false), make_ref_counted<IDL::Type>("SVGImageElement", false), make_ref_counted<IDL::Type>("HTMLVideoElement", false), make_ref_counted<IDL::Type>("HTMLCanvasElement", false), make_ref_counted<IDL::Type>("ImageBitmap", false)}), make_ref_counted<IDL::Type>("Blob", false), make_ref_counted<IDL::Type>("ImageData", false)})}, Vector<IDL::Optionality> { IDL::Optionality::Required});

        effective_overload_set.emplace(move(overloads), 0);
        break;
    }

    case 2: {
        Vector<IDL::EffectiveOverloadSet::Item> overloads;
        overloads.ensure_capacity(1);

        overloads.empend(0, Vector<NonnullRefPtr<IDL::Type const>> { make_ref_counted<IDL::UnionType>("", false, Vector<NonnullRefPtr<IDL::Type const>> {make_ref_counted<IDL::UnionType>("", false, Vector<NonnullRefPtr<IDL::Type const>> {make_ref_counted<IDL::Type>("HTMLImageElement", false), make_ref_counted<IDL::Type>("SVGImageElement", false), make_ref_counted<IDL::Type>("HTMLVideoElement", false), make_ref_counted<IDL::Type>("HTMLCanvasElement", false), make_ref_counted<IDL::Type>("ImageBitmap", false)}), make_ref_counted<IDL::Type>("Blob", false), make_ref_counted<IDL::Type>("ImageData", false)}), make_ref_counted<IDL::Type>("ImageBitmapOptions", false)}, Vector<IDL::Optionality> { IDL::Optionality::Required, IDL::Optionality::Optional});

        effective_overload_set.emplace(move(overloads), 0);
        break;
    }

    case 5: {
        Vector<IDL::EffectiveOverloadSet::Item> overloads;
        overloads.ensure_capacity(1);

        overloads.empend(1, Vector<NonnullRefPtr<IDL::Type const>> { make_ref_counted<IDL::UnionType>("", false, Vector<NonnullRefPtr<IDL::Type const>> {make_ref_counted<IDL::UnionType>("", false, Vector<NonnullRefPtr<IDL::Type const>> {make_ref_counted<IDL::Type>("HTMLImageElement", false), make_ref_counted<IDL::Type>("SVGImageElement", false), make_ref_counted<IDL::Type>("HTMLVideoElement", false), make_ref_counted<IDL::Type>("HTMLCanvasElement", false), make_ref_counted<IDL::Type>("ImageBitmap", false)}), make_ref_counted<IDL::Type>("Blob", false), make_ref_counted<IDL::Type>("ImageData", false)}), make_ref_counted<IDL::Type>("long", false), make_ref_counted<IDL::Type>("long", false), make_ref_counted<IDL::Type>("long", false), make_ref_counted<IDL::Type>("long", false)}, Vector<IDL::Optionality> { IDL::Optionality::Required, IDL::Optionality::Required, IDL::Optionality::Required, IDL::Optionality::Required, IDL::Optionality::Required});

        effective_overload_set.emplace(move(overloads), 0);
        break;
    }

    case 6: {
        Vector<IDL::EffectiveOverloadSet::Item> overloads;
        overloads.ensure_capacity(1);

        overloads.empend(1, Vector<NonnullRefPtr<IDL::Type const>> { make_ref_counted<IDL::UnionType>("", false, Vector<NonnullRefPtr<IDL::Type const>> {make_ref_counted<IDL::UnionType>("", false, Vector<NonnullRefPtr<IDL::Type const>> {make_ref_counted<IDL::Type>("HTMLImageElement", false), make_ref_counted<IDL::Type>("SVGImageElement", false), make_ref_counted<IDL::Type>("HTMLVideoElement", false), make_ref_counted<IDL::Type>("HTMLCanvasElement", false), make_ref_counted<IDL::Type>("ImageBitmap", false)}), make_ref_counted<IDL::Type>("Blob", false), make_ref_counted<IDL::Type>("ImageData", false)}), make_ref_counted<IDL::Type>("long", false), make_ref_counted<IDL::Type>("long", false), make_ref_counted<IDL::Type>("long", false), make_ref_counted<IDL::Type>("long", false), make_ref_counted<IDL::Type>("ImageBitmapOptions", false)}, Vector<IDL::Optionality> { IDL::Optionality::Required, IDL::Optionality::Required, IDL::Optionality::Required, IDL::Optionality::Required, IDL::Optionality::Required, IDL::Optionality::Optional});

        effective_overload_set.emplace(move(overloads), 0);
        break;
    }

    }

    Vector<StringView> dictionary_types {
    "ImageBitmapOptions"sv,
};


    if (!effective_overload_set.has_value())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::OverloadResolutionFailed);

    auto chosen_overload = TRY(WebIDL::resolve_overload(vm, effective_overload_set.value(), dictionary_types));
    switch (chosen_overload.callable_id) {

    case 0:

        return create_image_bitmap0(vm);

    case 1:

        return create_image_bitmap1(vm);

    default:
        VERIFY_NOT_REACHED();
    }
}

} // namespace Web::Bindings
