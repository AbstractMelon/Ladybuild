
#include <AK/Function.h>
#include <LibIDL/Types.h>
#include <LibJS/Runtime/Array.h>
#include <LibJS/Runtime/ArrayBuffer.h>
#include <LibJS/Runtime/DataView.h>
#include <LibJS/Runtime/Error.h>
#include <LibJS/Runtime/FunctionObject.h>
#include <LibJS/Runtime/GlobalObject.h>
#include <LibJS/Runtime/Iterator.h>
#include <LibJS/Runtime/PromiseConstructor.h>
#include <LibJS/Runtime/TypedArray.h>
#include <LibJS/Runtime/Value.h>
#include <LibJS/Runtime/ValueInlines.h>
#include <LibURL/Origin.h>
#include <LibWeb/Bindings/ElementPrototype.h>
#include <LibWeb/Bindings/ExceptionOrUtils.h>
#include <LibWeb/Bindings/Intrinsics.h>
#include <LibWeb/DOM/Element.h>
#include <LibWeb/DOM/Event.h>
#include <LibWeb/DOM/IDLEventListener.h>
#include <LibWeb/DOM/NodeFilter.h>
#include <LibWeb/DOM/Range.h>
#include <LibWeb/HTML/Numbers.h>
#include <LibWeb/HTML/Scripting/Agent.h>
#include <LibWeb/HTML/Scripting/Environments.h>
#include <LibWeb/HTML/Window.h>
#include <LibWeb/HTML/WindowProxy.h>
#include <LibWeb/Infra/Strings.h>
#include <LibWeb/WebIDL/AbstractOperations.h>
#include <LibWeb/WebIDL/Buffers.h>
#include <LibWeb/WebIDL/OverloadResolution.h>
#include <LibWeb/WebIDL/Promise.h>
#include <LibWeb/WebIDL/Tracing.h>
#include <LibWeb/WebIDL/Types.h>

#if __has_include(<LibWeb/Bindings/NodePrototype.h>)
#    include <LibWeb/Bindings/NodePrototype.h>
#endif


#include <LibWeb/Bindings/MainThreadVM.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Element.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Attr.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/DOMTokenList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/NamedNodeMap.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Node.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/NodeList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/ShadowRoot.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMRect.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMRectList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLSlotElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Window.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Animations/Animation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Animations/KeyframeEffect.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Document.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/EventTarget.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/HTMLCollection.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/DocumentFragment.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMRectReadOnly.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Text.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/MediaQueryList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/Screen.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/VisualViewport.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/CustomElements/CustomElementRegistry.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/History.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Navigation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Navigator.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Animations/AnimationEffect.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Animations/AnimationTimeline.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Animations/DocumentTimeline.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/FontFaceSet.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/StyleSheetList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/CDATASection.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Comment.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/DOMImplementation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/DocumentType.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Event.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/NodeFilter.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/NodeIterator.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/ProcessingInstruction.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Range.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/TreeWalker.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLAllCollection.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLHeadElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLScriptElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Location.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Selection/Selection.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/AbortSignal.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/CharacterData.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/DOMStringMap.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/ElementInternals.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/ScreenOrientation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/NavigationHistoryEntry.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/NavigationTransition.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Clipboard/Clipboard.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CredentialManagement/CredentialsContainer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/MimeTypeArray.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/PluginArray.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/UserActivation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/MediaCapabilitiesAPI/MediaCapabilities.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/ServiceWorker/ServiceWorkerContainer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/MessagePort.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Storage.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Crypto/Crypto.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Fetch/Request.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Fetch/Response.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HighResolutionTime/Performance.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/ImageBitmap.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/IndexedDB/IDBFactory.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/RequestIdleCallback/IdleDeadline.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/FontFace.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/CSSStyleSheet.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/XMLDocument.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/AbstractRange.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Scripting/Fetching.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/CSSStyleDeclaration.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/NavigationType.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CredentialManagement/Credential.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CredentialManagement/FederatedCredential.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CredentialManagement/PasswordCredential.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/MimeType.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Plugin.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/EncryptedMediaExtensions/EncryptedMediaExtensions.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Worker.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/ServiceWorker/ServiceWorkerRegistration.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/StorageAPI/StorageManager.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Crypto/SubtleCrypto.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Fetch/Headers.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/NavigationTiming/PerformanceNavigation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/NavigationTiming/PerformanceTiming.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/PerformanceTimeline/PerformanceEntry.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/UserTiming/PerformanceMark.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/UserTiming/PerformanceMeasure.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/FileAPI/Blob.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/ImageData.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/CanvasRenderingContext2D.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/CSSRule.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/CSSRuleList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/MediaList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/StyleSheet.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/ReadableStream.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOMURL/URLSearchParams.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/XHR/FormData.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/ServiceWorker/ServiceWorker.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Crypto/CryptoKey.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLCanvasElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Canvas/CanvasDrawPath.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Canvas/CanvasTextDrawingStyles.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLImageElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLVideoElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGImageElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/ReadableStreamBYOBReader.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/ReadableStreamDefaultReader.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/WritableStream.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/FileAPI/File.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLRenderingContext.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGL2RenderingContext.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Path2D.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/CanvasGradient.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/CanvasPattern.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMPointReadOnly.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/TextMetrics.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMMatrix.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLMediaElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGGraphicsElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/WritableStreamDefaultWriter.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMMatrixReadOnly.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMPoint.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/AudioTrackList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/MediaError.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/TextTrack.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/TextTrackList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/TimeRanges.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/VideoTrackList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGAnimatedString.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLActiveInfo.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLBuffer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLFramebuffer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLObject.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLProgram.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLRenderbuffer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLShader.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLShaderPrecisionFormat.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLTexture.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLUniformLocation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLQuery.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLSampler.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLSync.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLTransformFeedback.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLVertexArrayObject.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/AudioTrack.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/VideoTrack.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGSVGElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGAnimatedRect.h>

// FIXME: This is a total hack until we can figure out the namespace for a given type somehow.
using namespace Web::Animations;
using namespace Web::Clipboard;
using namespace Web::CredentialManagement;
using namespace Web::Crypto;
using namespace Web::CSS;
using namespace Web::DOM;
using namespace Web::DOMURL;
using namespace Web::Encoding;
using namespace Web::EntriesAPI;
using namespace Web::EventTiming;
using namespace Web::Fetch;
using namespace Web::FileAPI;
using namespace Web::Geometry;
using namespace Web::HighResolutionTime;
using namespace Web::HTML;
using namespace Web::IndexedDB;
using namespace Web::Internals;
using namespace Web::IntersectionObserver;
using namespace Web::MediaCapabilitiesAPI;
using namespace Web::MediaSourceExtensions;
using namespace Web::NavigationTiming;
using namespace Web::PerformanceTimeline;
using namespace Web::RequestIdleCallback;
using namespace Web::ResizeObserver;
using namespace Web::Selection;
using namespace Web::ServiceWorker;
using namespace Web::StorageAPI;
using namespace Web::Streams;
using namespace Web::SVG;
using namespace Web::UIEvents;
using namespace Web::URLPattern;
using namespace Web::UserTiming;
using namespace Web::WebAssembly;
using namespace Web::WebAudio;
using namespace Web::WebGL;
using namespace Web::WebGL::Extensions;
using namespace Web::WebIDL;
using namespace Web::WebVTT;
using namespace Web::XHR;

namespace Web::Bindings {

GC_DEFINE_ALLOCATOR(ElementPrototype);

ElementPrototype::ElementPrototype([[maybe_unused]] JS::Realm& realm)
    : Object(realm, nullptr)

{
}

ElementPrototype::~ElementPrototype()
{
}

void ElementPrototype::initialize(JS::Realm& realm)
{


    [[maybe_unused]] auto& vm = realm.vm();
    [[maybe_unused]] u8 default_attributes = JS::Attribute::Enumerable | JS::Attribute::Configurable | JS::Attribute::Writable;



    set_prototype(&ensure_web_prototype<NodePrototype>(realm, "Node"_fly_string));


    auto unscopable_object = JS::Object::create(realm, nullptr);

    define_native_accessor(realm, "namespaceURI", namespace_uri_getter, nullptr, default_attributes);

    define_native_accessor(realm, "prefix", prefix_getter, nullptr, default_attributes);

    define_native_accessor(realm, "localName", local_name_getter, nullptr, default_attributes);

    define_native_accessor(realm, "tagName", tag_name_getter, nullptr, default_attributes);

    define_native_accessor(realm, "id", id_getter, id_setter, default_attributes);

    define_native_accessor(realm, "className", class_name_getter, class_name_setter, default_attributes);

    define_native_accessor(realm, "classList", class_list_getter, class_list_setter, default_attributes);

    MUST(unscopable_object->create_data_property("slot", JS::Value(true)));

    define_native_accessor(realm, "slot", slot_getter, slot_setter, default_attributes);

    define_native_accessor(realm, "attributes", attributes_getter, nullptr, default_attributes);

    define_native_accessor(realm, "shadowRoot", shadow_root_getter, nullptr, default_attributes);

    define_native_accessor(realm, "nextElementSibling", next_element_sibling_getter, nullptr, default_attributes);

    define_native_accessor(realm, "previousElementSibling", previous_element_sibling_getter, nullptr, default_attributes);

    define_native_accessor(realm, "scrollTop", scroll_top_getter, scroll_top_setter, default_attributes);

    define_native_accessor(realm, "scrollLeft", scroll_left_getter, scroll_left_setter, default_attributes);

    define_native_accessor(realm, "scrollWidth", scroll_width_getter, nullptr, default_attributes);

    define_native_accessor(realm, "scrollHeight", scroll_height_getter, nullptr, default_attributes);

    define_native_accessor(realm, "clientTop", client_top_getter, nullptr, default_attributes);

    define_native_accessor(realm, "clientLeft", client_left_getter, nullptr, default_attributes);

    define_native_accessor(realm, "clientWidth", client_width_getter, nullptr, default_attributes);

    define_native_accessor(realm, "clientHeight", client_height_getter, nullptr, default_attributes);

    define_native_accessor(realm, "currentCSSZoom", current_css_zoom_getter, nullptr, default_attributes);

    define_native_accessor(realm, "innerHTML", inner_html_getter, inner_html_setter, default_attributes);

    define_native_accessor(realm, "outerHTML", outer_html_getter, outer_html_setter, default_attributes);

    define_native_accessor(realm, "assignedSlot", assigned_slot_getter, nullptr, default_attributes);

    define_native_accessor(realm, "role", role_getter, role_setter, default_attributes);

    define_native_accessor(realm, "ariaActiveDescendantElement", aria_active_descendant_element_getter, aria_active_descendant_element_setter, default_attributes);

    define_native_accessor(realm, "ariaAtomic", aria_atomic_getter, aria_atomic_setter, default_attributes);

    define_native_accessor(realm, "ariaAutoComplete", aria_auto_complete_getter, aria_auto_complete_setter, default_attributes);

    define_native_accessor(realm, "ariaBrailleLabel", aria_braille_label_getter, aria_braille_label_setter, default_attributes);

    define_native_accessor(realm, "ariaBrailleRoleDescription", aria_braille_role_description_getter, aria_braille_role_description_setter, default_attributes);

    define_native_accessor(realm, "ariaBusy", aria_busy_getter, aria_busy_setter, default_attributes);

    define_native_accessor(realm, "ariaChecked", aria_checked_getter, aria_checked_setter, default_attributes);

    define_native_accessor(realm, "ariaColCount", aria_col_count_getter, aria_col_count_setter, default_attributes);

    define_native_accessor(realm, "ariaColIndex", aria_col_index_getter, aria_col_index_setter, default_attributes);

    define_native_accessor(realm, "ariaColIndexText", aria_col_index_text_getter, aria_col_index_text_setter, default_attributes);

    define_native_accessor(realm, "ariaColSpan", aria_col_span_getter, aria_col_span_setter, default_attributes);

    define_native_accessor(realm, "ariaCurrent", aria_current_getter, aria_current_setter, default_attributes);

    define_native_accessor(realm, "ariaDescription", aria_description_getter, aria_description_setter, default_attributes);

    define_native_accessor(realm, "ariaDisabled", aria_disabled_getter, aria_disabled_setter, default_attributes);

    define_native_accessor(realm, "ariaExpanded", aria_expanded_getter, aria_expanded_setter, default_attributes);

    define_native_accessor(realm, "ariaHasPopup", aria_has_popup_getter, aria_has_popup_setter, default_attributes);

    define_native_accessor(realm, "ariaHidden", aria_hidden_getter, aria_hidden_setter, default_attributes);

    define_native_accessor(realm, "ariaInvalid", aria_invalid_getter, aria_invalid_setter, default_attributes);

    define_native_accessor(realm, "ariaKeyShortcuts", aria_key_shortcuts_getter, aria_key_shortcuts_setter, default_attributes);

    define_native_accessor(realm, "ariaLabel", aria_label_getter, aria_label_setter, default_attributes);

    define_native_accessor(realm, "ariaLevel", aria_level_getter, aria_level_setter, default_attributes);

    define_native_accessor(realm, "ariaLive", aria_live_getter, aria_live_setter, default_attributes);

    define_native_accessor(realm, "ariaModal", aria_modal_getter, aria_modal_setter, default_attributes);

    define_native_accessor(realm, "ariaMultiLine", aria_multi_line_getter, aria_multi_line_setter, default_attributes);

    define_native_accessor(realm, "ariaMultiSelectable", aria_multi_selectable_getter, aria_multi_selectable_setter, default_attributes);

    define_native_accessor(realm, "ariaOrientation", aria_orientation_getter, aria_orientation_setter, default_attributes);

    define_native_accessor(realm, "ariaPlaceholder", aria_placeholder_getter, aria_placeholder_setter, default_attributes);

    define_native_accessor(realm, "ariaPosInSet", aria_pos_in_set_getter, aria_pos_in_set_setter, default_attributes);

    define_native_accessor(realm, "ariaPressed", aria_pressed_getter, aria_pressed_setter, default_attributes);

    define_native_accessor(realm, "ariaReadOnly", aria_read_only_getter, aria_read_only_setter, default_attributes);

    define_native_accessor(realm, "ariaRelevant", aria_relevant_getter, aria_relevant_setter, default_attributes);

    define_native_accessor(realm, "ariaRequired", aria_required_getter, aria_required_setter, default_attributes);

    define_native_accessor(realm, "ariaRoleDescription", aria_role_description_getter, aria_role_description_setter, default_attributes);

    define_native_accessor(realm, "ariaRowCount", aria_row_count_getter, aria_row_count_setter, default_attributes);

    define_native_accessor(realm, "ariaRowIndex", aria_row_index_getter, aria_row_index_setter, default_attributes);

    define_native_accessor(realm, "ariaRowIndexText", aria_row_index_text_getter, aria_row_index_text_setter, default_attributes);

    define_native_accessor(realm, "ariaRowSpan", aria_row_span_getter, aria_row_span_setter, default_attributes);

    define_native_accessor(realm, "ariaSelected", aria_selected_getter, aria_selected_setter, default_attributes);

    define_native_accessor(realm, "ariaSetSize", aria_set_size_getter, aria_set_size_setter, default_attributes);

    define_native_accessor(realm, "ariaSort", aria_sort_getter, aria_sort_setter, default_attributes);

    define_native_accessor(realm, "ariaValueMax", aria_value_max_getter, aria_value_max_setter, default_attributes);

    define_native_accessor(realm, "ariaValueMin", aria_value_min_getter, aria_value_min_setter, default_attributes);

    define_native_accessor(realm, "ariaValueNow", aria_value_now_getter, aria_value_now_setter, default_attributes);

    define_native_accessor(realm, "ariaValueText", aria_value_text_getter, aria_value_text_setter, default_attributes);

    define_native_accessor(realm, "children", children_getter, nullptr, default_attributes);

    define_native_accessor(realm, "firstElementChild", first_element_child_getter, nullptr, default_attributes);

    define_native_accessor(realm, "lastElementChild", last_element_child_getter, nullptr, default_attributes);

    define_native_accessor(realm, "childElementCount", child_element_count_getter, nullptr, default_attributes);

    MUST(unscopable_object->create_data_property("replaceWith", JS::Value(true)));

    define_native_function(realm, "replaceWith", replace_with, 0, default_attributes);

    MUST(unscopable_object->create_data_property("remove", JS::Value(true)));

    define_native_function(realm, "remove", remove, 0, default_attributes);

    define_native_function(realm, "getAnimations", get_animations, 0, default_attributes);

    define_native_function(realm, "getElementsByTagNameNS", get_elements_by_tag_name_ns, 2, default_attributes);

    MUST(unscopable_object->create_data_property("prepend", JS::Value(true)));

    define_native_function(realm, "prepend", prepend, 0, default_attributes);

    define_native_function(realm, "getBoundingClientRect", get_bounding_client_rect, 0, default_attributes);

    define_native_function(realm, "getAttributeNodeNS", get_attribute_node_ns, 2, default_attributes);

    define_native_function(realm, "toggleAttribute", toggle_attribute, 1, default_attributes);

    define_native_function(realm, "getAttributeNames", get_attribute_names, 0, default_attributes);

    define_native_function(realm, "animate", animate, 1, default_attributes);

    define_native_function(realm, "webkitMatchesSelector", webkit_matches_selector, 1, default_attributes);

    MUST(unscopable_object->create_data_property("before", JS::Value(true)));

    define_native_function(realm, "before", before, 0, default_attributes);

    define_native_function(realm, "attachShadow", attach_shadow, 1, default_attributes);

    define_native_function(realm, "getHTML", get_html, 0, default_attributes);

    define_native_function(realm, "setHTMLUnsafe", set_html_unsafe, 1, default_attributes);

    define_native_function(realm, "setAttributeNode", set_attribute_node, 1, default_attributes);

    define_native_function(realm, "setAttribute", set_attribute, 2, default_attributes);

    define_native_function(realm, "hasAttributes", has_attributes, 0, default_attributes);

    MUST(unscopable_object->create_data_property("replaceChildren", JS::Value(true)));

    define_native_function(realm, "replaceChildren", replace_children, 0, default_attributes);

    define_native_function(realm, "insertAdjacentHTML", insert_adjacent_html, 2, default_attributes);

    define_native_function(realm, "scroll", scroll, 0, default_attributes);

    define_native_function(realm, "getAttribute", get_attribute, 1, default_attributes);

    define_native_function(realm, "scrollIntoView", scroll_into_view, 0, default_attributes);

    define_native_function(realm, "closest", closest, 1, default_attributes);

    define_native_function(realm, "hasAttributeNS", has_attribute_ns, 2, default_attributes);

    define_native_function(realm, "scrollTo", scroll_to, 0, default_attributes);

    MUST(unscopable_object->create_data_property("append", JS::Value(true)));

    define_native_function(realm, "append", append, 0, default_attributes);

    define_native_function(realm, "getAttributeNS", get_attribute_ns, 2, default_attributes);

    MUST(unscopable_object->create_data_property("after", JS::Value(true)));

    define_native_function(realm, "after", after, 0, default_attributes);

    define_native_function(realm, "scrollBy", scroll_by, 0, default_attributes);

    define_native_function(realm, "setAttributeNodeNS", set_attribute_node_ns, 1, default_attributes);

    define_native_function(realm, "insertAdjacentText", insert_adjacent_text, 2, default_attributes);

    define_native_function(realm, "getElementsByClassName", get_elements_by_class_name, 1, default_attributes);

    define_native_function(realm, "hasAttribute", has_attribute, 1, default_attributes);

    define_native_function(realm, "removeAttribute", remove_attribute, 1, default_attributes);

    define_native_function(realm, "setAttributeNS", set_attribute_ns, 3, default_attributes);

    define_native_function(realm, "getAttributeNode", get_attribute_node, 1, default_attributes);

    define_native_function(realm, "matches", matches, 1, default_attributes);

    define_native_function(realm, "getElementsByTagName", get_elements_by_tag_name, 1, default_attributes);

    define_native_function(realm, "querySelector", query_selector, 1, default_attributes);

    define_native_function(realm, "checkVisibility", check_visibility, 0, default_attributes);

    define_native_function(realm, "getClientRects", get_client_rects, 0, default_attributes);

    define_native_function(realm, "removeAttributeNode", remove_attribute_node, 1, default_attributes);

    define_native_function(realm, "insertAdjacentElement", insert_adjacent_element, 2, default_attributes);

    define_native_function(realm, "querySelectorAll", query_selector_all, 1, default_attributes);

    define_native_function(realm, "removeAttributeNS", remove_attribute_ns, 2, default_attributes);

    define_direct_property(vm.well_known_symbol_unscopables(), unscopable_object, JS::Attribute::Configurable);

    define_direct_property(vm.well_known_symbol_to_string_tag(), JS::PrimitiveString::create(vm, "Element"_string), JS::Attribute::Configurable);

    Base::initialize(realm);

}

[[maybe_unused]] static JS::ThrowCompletionOr<DOM::Element*> impl_from(JS::VM& vm)
{
    auto this_value = vm.this_value();
    JS::Object* this_object = nullptr;
    if (this_value.is_nullish())
        this_object = &vm.current_realm()->global_object();
    else
        this_object = TRY(this_value.to_object(vm));

    if (!is<DOM::Element>(this_object))
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "Element");
    return static_cast<DOM::Element*>(this_object);
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::namespace_uri_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::namespace_uri_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->namespace_uri(); }));

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::prefix_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::prefix_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->prefix(); }));

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::local_name_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::local_name_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->local_name(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::tag_name_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::tag_name_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->tag_name(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::id_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::id_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto contentAttributeValue = impl->attribute("id"_fly_string);

    auto retval = contentAttributeValue.value_or(String {});

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::id_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::id_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    String cpp_value;
    if (!false || !value.is_null()) {
        cpp_value = TRY(WebIDL::to_string(vm, value));
    }

MUST(impl->set_attribute("id"_fly_string, cpp_value));

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::class_name_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::class_name_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto contentAttributeValue = impl->attribute("class"_fly_string);

    auto retval = contentAttributeValue.value_or(String {});

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::class_name_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::class_name_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    String cpp_value;
    if (!false || !value.is_null()) {
        cpp_value = TRY(WebIDL::to_string(vm, value));
    }

MUST(impl->set_attribute("class"_fly_string, cpp_value));

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::class_list_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::class_list_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->class_list(); }));

    return &const_cast<DOMTokenList&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::class_list_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::class_list_setter");
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");
    auto value = vm.argument(0);

    auto receiver = TRY(throw_dom_exception_if_needed(vm, [&]() { return impl->class_list(); }));
    TRY(receiver->set(JS::PropertyKey { "value", JS::PropertyKey::StringMayBeNumber::No }, value, JS::Object::ShouldThrowExceptions::Yes));

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::slot_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::slot_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto contentAttributeValue = impl->attribute("slot"_fly_string);

    auto retval = contentAttributeValue.value_or(String {});

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::slot_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::slot_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    String cpp_value;
    if (!false || !value.is_null()) {
        cpp_value = TRY(WebIDL::to_string(vm, value));
    }

MUST(impl->set_attribute("slot"_fly_string, cpp_value));

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::attributes_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::attributes_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->attributes(); }));

    return &const_cast<NamedNodeMap&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::shadow_root_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::shadow_root_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->shadow_root_for_bindings(); }));

    if (!retval) {
        return JS::js_null();
    } else {

    return &const_cast<ShadowRoot&>(*retval);

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::next_element_sibling_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::next_element_sibling_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->next_element_sibling(); }));

    if (!retval) {
        return JS::js_null();
    } else {

    return &const_cast<Element&>(*retval);

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::previous_element_sibling_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::previous_element_sibling_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->previous_element_sibling(); }));

    if (!retval) {
        return JS::js_null();
    } else {

    return &const_cast<Element&>(*retval);

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::scroll_top_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::scroll_top_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->scroll_top(); }));

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::scroll_top_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::scroll_top_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    double cpp_value = TRY(value.to_double(vm));

    TRY(throw_dom_exception_if_needed(vm, [&] { return impl->set_scroll_top(cpp_value); }));

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::scroll_left_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::scroll_left_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->scroll_left(); }));

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::scroll_left_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::scroll_left_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    double cpp_value = TRY(value.to_double(vm));

    TRY(throw_dom_exception_if_needed(vm, [&] { return impl->set_scroll_left(cpp_value); }));

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::scroll_width_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::scroll_width_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->scroll_width(); }));

    return JS::Value(static_cast<WebIDL::Long>(retval));

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::scroll_height_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::scroll_height_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->scroll_height(); }));

    return JS::Value(static_cast<WebIDL::Long>(retval));

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::client_top_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::client_top_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->client_top(); }));

    return JS::Value(static_cast<WebIDL::Long>(retval));

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::client_left_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::client_left_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->client_left(); }));

    return JS::Value(static_cast<WebIDL::Long>(retval));

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::client_width_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::client_width_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->client_width(); }));

    return JS::Value(static_cast<WebIDL::Long>(retval));

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::client_height_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::client_height_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->client_height(); }));

    return JS::Value(static_cast<WebIDL::Long>(retval));

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::current_css_zoom_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::current_css_zoom_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->current_css_zoom(); }));

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::inner_html_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::inner_html_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->inner_html(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::inner_html_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::inner_html_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    String cpp_value;
    if (!true || !value.is_null()) {
        cpp_value = TRY(WebIDL::to_string(vm, value));
    }

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_inner_html(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::outer_html_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::outer_html_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->outer_html(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::outer_html_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::outer_html_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    String cpp_value;
    if (!true || !value.is_null()) {
        cpp_value = TRY(WebIDL::to_string(vm, value));
    }

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_outer_html(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::assigned_slot_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::assigned_slot_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->assigned_slot(); }));

    if (!retval) {
        return JS::js_null();
    } else {

    return &const_cast<HTMLSlotElement&>(*retval);

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::role_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::role_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->role(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::role_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::role_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_role(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_active_descendant_element_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_active_descendant_element_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval = GC::Ptr<Element> {};

    auto contentAttributeValue = impl->attribute("aria-activedescendant"_fly_string);

    auto const explicitly_set_attr = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->aria_active_descendant_element(); }));
    if (explicitly_set_attr) {
        if (&impl->shadow_including_root() == &explicitly_set_attr->root()) {
            retval = explicitly_set_attr;
        } else {
            retval = GC::Ptr<Element> {};
        }
    }

    else if (contentAttributeValue.has_value()) {
        impl->root().for_each_in_inclusive_subtree_of_type<DOM::Element>([&](auto& candidate) {
            if (candidate.attribute(HTML::AttributeNames::id) == contentAttributeValue.value()) {
                retval = &candidate;
                return TraversalDecision::Break;
            }
            return TraversalDecision::Continue;
        });
    }

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (!retval) {
        return JS::js_null();
    } else {

    return &const_cast<Element&>(*retval);

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_active_descendant_element_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_active_descendant_element_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    GC::Ptr<Element> cpp_value;

    if (!value.is_nullish()) {
        if (!value.is_object() || !is<Element>(value.as_object()))
            return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "Element");

        cpp_value = &static_cast<Element&>(value.as_object());
    }

    if (!cpp_value) {
        TRY(throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_active_descendant_element(nullptr); }));
        impl->remove_attribute("aria-activedescendant"_fly_string);
        return JS::js_undefined();
    }

    MUST(impl->set_attribute("aria-activedescendant"_fly_string, String {}));

    TRY(throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_active_descendant_element(cpp_value); }));

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_atomic_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_atomic_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_atomic(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_atomic_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_atomic_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_atomic(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_auto_complete_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_auto_complete_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_auto_complete(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_auto_complete_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_auto_complete_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_auto_complete(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_braille_label_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_braille_label_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_braille_label(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_braille_label_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_braille_label_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_braille_label(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_braille_role_description_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_braille_role_description_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_braille_role_description(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_braille_role_description_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_braille_role_description_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_braille_role_description(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_busy_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_busy_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_busy(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_busy_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_busy_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_busy(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_checked_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_checked_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_checked(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_checked_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_checked_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_checked(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_col_count_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_col_count_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_col_count(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_col_count_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_col_count_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_col_count(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_col_index_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_col_index_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_col_index(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_col_index_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_col_index_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_col_index(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_col_index_text_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_col_index_text_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_col_index_text(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_col_index_text_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_col_index_text_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_col_index_text(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_col_span_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_col_span_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_col_span(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_col_span_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_col_span_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_col_span(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_current_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_current_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_current(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_current_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_current_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_current(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_description_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_description_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_description(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_description_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_description_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_description(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_disabled_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_disabled_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_disabled(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_disabled_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_disabled_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_disabled(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_expanded_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_expanded_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_expanded(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_expanded_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_expanded_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_expanded(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_has_popup_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_has_popup_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_has_popup(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_has_popup_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_has_popup_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_has_popup(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_hidden_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_hidden_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_hidden(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_hidden_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_hidden_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_hidden(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_invalid_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_invalid_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_invalid(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_invalid_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_invalid_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_invalid(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_key_shortcuts_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_key_shortcuts_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_key_shortcuts(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_key_shortcuts_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_key_shortcuts_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_key_shortcuts(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_label_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_label_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_label(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_label_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_label_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_label(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_level_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_level_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_level(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_level_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_level_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_level(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_live_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_live_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_live(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_live_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_live_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_live(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_modal_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_modal_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_modal(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_modal_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_modal_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_modal(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_multi_line_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_multi_line_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_multi_line(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_multi_line_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_multi_line_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_multi_line(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_multi_selectable_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_multi_selectable_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_multi_selectable(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_multi_selectable_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_multi_selectable_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_multi_selectable(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_orientation_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_orientation_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_orientation(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_orientation_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_orientation_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_orientation(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_placeholder_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_placeholder_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_placeholder(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_placeholder_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_placeholder_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_placeholder(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_pos_in_set_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_pos_in_set_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_pos_in_set(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_pos_in_set_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_pos_in_set_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_pos_in_set(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_pressed_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_pressed_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_pressed(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_pressed_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_pressed_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_pressed(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_read_only_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_read_only_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_read_only(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_read_only_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_read_only_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_read_only(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_relevant_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_relevant_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_relevant(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_relevant_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_relevant_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_relevant(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_required_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_required_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_required(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_required_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_required_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_required(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_role_description_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_role_description_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_role_description(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_role_description_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_role_description_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_role_description(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_row_count_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_row_count_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_row_count(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_row_count_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_row_count_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_row_count(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_row_index_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_row_index_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_row_index(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_row_index_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_row_index_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_row_index(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_row_index_text_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_row_index_text_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_row_index_text(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_row_index_text_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_row_index_text_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_row_index_text(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_row_span_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_row_span_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_row_span(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_row_span_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_row_span_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_row_span(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_selected_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_selected_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_selected(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_selected_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_selected_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_selected(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_set_size_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_set_size_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_set_size(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_set_size_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_set_size_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_set_size(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_sort_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_sort_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_sort(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_sort_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_sort_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_sort(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_value_max_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_value_max_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_value_max(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_value_max_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_value_max_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_value_max(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_value_min_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_value_min_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_value_min(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_value_min_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_value_min_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_value_min(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_value_now_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_value_now_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_value_now(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_value_now_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_value_now_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_value_now(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_value_text_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_value_text_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->aria_value_text(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    auto retval = retval_or_exception.release_value();

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::aria_value_text_setter)
{
    WebIDL::log_trace(vm, "ElementPrototype::aria_value_text_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "Element setter");

    auto value = vm.argument(0);

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    Optional<String> cpp_value;
    if (!value.is_nullish())
        cpp_value = TRY(WebIDL::to_string(vm, value));

    auto maybe_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_aria_value_text(cpp_value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (maybe_exception.is_error())
        return maybe_exception.release_error();

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::children_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::children_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->children(); }));

    return &const_cast<HTMLCollection&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::first_element_child_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::first_element_child_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->first_element_child(); }));

    if (!retval) {
        return JS::js_null();
    } else {

    return &const_cast<Element&>(*retval);

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::last_element_child_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::last_element_child_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->last_element_child(); }));

    if (!retval) {
        return JS::js_null();
    } else {

    return &const_cast<Element&>(*retval);

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::child_element_count_getter)
{
    WebIDL::log_trace(vm, "ElementPrototype::child_element_count_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->child_element_count(); }));

    return JS::Value(static_cast<WebIDL::UnsignedLong>(retval));

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::has_attributes)
{
    WebIDL::log_trace(vm, "ElementPrototype::has_attributes");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->has_attributes(); }));

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::get_attribute_names)
{
    WebIDL::log_trace(vm, "ElementPrototype::get_attribute_names");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->get_attribute_names(); }));

    auto new_array0 = MUST(JS::Array::create(realm, 0));

    for (size_t i0 = 0; i0 < retval.size(); ++i0) {
        auto& element0 = retval.at(i0);

    auto wrapped_element0 = JS::PrimitiveString::create(vm, element0);

        auto property_index0 = JS::PropertyKey { i0 };
        MUST(new_array0->create_data_property(property_index0, wrapped_element0));
    }

    return new_array0;

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::get_attribute)
{
    WebIDL::log_trace(vm, "ElementPrototype::get_attribute");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "getAttribute");

    auto arg0 = vm.argument(0);

    String qualified_name;
    if (!false || !arg0.is_null()) {
        qualified_name = TRY(WebIDL::to_string(vm, arg0));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->get_attribute(qualified_name); }));

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::get_attribute_ns)
{
    WebIDL::log_trace(vm, "ElementPrototype::get_attribute_ns");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 2)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "getAttributeNS", "2");

    auto arg0 = vm.argument(0);

    Optional<FlyString> namespace_;
    if (!arg0.is_nullish())
        namespace_ = TRY(WebIDL::to_string(vm, arg0));

    auto arg1 = vm.argument(1);

    FlyString local_name;
    if (!false || !arg1.is_null()) {
        local_name = TRY(WebIDL::to_string(vm, arg1));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->get_attribute_ns(namespace_, local_name); }));

    if (!retval.has_value()) {
        return JS::js_null();
    } else {

    return JS::PrimitiveString::create(vm, const_cast<decltype(retval)&>(retval).release_value());

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::set_attribute)
{
    WebIDL::log_trace(vm, "ElementPrototype::set_attribute");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 2)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "setAttribute", "2");

    auto arg0 = vm.argument(0);

    String qualified_name;
    if (!false || !arg0.is_null()) {
        qualified_name = TRY(WebIDL::to_string(vm, arg0));
    }

    auto arg1 = vm.argument(1);

    String value;
    if (!false || !arg1.is_null()) {
        value = TRY(WebIDL::to_string(vm, arg1));
    }

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_attribute(qualified_name, value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    [[maybe_unused]] auto retval = retval_or_exception.release_value();

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::set_attribute_ns)
{
    WebIDL::log_trace(vm, "ElementPrototype::set_attribute_ns");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 3)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "setAttributeNS", "3");

    auto arg0 = vm.argument(0);

    Optional<FlyString> namespace_;
    if (!arg0.is_nullish())
        namespace_ = TRY(WebIDL::to_string(vm, arg0));

    auto arg1 = vm.argument(1);

    FlyString qualified_name;
    if (!false || !arg1.is_null()) {
        qualified_name = TRY(WebIDL::to_string(vm, arg1));
    }

    auto arg2 = vm.argument(2);

    String value;
    if (!false || !arg2.is_null()) {
        value = TRY(WebIDL::to_string(vm, arg2));
    }

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_attribute_ns(namespace_, qualified_name, value); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    [[maybe_unused]] auto retval = retval_or_exception.release_value();

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::remove_attribute)
{
    WebIDL::log_trace(vm, "ElementPrototype::remove_attribute");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "removeAttribute");

    auto arg0 = vm.argument(0);

    FlyString qualified_name;
    if (!false || !arg0.is_null()) {
        qualified_name = TRY(WebIDL::to_string(vm, arg0));
    }

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->remove_attribute(qualified_name); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    [[maybe_unused]] auto retval = retval_or_exception.release_value();

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::remove_attribute_ns)
{
    WebIDL::log_trace(vm, "ElementPrototype::remove_attribute_ns");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 2)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "removeAttributeNS", "2");

    auto arg0 = vm.argument(0);

    Optional<FlyString> namespace_;
    if (!arg0.is_nullish())
        namespace_ = TRY(WebIDL::to_string(vm, arg0));

    auto arg1 = vm.argument(1);

    FlyString local_name;
    if (!false || !arg1.is_null()) {
        local_name = TRY(WebIDL::to_string(vm, arg1));
    }

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->remove_attribute_ns(namespace_, local_name); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    [[maybe_unused]] auto retval = retval_or_exception.release_value();

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::toggle_attribute)
{
    WebIDL::log_trace(vm, "ElementPrototype::toggle_attribute");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "toggleAttribute");

    auto arg0 = vm.argument(0);

    String qualified_name;
    if (!false || !arg0.is_null()) {
        qualified_name = TRY(WebIDL::to_string(vm, arg0));
    }

    auto arg1 = vm.argument(1);

    Optional<bool> force;

    if (!arg1.is_undefined())

    force = arg1.to_boolean();

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->toggle_attribute(qualified_name, force); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    [[maybe_unused]] auto retval = retval_or_exception.release_value();

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::has_attribute)
{
    WebIDL::log_trace(vm, "ElementPrototype::has_attribute");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "hasAttribute");

    auto arg0 = vm.argument(0);

    String qualified_name;
    if (!false || !arg0.is_null()) {
        qualified_name = TRY(WebIDL::to_string(vm, arg0));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->has_attribute(qualified_name); }));

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::has_attribute_ns)
{
    WebIDL::log_trace(vm, "ElementPrototype::has_attribute_ns");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 2)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "hasAttributeNS", "2");

    auto arg0 = vm.argument(0);

    Optional<FlyString> namespace_;
    if (!arg0.is_nullish())
        namespace_ = TRY(WebIDL::to_string(vm, arg0));

    auto arg1 = vm.argument(1);

    FlyString local_name;
    if (!false || !arg1.is_null()) {
        local_name = TRY(WebIDL::to_string(vm, arg1));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->has_attribute_ns(namespace_, local_name); }));

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::get_attribute_node)
{
    WebIDL::log_trace(vm, "ElementPrototype::get_attribute_node");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "getAttributeNode");

    auto arg0 = vm.argument(0);

    FlyString qualified_name;
    if (!false || !arg0.is_null()) {
        qualified_name = TRY(WebIDL::to_string(vm, arg0));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->get_attribute_node(qualified_name); }));

    if (!retval) {
        return JS::js_null();
    } else {

    return &const_cast<Attr&>(*retval);

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::get_attribute_node_ns)
{
    WebIDL::log_trace(vm, "ElementPrototype::get_attribute_node_ns");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 2)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "getAttributeNodeNS", "2");

    auto arg0 = vm.argument(0);

    Optional<FlyString> namespace_;
    if (!arg0.is_nullish())
        namespace_ = TRY(WebIDL::to_string(vm, arg0));

    auto arg1 = vm.argument(1);

    FlyString local_name;
    if (!false || !arg1.is_null()) {
        local_name = TRY(WebIDL::to_string(vm, arg1));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->get_attribute_node_ns(namespace_, local_name); }));

    if (!retval) {
        return JS::js_null();
    } else {

    return &const_cast<Attr&>(*retval);

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::set_attribute_node)
{
    WebIDL::log_trace(vm, "ElementPrototype::set_attribute_node");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "setAttributeNode");

    auto arg0 = vm.argument(0);

    if (!arg0.is_object() || !is<Attr>(arg0.as_object()))
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "Attr");

    auto& attr = static_cast<Attr&>(arg0.as_object());

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_attribute_node(attr); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    [[maybe_unused]] auto retval = retval_or_exception.release_value();

    if (!retval) {
        return JS::js_null();
    } else {

    return &const_cast<Attr&>(*retval);

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::set_attribute_node_ns)
{
    WebIDL::log_trace(vm, "ElementPrototype::set_attribute_node_ns");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "setAttributeNodeNS");

    auto arg0 = vm.argument(0);

    if (!arg0.is_object() || !is<Attr>(arg0.as_object()))
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "Attr");

    auto& attr = static_cast<Attr&>(arg0.as_object());

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_attribute_node_ns(attr); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    [[maybe_unused]] auto retval = retval_or_exception.release_value();

    if (!retval) {
        return JS::js_null();
    } else {

    return &const_cast<Attr&>(*retval);

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::remove_attribute_node)
{
    WebIDL::log_trace(vm, "ElementPrototype::remove_attribute_node");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "removeAttributeNode");

    auto arg0 = vm.argument(0);

    if (!arg0.is_object() || !is<Attr>(arg0.as_object()))
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "Attr");

    auto& attr = static_cast<Attr&>(arg0.as_object());

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->remove_attribute_node(attr); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    [[maybe_unused]] auto retval = retval_or_exception.release_value();

    return &const_cast<Attr&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::attach_shadow)
{
    WebIDL::log_trace(vm, "ElementPrototype::attach_shadow");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "attachShadow");

    auto arg0 = vm.argument(0);

    if (!arg0.is_nullish() && !arg0.is_object())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "ShadowRootInit");

    ShadowRootInit init {};

    auto clonable_property_value_0 = JS::js_undefined();
    if (arg0.is_object())
        clonable_property_value_0 = TRY(arg0.as_object().get("clonable"));

    bool clonable_value_0;

    if (!clonable_property_value_0.is_undefined())

    clonable_value_0 = clonable_property_value_0.to_boolean();

    else
        clonable_value_0 = static_cast<bool>(false);

    init.clonable = clonable_value_0;

    auto delegates_focus_property_value_1 = JS::js_undefined();
    if (arg0.is_object())
        delegates_focus_property_value_1 = TRY(arg0.as_object().get("delegatesFocus"));

    bool delegates_focus_value_1;

    if (!delegates_focus_property_value_1.is_undefined())

    delegates_focus_value_1 = delegates_focus_property_value_1.to_boolean();

    else
        delegates_focus_value_1 = static_cast<bool>(false);

    init.delegates_focus = delegates_focus_value_1;

    auto mode_property_value_2 = JS::js_undefined();
    if (arg0.is_object())
        mode_property_value_2 = TRY(arg0.as_object().get("mode"));

    if (mode_property_value_2.is_undefined())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::MissingRequiredProperty, "mode");

    ShadowRootMode mode_value_2 { ShadowRootMode::Open };

    auto mode_property_value_2_string = TRY(mode_property_value_2.to_string(vm));

    if (mode_property_value_2_string == "open"sv)
        mode_value_2 = ShadowRootMode::Open;

    else if (mode_property_value_2_string == "closed"sv)
        mode_value_2 = ShadowRootMode::Closed;

    else
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidEnumerationValue, mode_property_value_2_string, "ShadowRootMode");

    init.mode = mode_value_2;

    auto serializable_property_value_3 = JS::js_undefined();
    if (arg0.is_object())
        serializable_property_value_3 = TRY(arg0.as_object().get("serializable"));

    bool serializable_value_3;

    if (!serializable_property_value_3.is_undefined())

    serializable_value_3 = serializable_property_value_3.to_boolean();

    else
        serializable_value_3 = static_cast<bool>(false);

    init.serializable = serializable_value_3;

    auto slot_assignment_property_value_4 = JS::js_undefined();
    if (arg0.is_object())
        slot_assignment_property_value_4 = TRY(arg0.as_object().get("slotAssignment"));

    SlotAssignmentMode slot_assignment_value_4 { SlotAssignmentMode::Named };

    if (!slot_assignment_property_value_4.is_undefined()) {

    auto slot_assignment_property_value_4_string = TRY(slot_assignment_property_value_4.to_string(vm));

    if (slot_assignment_property_value_4_string == "manual"sv)
        slot_assignment_value_4 = SlotAssignmentMode::Manual;

    else if (slot_assignment_property_value_4_string == "named"sv)
        slot_assignment_value_4 = SlotAssignmentMode::Named;

    else
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidEnumerationValue, slot_assignment_property_value_4_string, "SlotAssignmentMode");

    }

    init.slot_assignment = slot_assignment_value_4;

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->attach_shadow(init); }));

    return &const_cast<ShadowRoot&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::matches)
{
    WebIDL::log_trace(vm, "ElementPrototype::matches");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "matches");

    auto arg0 = vm.argument(0);

    String selectors;
    if (!false || !arg0.is_null()) {
        selectors = TRY(WebIDL::to_string(vm, arg0));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->matches(selectors); }));

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::closest)
{
    WebIDL::log_trace(vm, "ElementPrototype::closest");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "closest");

    auto arg0 = vm.argument(0);

    String selectors;
    if (!false || !arg0.is_null()) {
        selectors = TRY(WebIDL::to_string(vm, arg0));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->closest(selectors); }));

    if (!retval) {
        return JS::js_null();
    } else {

    return &const_cast<Element&>(*retval);

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::webkit_matches_selector)
{
    WebIDL::log_trace(vm, "ElementPrototype::webkit_matches_selector");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "webkitMatchesSelector");

    auto arg0 = vm.argument(0);

    String selectors;
    if (!false || !arg0.is_null()) {
        selectors = TRY(WebIDL::to_string(vm, arg0));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->matches(selectors); }));

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::get_elements_by_tag_name)
{
    WebIDL::log_trace(vm, "ElementPrototype::get_elements_by_tag_name");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "getElementsByTagName");

    auto arg0 = vm.argument(0);

    FlyString tag_name;
    if (!false || !arg0.is_null()) {
        tag_name = TRY(WebIDL::to_string(vm, arg0));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->get_elements_by_tag_name(tag_name); }));

    return &const_cast<HTMLCollection&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::get_elements_by_tag_name_ns)
{
    WebIDL::log_trace(vm, "ElementPrototype::get_elements_by_tag_name_ns");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 2)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "getElementsByTagNameNS", "2");

    auto arg0 = vm.argument(0);

    Optional<FlyString> namespace_;
    if (!arg0.is_nullish())
        namespace_ = TRY(WebIDL::to_string(vm, arg0));

    auto arg1 = vm.argument(1);

    FlyString local_name;
    if (!false || !arg1.is_null()) {
        local_name = TRY(WebIDL::to_string(vm, arg1));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->get_elements_by_tag_name_ns(namespace_, local_name); }));

    return &const_cast<HTMLCollection&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::get_elements_by_class_name)
{
    WebIDL::log_trace(vm, "ElementPrototype::get_elements_by_class_name");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "getElementsByClassName");

    auto arg0 = vm.argument(0);

    String class_name;
    if (!false || !arg0.is_null()) {
        class_name = TRY(WebIDL::to_string(vm, arg0));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->get_elements_by_class_name(class_name); }));

    return &const_cast<HTMLCollection&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::insert_adjacent_element)
{
    WebIDL::log_trace(vm, "ElementPrototype::insert_adjacent_element");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 2)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "insertAdjacentElement", "2");

    auto arg0 = vm.argument(0);

    String where;
    if (!false || !arg0.is_null()) {
        where = TRY(WebIDL::to_string(vm, arg0));
    }

    auto arg1 = vm.argument(1);

    if (!arg1.is_object() || !is<Element>(arg1.as_object()))
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "Element");

    auto& element = static_cast<Element&>(arg1.as_object());

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->insert_adjacent_element(where, element); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    [[maybe_unused]] auto retval = retval_or_exception.release_value();

    if (!retval) {
        return JS::js_null();
    } else {

    return &const_cast<Element&>(*retval);

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::insert_adjacent_text)
{
    WebIDL::log_trace(vm, "ElementPrototype::insert_adjacent_text");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 2)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "insertAdjacentText", "2");

    auto arg0 = vm.argument(0);

    String where;
    if (!false || !arg0.is_null()) {
        where = TRY(WebIDL::to_string(vm, arg0));
    }

    auto arg1 = vm.argument(1);

    String data;
    if (!false || !arg1.is_null()) {
        data = TRY(WebIDL::to_string(vm, arg1));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->insert_adjacent_text(where, data); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::get_client_rects)
{
    WebIDL::log_trace(vm, "ElementPrototype::get_client_rects");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->get_client_rects(); }));

    return &const_cast<DOMRectList&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::get_bounding_client_rect)
{
    WebIDL::log_trace(vm, "ElementPrototype::get_bounding_client_rect");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->get_bounding_client_rect(); }));

    return &const_cast<DOMRect&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::check_visibility)
{
    WebIDL::log_trace(vm, "ElementPrototype::check_visibility");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    auto arg0 = vm.argument(0);

    if (!arg0.is_nullish() && !arg0.is_object())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "CheckVisibilityOptions");

    CheckVisibilityOptions options {};

    auto check_opacity_property_value_5 = JS::js_undefined();
    if (arg0.is_object())
        check_opacity_property_value_5 = TRY(arg0.as_object().get("checkOpacity"));

    bool check_opacity_value_5;

    if (!check_opacity_property_value_5.is_undefined())

    check_opacity_value_5 = check_opacity_property_value_5.to_boolean();

    else
        check_opacity_value_5 = static_cast<bool>(false);

    options.check_opacity = check_opacity_value_5;

    auto check_visibility_css_property_value_6 = JS::js_undefined();
    if (arg0.is_object())
        check_visibility_css_property_value_6 = TRY(arg0.as_object().get("checkVisibilityCSS"));

    bool check_visibility_css_value_6;

    if (!check_visibility_css_property_value_6.is_undefined())

    check_visibility_css_value_6 = check_visibility_css_property_value_6.to_boolean();

    else
        check_visibility_css_value_6 = static_cast<bool>(false);

    options.check_visibility_css = check_visibility_css_value_6;

    auto content_visibility_auto_property_value_7 = JS::js_undefined();
    if (arg0.is_object())
        content_visibility_auto_property_value_7 = TRY(arg0.as_object().get("contentVisibilityAuto"));

    bool content_visibility_auto_value_7;

    if (!content_visibility_auto_property_value_7.is_undefined())

    content_visibility_auto_value_7 = content_visibility_auto_property_value_7.to_boolean();

    else
        content_visibility_auto_value_7 = static_cast<bool>(false);

    options.content_visibility_auto = content_visibility_auto_value_7;

    auto opacity_property_property_value_8 = JS::js_undefined();
    if (arg0.is_object())
        opacity_property_property_value_8 = TRY(arg0.as_object().get("opacityProperty"));

    bool opacity_property_value_8;

    if (!opacity_property_property_value_8.is_undefined())

    opacity_property_value_8 = opacity_property_property_value_8.to_boolean();

    else
        opacity_property_value_8 = static_cast<bool>(false);

    options.opacity_property = opacity_property_value_8;

    auto visibility_property_property_value_9 = JS::js_undefined();
    if (arg0.is_object())
        visibility_property_property_value_9 = TRY(arg0.as_object().get("visibilityProperty"));

    bool visibility_property_value_9;

    if (!visibility_property_property_value_9.is_undefined())

    visibility_property_value_9 = visibility_property_property_value_9.to_boolean();

    else
        visibility_property_value_9 = static_cast<bool>(false);

    options.visibility_property = visibility_property_value_9;

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->check_visibility(options); }));

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::scroll_into_view)
{
    WebIDL::log_trace(vm, "ElementPrototype::scroll_into_view");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    auto arg0 = vm.argument(0);

    auto arg0_to_dictionary = [&vm, &realm](JS::Value arg0) -> JS::ThrowCompletionOr<ScrollIntoViewOptions> {
        // This might be unused.
        (void)realm;

    if (!arg0.is_nullish() && !arg0.is_object())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "ScrollIntoViewOptions");

    ScrollIntoViewOptions dictionary_union_type {};

    auto block_property_value_0 = JS::js_undefined();
    if (arg0.is_object())
        block_property_value_0 = TRY(arg0.as_object().get("block"));

    ScrollLogicalPosition block_value_0 { ScrollLogicalPosition::Start };

    if (!block_property_value_0.is_undefined()) {

    auto block_property_value_0_string = TRY(block_property_value_0.to_string(vm));

    if (block_property_value_0_string == "start"sv)
        block_value_0 = ScrollLogicalPosition::Start;

    else if (block_property_value_0_string == "center"sv)
        block_value_0 = ScrollLogicalPosition::Center;

    else if (block_property_value_0_string == "end"sv)
        block_value_0 = ScrollLogicalPosition::End;

    else if (block_property_value_0_string == "nearest"sv)
        block_value_0 = ScrollLogicalPosition::Nearest;

    else
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidEnumerationValue, block_property_value_0_string, "ScrollLogicalPosition");

    }

    dictionary_union_type.block = block_value_0;

    auto container_property_value_1 = JS::js_undefined();
    if (arg0.is_object())
        container_property_value_1 = TRY(arg0.as_object().get("container"));

    ScrollIntoViewContainer container_value_1 { ScrollIntoViewContainer::All };

    if (!container_property_value_1.is_undefined()) {

    auto container_property_value_1_string = TRY(container_property_value_1.to_string(vm));

    if (container_property_value_1_string == "all"sv)
        container_value_1 = ScrollIntoViewContainer::All;

    else if (container_property_value_1_string == "nearest"sv)
        container_value_1 = ScrollIntoViewContainer::Nearest;

    else
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidEnumerationValue, container_property_value_1_string, "ScrollIntoViewContainer");

    }

    dictionary_union_type.container = container_value_1;

    auto inline__property_value_2 = JS::js_undefined();
    if (arg0.is_object())
        inline__property_value_2 = TRY(arg0.as_object().get("inline"));

    ScrollLogicalPosition inline__value_2 { ScrollLogicalPosition::Nearest };

    if (!inline__property_value_2.is_undefined()) {

    auto inline__property_value_2_string = TRY(inline__property_value_2.to_string(vm));

    if (inline__property_value_2_string == "start"sv)
        inline__value_2 = ScrollLogicalPosition::Start;

    else if (inline__property_value_2_string == "center"sv)
        inline__value_2 = ScrollLogicalPosition::Center;

    else if (inline__property_value_2_string == "end"sv)
        inline__value_2 = ScrollLogicalPosition::End;

    else if (inline__property_value_2_string == "nearest"sv)
        inline__value_2 = ScrollLogicalPosition::Nearest;

    else
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidEnumerationValue, inline__property_value_2_string, "ScrollLogicalPosition");

    }

    dictionary_union_type.inline_ = inline__value_2;

    auto behavior_property_value_3 = JS::js_undefined();
    if (arg0.is_object())
        behavior_property_value_3 = TRY(arg0.as_object().get("behavior"));

    ScrollBehavior behavior_value_3 { ScrollBehavior::Auto };

    if (!behavior_property_value_3.is_undefined()) {

    auto behavior_property_value_3_string = TRY(behavior_property_value_3.to_string(vm));

    if (behavior_property_value_3_string == "auto"sv)
        behavior_value_3 = ScrollBehavior::Auto;

    else if (behavior_property_value_3_string == "instant"sv)
        behavior_value_3 = ScrollBehavior::Instant;

    else if (behavior_property_value_3_string == "smooth"sv)
        behavior_value_3 = ScrollBehavior::Smooth;

    else
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidEnumerationValue, behavior_property_value_3_string, "ScrollBehavior");

    }

    dictionary_union_type.behavior = behavior_value_3;

        return dictionary_union_type;
    };

    auto arg0_to_variant = [&vm, &realm, &arg0_to_dictionary](JS::Value arg0) -> JS::ThrowCompletionOr<Variant<bool, ScrollIntoViewOptions>> {
        // These might be unused.
        (void)vm;
        (void)realm;

        if (arg0.is_nullish())
            return Variant<bool, ScrollIntoViewOptions> { TRY(arg0_to_dictionary(arg0)) };

        if (arg0.is_object()) {
            [[maybe_unused]] auto& arg0_object = arg0.as_object();

        return Variant<bool, ScrollIntoViewOptions> { TRY(arg0_to_dictionary(arg0)) };

        }

        if (arg0.is_boolean())
            return Variant<bool, ScrollIntoViewOptions> { arg0.as_bool() };

        return Variant<bool, ScrollIntoViewOptions> { arg0.to_boolean() };

    };

    Variant<bool, ScrollIntoViewOptions> arg = arg0.is_undefined() ? TRY(arg0_to_dictionary(arg0)) : TRY(arg0_to_variant(arg0));

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->scroll_into_view(arg); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::scroll0)
{
    WebIDL::log_trace(vm, "ElementPrototype::scroll0");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    auto arg0 = vm.argument(0);

    if (!arg0.is_nullish() && !arg0.is_object())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "ScrollToOptions");

    ScrollToOptions options {};

    auto left_property_value_10 = JS::js_undefined();
    if (arg0.is_object())
        left_property_value_10 = TRY(arg0.as_object().get("left"));

    if (!left_property_value_10.is_undefined()) {

    Optional<double> left_value_10;

    if (!left_property_value_10.is_undefined())
        left_value_10 = TRY(left_property_value_10.to_double(vm));


    options.left = left_value_10;

    }

    auto top_property_value_11 = JS::js_undefined();
    if (arg0.is_object())
        top_property_value_11 = TRY(arg0.as_object().get("top"));

    if (!top_property_value_11.is_undefined()) {

    Optional<double> top_value_11;

    if (!top_property_value_11.is_undefined())
        top_value_11 = TRY(top_property_value_11.to_double(vm));


    options.top = top_value_11;

    }

    auto behavior_property_value_12 = JS::js_undefined();
    if (arg0.is_object())
        behavior_property_value_12 = TRY(arg0.as_object().get("behavior"));

    ScrollBehavior behavior_value_12 { ScrollBehavior::Auto };

    if (!behavior_property_value_12.is_undefined()) {

    auto behavior_property_value_12_string = TRY(behavior_property_value_12.to_string(vm));

    if (behavior_property_value_12_string == "auto"sv)
        behavior_value_12 = ScrollBehavior::Auto;

    else if (behavior_property_value_12_string == "instant"sv)
        behavior_value_12 = ScrollBehavior::Instant;

    else if (behavior_property_value_12_string == "smooth"sv)
        behavior_value_12 = ScrollBehavior::Smooth;

    else
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidEnumerationValue, behavior_property_value_12_string, "ScrollBehavior");

    }

    options.behavior = behavior_value_12;

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->scroll(options); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::scroll1)
{
    WebIDL::log_trace(vm, "ElementPrototype::scroll1");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    auto arg0 = vm.argument(0);

    double x = TRY(arg0.to_double(vm));

    auto arg1 = vm.argument(1);

    double y = TRY(arg1.to_double(vm));

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->scroll(x, y); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::scroll_to0)
{
    WebIDL::log_trace(vm, "ElementPrototype::scroll_to0");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    auto arg0 = vm.argument(0);

    if (!arg0.is_nullish() && !arg0.is_object())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "ScrollToOptions");

    ScrollToOptions options {};

    auto left_property_value_13 = JS::js_undefined();
    if (arg0.is_object())
        left_property_value_13 = TRY(arg0.as_object().get("left"));

    if (!left_property_value_13.is_undefined()) {

    Optional<double> left_value_13;

    if (!left_property_value_13.is_undefined())
        left_value_13 = TRY(left_property_value_13.to_double(vm));


    options.left = left_value_13;

    }

    auto top_property_value_14 = JS::js_undefined();
    if (arg0.is_object())
        top_property_value_14 = TRY(arg0.as_object().get("top"));

    if (!top_property_value_14.is_undefined()) {

    Optional<double> top_value_14;

    if (!top_property_value_14.is_undefined())
        top_value_14 = TRY(top_property_value_14.to_double(vm));


    options.top = top_value_14;

    }

    auto behavior_property_value_15 = JS::js_undefined();
    if (arg0.is_object())
        behavior_property_value_15 = TRY(arg0.as_object().get("behavior"));

    ScrollBehavior behavior_value_15 { ScrollBehavior::Auto };

    if (!behavior_property_value_15.is_undefined()) {

    auto behavior_property_value_15_string = TRY(behavior_property_value_15.to_string(vm));

    if (behavior_property_value_15_string == "auto"sv)
        behavior_value_15 = ScrollBehavior::Auto;

    else if (behavior_property_value_15_string == "instant"sv)
        behavior_value_15 = ScrollBehavior::Instant;

    else if (behavior_property_value_15_string == "smooth"sv)
        behavior_value_15 = ScrollBehavior::Smooth;

    else
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidEnumerationValue, behavior_property_value_15_string, "ScrollBehavior");

    }

    options.behavior = behavior_value_15;

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->scroll(options); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::scroll_to1)
{
    WebIDL::log_trace(vm, "ElementPrototype::scroll_to1");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    auto arg0 = vm.argument(0);

    double x = TRY(arg0.to_double(vm));

    auto arg1 = vm.argument(1);

    double y = TRY(arg1.to_double(vm));

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->scroll(x, y); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::scroll_by0)
{
    WebIDL::log_trace(vm, "ElementPrototype::scroll_by0");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    auto arg0 = vm.argument(0);

    if (!arg0.is_nullish() && !arg0.is_object())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "ScrollToOptions");

    ScrollToOptions options {};

    auto left_property_value_16 = JS::js_undefined();
    if (arg0.is_object())
        left_property_value_16 = TRY(arg0.as_object().get("left"));

    if (!left_property_value_16.is_undefined()) {

    Optional<double> left_value_16;

    if (!left_property_value_16.is_undefined())
        left_value_16 = TRY(left_property_value_16.to_double(vm));


    options.left = left_value_16;

    }

    auto top_property_value_17 = JS::js_undefined();
    if (arg0.is_object())
        top_property_value_17 = TRY(arg0.as_object().get("top"));

    if (!top_property_value_17.is_undefined()) {

    Optional<double> top_value_17;

    if (!top_property_value_17.is_undefined())
        top_value_17 = TRY(top_property_value_17.to_double(vm));


    options.top = top_value_17;

    }

    auto behavior_property_value_18 = JS::js_undefined();
    if (arg0.is_object())
        behavior_property_value_18 = TRY(arg0.as_object().get("behavior"));

    ScrollBehavior behavior_value_18 { ScrollBehavior::Auto };

    if (!behavior_property_value_18.is_undefined()) {

    auto behavior_property_value_18_string = TRY(behavior_property_value_18.to_string(vm));

    if (behavior_property_value_18_string == "auto"sv)
        behavior_value_18 = ScrollBehavior::Auto;

    else if (behavior_property_value_18_string == "instant"sv)
        behavior_value_18 = ScrollBehavior::Instant;

    else if (behavior_property_value_18_string == "smooth"sv)
        behavior_value_18 = ScrollBehavior::Smooth;

    else
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidEnumerationValue, behavior_property_value_18_string, "ScrollBehavior");

    }

    options.behavior = behavior_value_18;

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->scroll_by(options); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::scroll_by1)
{
    WebIDL::log_trace(vm, "ElementPrototype::scroll_by1");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    auto arg0 = vm.argument(0);

    double x = TRY(arg0.to_double(vm));

    auto arg1 = vm.argument(1);

    double y = TRY(arg1.to_double(vm));

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->scroll_by(x, y); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::set_html_unsafe)
{
    WebIDL::log_trace(vm, "ElementPrototype::set_html_unsafe");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "setHTMLUnsafe");

    auto arg0 = vm.argument(0);

    String html;
    if (!false || !arg0.is_null()) {
        html = TRY(WebIDL::to_string(vm, arg0));
    }

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->set_html_unsafe(html); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    [[maybe_unused]] auto retval = retval_or_exception.release_value();

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::get_html)
{
    WebIDL::log_trace(vm, "ElementPrototype::get_html");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    auto arg0 = vm.argument(0);

    if (!arg0.is_nullish() && !arg0.is_object())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "GetHTMLOptions");

    GetHTMLOptions options {};

    auto serializable_shadow_roots_property_value_19 = JS::js_undefined();
    if (arg0.is_object())
        serializable_shadow_roots_property_value_19 = TRY(arg0.as_object().get("serializableShadowRoots"));

    bool serializable_shadow_roots_value_19;

    if (!serializable_shadow_roots_property_value_19.is_undefined())

    serializable_shadow_roots_value_19 = serializable_shadow_roots_property_value_19.to_boolean();

    else
        serializable_shadow_roots_value_19 = static_cast<bool>(false);

    options.serializable_shadow_roots = serializable_shadow_roots_value_19;

    auto shadow_roots_property_value_20 = JS::js_undefined();
    if (arg0.is_object())
        shadow_roots_property_value_20 = TRY(arg0.as_object().get("shadowRoots"));

    GC::RootVector<GC::Root<ShadowRoot>> shadow_roots_value_20 { vm.heap() };

    if (!shadow_roots_property_value_20.is_undefined()) {

    if (!shadow_roots_property_value_20.is_object())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObject, shadow_roots_property_value_20.to_string_without_side_effects());

    auto shadow_roots_property_value_20_iterator_method0 = TRY(shadow_roots_property_value_20.get_method(vm, vm.well_known_symbol_iterator()));
    if (!shadow_roots_property_value_20_iterator_method0)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotIterable, shadow_roots_property_value_20.to_string_without_side_effects());

    auto shadow_roots_property_value_20_iterator1 = TRY(JS::get_iterator_from_method(vm, shadow_roots_property_value_20, *shadow_roots_property_value_20_iterator_method0));

    GC::RootVector<GC::Root<ShadowRoot>> shadow_roots_value_20_non_optional { vm.heap() };

    for (;;) {
        auto next1 = TRY(JS::iterator_step(vm, shadow_roots_property_value_20_iterator1));
        if (!next1)
            break;

        auto next_item1 = TRY(JS::iterator_value(vm, *next1));

    if (!next_item1.is_object() || !is<ShadowRoot>(next_item1.as_object()))
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "ShadowRoot");

    auto& sequence_item1 = static_cast<ShadowRoot&>(next_item1.as_object());

    shadow_roots_value_20_non_optional.append(sequence_item1);
    }

        shadow_roots_value_20 = move(shadow_roots_value_20_non_optional);
    }

    options.shadow_roots = shadow_roots_value_20;

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->get_html(options); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::insert_adjacent_html)
{
    WebIDL::log_trace(vm, "ElementPrototype::insert_adjacent_html");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 2)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "insertAdjacentHTML", "2");

    auto arg0 = vm.argument(0);

    String position;
    if (!false || !arg0.is_null()) {
        position = TRY(WebIDL::to_string(vm, arg0));
    }

    auto arg1 = vm.argument(1);

    String text;
    if (!false || !arg1.is_null()) {
        text = TRY(WebIDL::to_string(vm, arg1));
    }

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->insert_adjacent_html(position, text); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    [[maybe_unused]] auto retval = retval_or_exception.release_value();

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::before)
{
    WebIDL::log_trace(vm, "ElementPrototype::before");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    auto arg0_to_variant = [&vm, &realm](JS::Value arg0) -> JS::ThrowCompletionOr<Variant<GC::Root<Node>, String>> {
        // These might be unused.
        (void)vm;
        (void)realm;

        if (arg0.is_object()) {
            [[maybe_unused]] auto& arg0_object = arg0.as_object();

            if (is<PlatformObject>(arg0_object)) {

                if (is<Node>(arg0_object))
                    return GC::make_root(static_cast<Node&>(arg0_object));

            }

        }

    String arg0_string;
    if (!false || !arg0.is_null()) {
        arg0_string = TRY(WebIDL::to_string(vm, arg0));
    }

        return { arg0_string };

    };

        Vector<Variant<GC::Root<Node>, String>> nodes;

        if (vm.argument_count() > 0) {
            nodes.ensure_capacity(vm.argument_count() - 0);

            for (size_t i = 0; i < vm.argument_count(); ++i) {
                auto result = TRY(arg0_to_variant(vm.argument(i)));
                nodes.unchecked_append(move(result));
            }
        }
    
    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->before(move(nodes)); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    [[maybe_unused]] auto retval = retval_or_exception.release_value();

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::after)
{
    WebIDL::log_trace(vm, "ElementPrototype::after");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    auto arg0_to_variant = [&vm, &realm](JS::Value arg0) -> JS::ThrowCompletionOr<Variant<GC::Root<Node>, String>> {
        // These might be unused.
        (void)vm;
        (void)realm;

        if (arg0.is_object()) {
            [[maybe_unused]] auto& arg0_object = arg0.as_object();

            if (is<PlatformObject>(arg0_object)) {

                if (is<Node>(arg0_object))
                    return GC::make_root(static_cast<Node&>(arg0_object));

            }

        }

    String arg0_string;
    if (!false || !arg0.is_null()) {
        arg0_string = TRY(WebIDL::to_string(vm, arg0));
    }

        return { arg0_string };

    };

        Vector<Variant<GC::Root<Node>, String>> nodes;

        if (vm.argument_count() > 0) {
            nodes.ensure_capacity(vm.argument_count() - 0);

            for (size_t i = 0; i < vm.argument_count(); ++i) {
                auto result = TRY(arg0_to_variant(vm.argument(i)));
                nodes.unchecked_append(move(result));
            }
        }
    
    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->after(move(nodes)); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    [[maybe_unused]] auto retval = retval_or_exception.release_value();

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::replace_with)
{
    WebIDL::log_trace(vm, "ElementPrototype::replace_with");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    auto arg0_to_variant = [&vm, &realm](JS::Value arg0) -> JS::ThrowCompletionOr<Variant<GC::Root<Node>, String>> {
        // These might be unused.
        (void)vm;
        (void)realm;

        if (arg0.is_object()) {
            [[maybe_unused]] auto& arg0_object = arg0.as_object();

            if (is<PlatformObject>(arg0_object)) {

                if (is<Node>(arg0_object))
                    return GC::make_root(static_cast<Node&>(arg0_object));

            }

        }

    String arg0_string;
    if (!false || !arg0.is_null()) {
        arg0_string = TRY(WebIDL::to_string(vm, arg0));
    }

        return { arg0_string };

    };

        Vector<Variant<GC::Root<Node>, String>> nodes;

        if (vm.argument_count() > 0) {
            nodes.ensure_capacity(vm.argument_count() - 0);

            for (size_t i = 0; i < vm.argument_count(); ++i) {
                auto result = TRY(arg0_to_variant(vm.argument(i)));
                nodes.unchecked_append(move(result));
            }
        }
    
    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->replace_with(move(nodes)); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    [[maybe_unused]] auto retval = retval_or_exception.release_value();

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::remove)
{
    WebIDL::log_trace(vm, "ElementPrototype::remove");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->remove_binding(); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    [[maybe_unused]] auto retval = retval_or_exception.release_value();

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::animate)
{
    WebIDL::log_trace(vm, "ElementPrototype::animate");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "animate");

    auto arg0 = vm.argument(0);

    Optional<GC::Root<JS::Object>> keyframes;
    if (!arg0.is_null() && !arg0.is_undefined())
        keyframes = GC::make_root(TRY(arg0.to_object(vm)));

    auto arg1 = vm.argument(1);

    auto arg1_to_dictionary = [&vm, &realm](JS::Value arg1) -> JS::ThrowCompletionOr<KeyframeAnimationOptions> {
        // This might be unused.
        (void)realm;

    if (!arg1.is_nullish() && !arg1.is_object())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "KeyframeAnimationOptions");

    KeyframeAnimationOptions dictionary_union_type {};

    auto id_property_value_4 = JS::js_undefined();
    if (arg1.is_object())
        id_property_value_4 = TRY(arg1.as_object().get("id"));

    String id_value_4;

    if (!id_property_value_4.is_undefined()) {
        if (!false || !id_property_value_4.is_null())
            id_value_4 = TRY(WebIDL::to_string(vm, id_property_value_4));
    } else {
        id_value_4 = MUST(String::from_utf8(""sv));
    }

    dictionary_union_type.id = id_value_4;

    auto timeline_property_value_5 = JS::js_undefined();
    if (arg1.is_object())
        timeline_property_value_5 = TRY(arg1.as_object().get("timeline"));

    if (!timeline_property_value_5.is_undefined()) {

    GC::Ptr<AnimationTimeline> timeline_value_5;

    if (!timeline_property_value_5.is_nullish()) {
        if (!timeline_property_value_5.is_object() || !is<AnimationTimeline>(timeline_property_value_5.as_object()))
            return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "AnimationTimeline");

        timeline_value_5 = &static_cast<AnimationTimeline&>(timeline_property_value_5.as_object());
    }

    dictionary_union_type.timeline = timeline_value_5;

    }

    auto composite_property_value_6 = JS::js_undefined();
    if (arg1.is_object())
        composite_property_value_6 = TRY(arg1.as_object().get("composite"));

    CompositeOperation composite_value_6 { CompositeOperation::Replace };

    if (!composite_property_value_6.is_undefined()) {

    auto composite_property_value_6_string = TRY(composite_property_value_6.to_string(vm));

    if (composite_property_value_6_string == "replace"sv)
        composite_value_6 = CompositeOperation::Replace;

    else if (composite_property_value_6_string == "add"sv)
        composite_value_6 = CompositeOperation::Add;

    else if (composite_property_value_6_string == "accumulate"sv)
        composite_value_6 = CompositeOperation::Accumulate;

    else
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidEnumerationValue, composite_property_value_6_string, "CompositeOperation");

    }

    dictionary_union_type.composite = composite_value_6;

    auto pseudo_element_property_value_7 = JS::js_undefined();
    if (arg1.is_object())
        pseudo_element_property_value_7 = TRY(arg1.as_object().get("pseudoElement"));

    Optional<String> pseudo_element_value_7;

    if (!pseudo_element_property_value_7.is_undefined()) {
        if (!pseudo_element_property_value_7.is_null())
            pseudo_element_value_7 = TRY(WebIDL::to_string(vm, pseudo_element_property_value_7));
    }

    dictionary_union_type.pseudo_element = pseudo_element_value_7;

    auto delay_property_value_8 = JS::js_undefined();
    if (arg1.is_object())
        delay_property_value_8 = TRY(arg1.as_object().get("delay"));

    double delay_value_8;

    if (!delay_property_value_8.is_undefined())
        delay_value_8 = TRY(delay_property_value_8.to_double(vm));

    else
        delay_value_8 = 0;

    if (isinf(delay_value_8) || isnan(delay_value_8)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "delay");
    }
    
    dictionary_union_type.delay = delay_value_8;

    auto direction_property_value_9 = JS::js_undefined();
    if (arg1.is_object())
        direction_property_value_9 = TRY(arg1.as_object().get("direction"));

    PlaybackDirection direction_value_9 { PlaybackDirection::Normal };

    if (!direction_property_value_9.is_undefined()) {

    auto direction_property_value_9_string = TRY(direction_property_value_9.to_string(vm));

    if (direction_property_value_9_string == "normal"sv)
        direction_value_9 = PlaybackDirection::Normal;

    else if (direction_property_value_9_string == "reverse"sv)
        direction_value_9 = PlaybackDirection::Reverse;

    else if (direction_property_value_9_string == "alternate"sv)
        direction_value_9 = PlaybackDirection::Alternate;

    else if (direction_property_value_9_string == "alternate-reverse"sv)
        direction_value_9 = PlaybackDirection::AlternateReverse;

    else
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidEnumerationValue, direction_property_value_9_string, "PlaybackDirection");

    }

    dictionary_union_type.direction = direction_value_9;

    auto duration_property_value_10 = JS::js_undefined();
    if (arg1.is_object())
        duration_property_value_10 = TRY(arg1.as_object().get("duration"));

    auto duration_property_value_10_to_variant = [&vm, &realm](JS::Value duration_property_value_10) -> JS::ThrowCompletionOr<Variant<double, String>> {
        // These might be unused.
        (void)vm;
        (void)realm;

        if (duration_property_value_10.is_object()) {
            [[maybe_unused]] auto& duration_property_value_10_object = duration_property_value_10.as_object();

        }

        if (duration_property_value_10.is_number()) {

    double duration_property_value_10_number = TRY(duration_property_value_10.to_double(vm));

            return { duration_property_value_10_number };
        }

    String duration_property_value_10_string;
    if (!false || !duration_property_value_10.is_null()) {
        duration_property_value_10_string = TRY(WebIDL::to_string(vm, duration_property_value_10));
    }

        return { duration_property_value_10_string };

    };

    Variant<double, String> duration_value_10 = duration_property_value_10.is_undefined() ? MUST(String::from_utf8("auto"sv)) : TRY(duration_property_value_10_to_variant(duration_property_value_10));

    dictionary_union_type.duration = duration_value_10;

    auto easing_property_value_11 = JS::js_undefined();
    if (arg1.is_object())
        easing_property_value_11 = TRY(arg1.as_object().get("easing"));

    String easing_value_11;

    if (!easing_property_value_11.is_undefined()) {
        if (!false || !easing_property_value_11.is_null())
            easing_value_11 = TRY(WebIDL::to_string(vm, easing_property_value_11));
    } else {
        easing_value_11 = MUST(String::from_utf8("linear"sv));
    }

    dictionary_union_type.easing = easing_value_11;

    auto end_delay_property_value_12 = JS::js_undefined();
    if (arg1.is_object())
        end_delay_property_value_12 = TRY(arg1.as_object().get("endDelay"));

    double end_delay_value_12;

    if (!end_delay_property_value_12.is_undefined())
        end_delay_value_12 = TRY(end_delay_property_value_12.to_double(vm));

    else
        end_delay_value_12 = 0;

    if (isinf(end_delay_value_12) || isnan(end_delay_value_12)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "endDelay");
    }
    
    dictionary_union_type.end_delay = end_delay_value_12;

    auto fill_property_value_13 = JS::js_undefined();
    if (arg1.is_object())
        fill_property_value_13 = TRY(arg1.as_object().get("fill"));

    FillMode fill_value_13 { FillMode::Auto };

    if (!fill_property_value_13.is_undefined()) {

    auto fill_property_value_13_string = TRY(fill_property_value_13.to_string(vm));

    if (fill_property_value_13_string == "none"sv)
        fill_value_13 = FillMode::None;

    else if (fill_property_value_13_string == "forwards"sv)
        fill_value_13 = FillMode::Forwards;

    else if (fill_property_value_13_string == "backwards"sv)
        fill_value_13 = FillMode::Backwards;

    else if (fill_property_value_13_string == "both"sv)
        fill_value_13 = FillMode::Both;

    else if (fill_property_value_13_string == "auto"sv)
        fill_value_13 = FillMode::Auto;

    else
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidEnumerationValue, fill_property_value_13_string, "FillMode");

    }

    dictionary_union_type.fill = fill_value_13;

    auto iteration_start_property_value_14 = JS::js_undefined();
    if (arg1.is_object())
        iteration_start_property_value_14 = TRY(arg1.as_object().get("iterationStart"));

    double iteration_start_value_14;

    if (!iteration_start_property_value_14.is_undefined())
        iteration_start_value_14 = TRY(iteration_start_property_value_14.to_double(vm));

    else
        iteration_start_value_14 = 0.0;

    if (isinf(iteration_start_value_14) || isnan(iteration_start_value_14)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "iterationStart");
    }
    
    dictionary_union_type.iteration_start = iteration_start_value_14;

    auto iterations_property_value_15 = JS::js_undefined();
    if (arg1.is_object())
        iterations_property_value_15 = TRY(arg1.as_object().get("iterations"));

    double iterations_value_15;

    if (!iterations_property_value_15.is_undefined())
        iterations_value_15 = TRY(iterations_property_value_15.to_double(vm));

    else
        iterations_value_15 = 1.0;

    dictionary_union_type.iterations = iterations_value_15;

        return dictionary_union_type;
    };

    auto arg1_to_variant = [&vm, &realm, &arg1_to_dictionary](JS::Value arg1) -> JS::ThrowCompletionOr<Variant<double, KeyframeAnimationOptions>> {
        // These might be unused.
        (void)vm;
        (void)realm;

        if (arg1.is_nullish())
            return Variant<double, KeyframeAnimationOptions> { TRY(arg1_to_dictionary(arg1)) };

        if (arg1.is_object()) {
            [[maybe_unused]] auto& arg1_object = arg1.as_object();

        return Variant<double, KeyframeAnimationOptions> { TRY(arg1_to_dictionary(arg1)) };

        }

        if (arg1.is_number()) {

    double arg1_number = TRY(arg1.to_double(vm));

            return { arg1_number };
        }

    double arg1_number = TRY(arg1.to_double(vm));

        return { arg1_number };

    };

    Variant<double, KeyframeAnimationOptions> options = arg1.is_undefined() ? TRY(arg1_to_dictionary(arg1)) : TRY(arg1_to_variant(arg1));

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->animate(keyframes, options); }));

    return &const_cast<Animation&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::get_animations)
{
    WebIDL::log_trace(vm, "ElementPrototype::get_animations");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    auto arg0 = vm.argument(0);

    if (!arg0.is_nullish() && !arg0.is_object())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "GetAnimationsOptions");

    GetAnimationsOptions options {};

    auto pseudo_element_property_value_21 = JS::js_undefined();
    if (arg0.is_object())
        pseudo_element_property_value_21 = TRY(arg0.as_object().get("pseudoElement"));

    Optional<String> pseudo_element_value_21;

    if (!pseudo_element_property_value_21.is_undefined()) {
        if (!pseudo_element_property_value_21.is_null())
            pseudo_element_value_21 = TRY(WebIDL::to_string(vm, pseudo_element_property_value_21));
    }

    options.pseudo_element = pseudo_element_value_21;

    auto subtree_property_value_22 = JS::js_undefined();
    if (arg0.is_object())
        subtree_property_value_22 = TRY(arg0.as_object().get("subtree"));

    bool subtree_value_22;

    if (!subtree_property_value_22.is_undefined())

    subtree_value_22 = subtree_property_value_22.to_boolean();

    else
        subtree_value_22 = static_cast<bool>(false);

    options.subtree = subtree_value_22;

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->get_animations(options); }));

    auto new_array0 = MUST(JS::Array::create(realm, 0));

    for (size_t i0 = 0; i0 < retval.size(); ++i0) {
        auto& element0 = retval.at(i0);

            auto* wrapped_element0 = &(*element0);

        auto property_index0 = JS::PropertyKey { i0 };
        MUST(new_array0->create_data_property(property_index0, wrapped_element0));
    }

    return new_array0;

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::prepend)
{
    WebIDL::log_trace(vm, "ElementPrototype::prepend");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    auto arg0_to_variant = [&vm, &realm](JS::Value arg0) -> JS::ThrowCompletionOr<Variant<GC::Root<Node>, String>> {
        // These might be unused.
        (void)vm;
        (void)realm;

        if (arg0.is_object()) {
            [[maybe_unused]] auto& arg0_object = arg0.as_object();

            if (is<PlatformObject>(arg0_object)) {

                if (is<Node>(arg0_object))
                    return GC::make_root(static_cast<Node&>(arg0_object));

            }

        }

    String arg0_string;
    if (!false || !arg0.is_null()) {
        arg0_string = TRY(WebIDL::to_string(vm, arg0));
    }

        return { arg0_string };

    };

        Vector<Variant<GC::Root<Node>, String>> nodes;

        if (vm.argument_count() > 0) {
            nodes.ensure_capacity(vm.argument_count() - 0);

            for (size_t i = 0; i < vm.argument_count(); ++i) {
                auto result = TRY(arg0_to_variant(vm.argument(i)));
                nodes.unchecked_append(move(result));
            }
        }
    
    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->prepend(move(nodes)); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    [[maybe_unused]] auto retval = retval_or_exception.release_value();

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::append)
{
    WebIDL::log_trace(vm, "ElementPrototype::append");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    auto arg0_to_variant = [&vm, &realm](JS::Value arg0) -> JS::ThrowCompletionOr<Variant<GC::Root<Node>, String>> {
        // These might be unused.
        (void)vm;
        (void)realm;

        if (arg0.is_object()) {
            [[maybe_unused]] auto& arg0_object = arg0.as_object();

            if (is<PlatformObject>(arg0_object)) {

                if (is<Node>(arg0_object))
                    return GC::make_root(static_cast<Node&>(arg0_object));

            }

        }

    String arg0_string;
    if (!false || !arg0.is_null()) {
        arg0_string = TRY(WebIDL::to_string(vm, arg0));
    }

        return { arg0_string };

    };

        Vector<Variant<GC::Root<Node>, String>> nodes;

        if (vm.argument_count() > 0) {
            nodes.ensure_capacity(vm.argument_count() - 0);

            for (size_t i = 0; i < vm.argument_count(); ++i) {
                auto result = TRY(arg0_to_variant(vm.argument(i)));
                nodes.unchecked_append(move(result));
            }
        }
    
    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->append(move(nodes)); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    [[maybe_unused]] auto retval = retval_or_exception.release_value();

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::replace_children)
{
    WebIDL::log_trace(vm, "ElementPrototype::replace_children");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    auto arg0_to_variant = [&vm, &realm](JS::Value arg0) -> JS::ThrowCompletionOr<Variant<GC::Root<Node>, String>> {
        // These might be unused.
        (void)vm;
        (void)realm;

        if (arg0.is_object()) {
            [[maybe_unused]] auto& arg0_object = arg0.as_object();

            if (is<PlatformObject>(arg0_object)) {

                if (is<Node>(arg0_object))
                    return GC::make_root(static_cast<Node&>(arg0_object));

            }

        }

    String arg0_string;
    if (!false || !arg0.is_null()) {
        arg0_string = TRY(WebIDL::to_string(vm, arg0));
    }

        return { arg0_string };

    };

        Vector<Variant<GC::Root<Node>, String>> nodes;

        if (vm.argument_count() > 0) {
            nodes.ensure_capacity(vm.argument_count() - 0);

            for (size_t i = 0; i < vm.argument_count(); ++i) {
                auto result = TRY(arg0_to_variant(vm.argument(i)));
                nodes.unchecked_append(move(result));
            }
        }
    
    auto& reactions_stack = HTML::relevant_agent(*impl).custom_element_reactions_stack;
    reactions_stack.element_queue_stack.append({});

    auto retval_or_exception = throw_dom_exception_if_needed(vm, [&] { return impl->replace_children(move(nodes)); });

    auto queue = reactions_stack.element_queue_stack.take_last();
    Bindings::invoke_custom_element_reactions(queue);

    if (retval_or_exception.is_error())
        return retval_or_exception.release_error();

    [[maybe_unused]] auto retval = retval_or_exception.release_value();

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::query_selector)
{
    WebIDL::log_trace(vm, "ElementPrototype::query_selector");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "querySelector");

    auto arg0 = vm.argument(0);

    String selectors;
    if (!false || !arg0.is_null()) {
        selectors = TRY(WebIDL::to_string(vm, arg0));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->query_selector(selectors); }));

    if (!retval) {
        return JS::js_null();
    } else {

    return &const_cast<Element&>(*retval);

    }

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::query_selector_all)
{
    WebIDL::log_trace(vm, "ElementPrototype::query_selector_all");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "querySelectorAll");

    auto arg0 = vm.argument(0);

    String selectors;
    if (!false || !arg0.is_null()) {
        selectors = TRY(WebIDL::to_string(vm, arg0));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->query_selector_all(selectors); }));

    return &const_cast<NodeList&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::scroll)
{
    WebIDL::log_trace(vm, "ElementPrototype::scroll");

    Optional<IDL::EffectiveOverloadSet> effective_overload_set;
    switch (min(2, vm.argument_count())) {

    case 0: {
        Vector<IDL::EffectiveOverloadSet::Item> overloads;
        overloads.ensure_capacity(1);

        overloads.empend(0, Vector<NonnullRefPtr<IDL::Type const>> { }, Vector<IDL::Optionality> { });

        effective_overload_set.emplace(move(overloads), 0);
        break;
    }

    case 1: {
        Vector<IDL::EffectiveOverloadSet::Item> overloads;
        overloads.ensure_capacity(1);

        overloads.empend(0, Vector<NonnullRefPtr<IDL::Type const>> { make_ref_counted<IDL::Type>("ScrollToOptions", false)}, Vector<IDL::Optionality> { IDL::Optionality::Optional});

        effective_overload_set.emplace(move(overloads), 0);
        break;
    }

    case 2: {
        Vector<IDL::EffectiveOverloadSet::Item> overloads;
        overloads.ensure_capacity(1);

        overloads.empend(1, Vector<NonnullRefPtr<IDL::Type const>> { make_ref_counted<IDL::Type>("unrestricted double", false), make_ref_counted<IDL::Type>("unrestricted double", false)}, Vector<IDL::Optionality> { IDL::Optionality::Required, IDL::Optionality::Required});

        effective_overload_set.emplace(move(overloads), 0);
        break;
    }

    }

    Vector<StringView> dictionary_types {
    "ScrollToOptions"sv,
};


    if (!effective_overload_set.has_value())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::OverloadResolutionFailed);

    auto chosen_overload = TRY(WebIDL::resolve_overload(vm, effective_overload_set.value(), dictionary_types));
    switch (chosen_overload.callable_id) {

    case 0:

        return scroll0(vm);

    case 1:

        return scroll1(vm);

    default:
        VERIFY_NOT_REACHED();
    }
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::scroll_to)
{
    WebIDL::log_trace(vm, "ElementPrototype::scroll_to");

    Optional<IDL::EffectiveOverloadSet> effective_overload_set;
    switch (min(2, vm.argument_count())) {

    case 0: {
        Vector<IDL::EffectiveOverloadSet::Item> overloads;
        overloads.ensure_capacity(1);

        overloads.empend(0, Vector<NonnullRefPtr<IDL::Type const>> { }, Vector<IDL::Optionality> { });

        effective_overload_set.emplace(move(overloads), 0);
        break;
    }

    case 1: {
        Vector<IDL::EffectiveOverloadSet::Item> overloads;
        overloads.ensure_capacity(1);

        overloads.empend(0, Vector<NonnullRefPtr<IDL::Type const>> { make_ref_counted<IDL::Type>("ScrollToOptions", false)}, Vector<IDL::Optionality> { IDL::Optionality::Optional});

        effective_overload_set.emplace(move(overloads), 0);
        break;
    }

    case 2: {
        Vector<IDL::EffectiveOverloadSet::Item> overloads;
        overloads.ensure_capacity(1);

        overloads.empend(1, Vector<NonnullRefPtr<IDL::Type const>> { make_ref_counted<IDL::Type>("unrestricted double", false), make_ref_counted<IDL::Type>("unrestricted double", false)}, Vector<IDL::Optionality> { IDL::Optionality::Required, IDL::Optionality::Required});

        effective_overload_set.emplace(move(overloads), 0);
        break;
    }

    }

    Vector<StringView> dictionary_types {
    "ScrollToOptions"sv,
};


    if (!effective_overload_set.has_value())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::OverloadResolutionFailed);

    auto chosen_overload = TRY(WebIDL::resolve_overload(vm, effective_overload_set.value(), dictionary_types));
    switch (chosen_overload.callable_id) {

    case 0:

        return scroll_to0(vm);

    case 1:

        return scroll_to1(vm);

    default:
        VERIFY_NOT_REACHED();
    }
}

JS_DEFINE_NATIVE_FUNCTION(ElementPrototype::scroll_by)
{
    WebIDL::log_trace(vm, "ElementPrototype::scroll_by");

    Optional<IDL::EffectiveOverloadSet> effective_overload_set;
    switch (min(2, vm.argument_count())) {

    case 0: {
        Vector<IDL::EffectiveOverloadSet::Item> overloads;
        overloads.ensure_capacity(1);

        overloads.empend(0, Vector<NonnullRefPtr<IDL::Type const>> { }, Vector<IDL::Optionality> { });

        effective_overload_set.emplace(move(overloads), 0);
        break;
    }

    case 1: {
        Vector<IDL::EffectiveOverloadSet::Item> overloads;
        overloads.ensure_capacity(1);

        overloads.empend(0, Vector<NonnullRefPtr<IDL::Type const>> { make_ref_counted<IDL::Type>("ScrollToOptions", false)}, Vector<IDL::Optionality> { IDL::Optionality::Optional});

        effective_overload_set.emplace(move(overloads), 0);
        break;
    }

    case 2: {
        Vector<IDL::EffectiveOverloadSet::Item> overloads;
        overloads.ensure_capacity(1);

        overloads.empend(1, Vector<NonnullRefPtr<IDL::Type const>> { make_ref_counted<IDL::Type>("unrestricted double", false), make_ref_counted<IDL::Type>("unrestricted double", false)}, Vector<IDL::Optionality> { IDL::Optionality::Required, IDL::Optionality::Required});

        effective_overload_set.emplace(move(overloads), 0);
        break;
    }

    }

    Vector<StringView> dictionary_types {
    "ScrollToOptions"sv,
};


    if (!effective_overload_set.has_value())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::OverloadResolutionFailed);

    auto chosen_overload = TRY(WebIDL::resolve_overload(vm, effective_overload_set.value(), dictionary_types));
    switch (chosen_overload.callable_id) {

    case 0:

        return scroll_by0(vm);

    case 1:

        return scroll_by1(vm);

    default:
        VERIFY_NOT_REACHED();
    }
}

} // namespace Web::Bindings
