
#pragma once

#include <LibJS/Runtime/Object.h>

namespace Web::Bindings {

class SubtleCryptoPrototype : public JS::Object {
    JS_OBJECT(SubtleCryptoPrototype, JS::Object);
    GC_DECLARE_ALLOCATOR(SubtleCryptoPrototype);
public:
    explicit SubtleCryptoPrototype(JS::Realm&);
    virtual void initialize(JS::Realm&) override;
    virtual ~SubtleCryptoPrototype() override;
private:

    JS_DECLARE_NATIVE_FUNCTION(decrypt);
        
    JS_DECLARE_NATIVE_FUNCTION(sign);
        
    JS_DECLARE_NATIVE_FUNCTION(unwrap_key);
        
    JS_DECLARE_NATIVE_FUNCTION(encrypt);
        
    JS_DECLARE_NATIVE_FUNCTION(derive_bits);
        
    JS_DECLARE_NATIVE_FUNCTION(import_key);
        
    JS_DECLARE_NATIVE_FUNCTION(wrap_key);
        
    JS_DECLARE_NATIVE_FUNCTION(verify);
        
    JS_DECLARE_NATIVE_FUNCTION(derive_key);
        
    JS_DECLARE_NATIVE_FUNCTION(digest);
        
    JS_DECLARE_NATIVE_FUNCTION(generate_key);
        
    JS_DECLARE_NATIVE_FUNCTION(export_key);
        

};


enum class KeyFormat : u8 {

    Raw,

    Spki,

    Pkcs8,

    Jwk,

};

inline String idl_enum_to_string(KeyFormat value)
{
    switch (value) {

    case KeyFormat::Raw:
        return "raw"_string;

    case KeyFormat::Spki:
        return "spki"_string;

    case KeyFormat::Pkcs8:
        return "pkcs8"_string;

    case KeyFormat::Jwk:
        return "jwk"_string;

    }
    VERIFY_NOT_REACHED();
}

} // namespace Web::Bindings
    