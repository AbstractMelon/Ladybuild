
#include <AK/Function.h>
#include <LibIDL/Types.h>
#include <LibJS/Runtime/Array.h>
#include <LibJS/Runtime/ArrayBuffer.h>
#include <LibJS/Runtime/DataView.h>
#include <LibJS/Runtime/Error.h>
#include <LibJS/Runtime/FunctionObject.h>
#include <LibJS/Runtime/GlobalObject.h>
#include <LibJS/Runtime/Iterator.h>
#include <LibJS/Runtime/PromiseConstructor.h>
#include <LibJS/Runtime/TypedArray.h>
#include <LibJS/Runtime/Value.h>
#include <LibJS/Runtime/ValueInlines.h>
#include <LibURL/Origin.h>
#include <LibWeb/Bindings/ServiceWorkerContainerPrototype.h>
#include <LibWeb/Bindings/ExceptionOrUtils.h>
#include <LibWeb/Bindings/Intrinsics.h>
#include <LibWeb/DOM/Element.h>
#include <LibWeb/DOM/Event.h>
#include <LibWeb/DOM/IDLEventListener.h>
#include <LibWeb/DOM/NodeFilter.h>
#include <LibWeb/DOM/Range.h>
#include <LibWeb/HTML/Numbers.h>
#include <LibWeb/HTML/Scripting/Agent.h>
#include <LibWeb/HTML/Scripting/Environments.h>
#include <LibWeb/HTML/Window.h>
#include <LibWeb/HTML/WindowProxy.h>
#include <LibWeb/Infra/Strings.h>
#include <LibWeb/WebIDL/AbstractOperations.h>
#include <LibWeb/WebIDL/Buffers.h>
#include <LibWeb/WebIDL/OverloadResolution.h>
#include <LibWeb/WebIDL/Promise.h>
#include <LibWeb/WebIDL/Tracing.h>
#include <LibWeb/WebIDL/Types.h>

#if __has_include(<LibWeb/Bindings/EventTargetPrototype.h>)
#    include <LibWeb/Bindings/EventTargetPrototype.h>
#endif


#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/ServiceWorker/ServiceWorkerContainer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/EventTarget.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Worker.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/ServiceWorker/ServiceWorkerRegistration.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/AbortSignal.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Event.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/MessagePort.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Fetch/Request.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/ServiceWorker/ServiceWorker.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Fetch/Headers.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/FileAPI/Blob.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/ReadableStream.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/XHR/FormData.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOMURL/URLSearchParams.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/ReadableStreamBYOBReader.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/ReadableStreamDefaultReader.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/WritableStream.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/FileAPI/File.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/WritableStreamDefaultWriter.h>

// FIXME: This is a total hack until we can figure out the namespace for a given type somehow.
using namespace Web::Animations;
using namespace Web::Clipboard;
using namespace Web::CredentialManagement;
using namespace Web::Crypto;
using namespace Web::CSS;
using namespace Web::DOM;
using namespace Web::DOMURL;
using namespace Web::Encoding;
using namespace Web::EntriesAPI;
using namespace Web::EventTiming;
using namespace Web::Fetch;
using namespace Web::FileAPI;
using namespace Web::Geometry;
using namespace Web::HighResolutionTime;
using namespace Web::HTML;
using namespace Web::IndexedDB;
using namespace Web::Internals;
using namespace Web::IntersectionObserver;
using namespace Web::MediaCapabilitiesAPI;
using namespace Web::MediaSourceExtensions;
using namespace Web::NavigationTiming;
using namespace Web::PerformanceTimeline;
using namespace Web::RequestIdleCallback;
using namespace Web::ResizeObserver;
using namespace Web::Selection;
using namespace Web::ServiceWorker;
using namespace Web::StorageAPI;
using namespace Web::Streams;
using namespace Web::SVG;
using namespace Web::UIEvents;
using namespace Web::URLPattern;
using namespace Web::UserTiming;
using namespace Web::WebAssembly;
using namespace Web::WebAudio;
using namespace Web::WebGL;
using namespace Web::WebGL::Extensions;
using namespace Web::WebIDL;
using namespace Web::WebVTT;
using namespace Web::XHR;

namespace Web::Bindings {

GC_DEFINE_ALLOCATOR(ServiceWorkerContainerPrototype);

ServiceWorkerContainerPrototype::ServiceWorkerContainerPrototype([[maybe_unused]] JS::Realm& realm)
    : Object(realm, nullptr)

{
}

ServiceWorkerContainerPrototype::~ServiceWorkerContainerPrototype()
{
}

void ServiceWorkerContainerPrototype::initialize(JS::Realm& realm)
{


    [[maybe_unused]] auto& vm = realm.vm();
    [[maybe_unused]] u8 default_attributes = JS::Attribute::Enumerable | JS::Attribute::Configurable | JS::Attribute::Writable;



    set_prototype(&ensure_web_prototype<EventTargetPrototype>(realm, "EventTarget"_fly_string));


    define_direct_property("controller", JS::js_undefined(), default_attributes | JS::Attribute::Unimplemented);
            
    define_direct_property("ready", JS::js_undefined(), default_attributes | JS::Attribute::Unimplemented);
            
    define_native_accessor(realm, "oncontrollerchange", oncontrollerchange_getter, oncontrollerchange_setter, default_attributes);

    define_native_accessor(realm, "onmessage", onmessage_getter, onmessage_setter, default_attributes);

    define_native_accessor(realm, "onmessageerror", onmessageerror_getter, onmessageerror_setter, default_attributes);

        define_direct_property("getRegistrations", JS::js_undefined(), default_attributes | JS::Attribute::Unimplemented);
            
        define_direct_property("startMessages", JS::js_undefined(), default_attributes | JS::Attribute::Unimplemented);
            
    define_native_function(realm, "register", register_, 1, default_attributes);

    define_native_function(realm, "getRegistration", get_registration, 0, default_attributes);

    define_direct_property(vm.well_known_symbol_to_string_tag(), JS::PrimitiveString::create(vm, "ServiceWorkerContainer"_string), JS::Attribute::Configurable);

    Base::initialize(realm);

}

[[maybe_unused]] static JS::ThrowCompletionOr<ServiceWorker::ServiceWorkerContainer*> impl_from(JS::VM& vm)
{
    auto this_value = vm.this_value();
    JS::Object* this_object = nullptr;
    if (this_value.is_nullish())
        this_object = &vm.current_realm()->global_object();
    else
        this_object = TRY(this_value.to_object(vm));

    if (!is<ServiceWorker::ServiceWorkerContainer>(this_object))
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "ServiceWorkerContainer");
    return static_cast<ServiceWorker::ServiceWorkerContainer*>(this_object);
}

JS_DEFINE_NATIVE_FUNCTION(ServiceWorkerContainerPrototype::oncontrollerchange_getter)
{
    WebIDL::log_trace(vm, "ServiceWorkerContainerPrototype::oncontrollerchange_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->oncontrollerchange(); }));

  if (!retval) {
      return JS::js_null();
  } else {
      return retval->callback;
  }

}

JS_DEFINE_NATIVE_FUNCTION(ServiceWorkerContainerPrototype::oncontrollerchange_setter)
{
    WebIDL::log_trace(vm, "ServiceWorkerContainerPrototype::oncontrollerchange_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "ServiceWorkerContainer setter");

    auto value = vm.argument(0);

    GC::Ptr<WebIDL::CallbackType> cpp_value;
    if (value.is_object())
        cpp_value = vm.heap().allocate<WebIDL::CallbackType>(value.as_object(), HTML::incumbent_realm(), WebIDL::OperationReturnsPromise::No);

    TRY(throw_dom_exception_if_needed(vm, [&] { return impl->set_oncontrollerchange(cpp_value); }));

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ServiceWorkerContainerPrototype::onmessage_getter)
{
    WebIDL::log_trace(vm, "ServiceWorkerContainerPrototype::onmessage_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->onmessage(); }));

  if (!retval) {
      return JS::js_null();
  } else {
      return retval->callback;
  }

}

JS_DEFINE_NATIVE_FUNCTION(ServiceWorkerContainerPrototype::onmessage_setter)
{
    WebIDL::log_trace(vm, "ServiceWorkerContainerPrototype::onmessage_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "ServiceWorkerContainer setter");

    auto value = vm.argument(0);

    GC::Ptr<WebIDL::CallbackType> cpp_value;
    if (value.is_object())
        cpp_value = vm.heap().allocate<WebIDL::CallbackType>(value.as_object(), HTML::incumbent_realm(), WebIDL::OperationReturnsPromise::No);

    TRY(throw_dom_exception_if_needed(vm, [&] { return impl->set_onmessage(cpp_value); }));

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ServiceWorkerContainerPrototype::onmessageerror_getter)
{
    WebIDL::log_trace(vm, "ServiceWorkerContainerPrototype::onmessageerror_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->onmessageerror(); }));

  if (!retval) {
      return JS::js_null();
  } else {
      return retval->callback;
  }

}

JS_DEFINE_NATIVE_FUNCTION(ServiceWorkerContainerPrototype::onmessageerror_setter)
{
    WebIDL::log_trace(vm, "ServiceWorkerContainerPrototype::onmessageerror_setter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    auto* impl = TRY(impl_from(vm));
    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "ServiceWorkerContainer setter");

    auto value = vm.argument(0);

    GC::Ptr<WebIDL::CallbackType> cpp_value;
    if (value.is_object())
        cpp_value = vm.heap().allocate<WebIDL::CallbackType>(value.as_object(), HTML::incumbent_realm(), WebIDL::OperationReturnsPromise::No);

    TRY(throw_dom_exception_if_needed(vm, [&] { return impl->set_onmessageerror(cpp_value); }));

    return JS::js_undefined();
}

JS_DEFINE_NATIVE_FUNCTION(ServiceWorkerContainerPrototype::register_)
{
    WebIDL::log_trace(vm, "ServiceWorkerContainerPrototype::register_");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto steps = [&realm, &vm]() -> JS::ThrowCompletionOr<GC::Ref<WebIDL::Promise>> {
        (void)realm;

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "register");

    auto arg0 = vm.argument(0);

    String script_url;
    if (!false || !arg0.is_null()) {
        script_url = TRY(WebIDL::to_usv_string(vm, arg0));
    }

    auto arg1 = vm.argument(1);

    if (!arg1.is_nullish() && !arg1.is_object())
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "RegistrationOptions");

    RegistrationOptions options {};

    auto scope_property_value_0 = JS::js_undefined();
    if (arg1.is_object())
        scope_property_value_0 = TRY(arg1.as_object().get("scope"));

    if (!scope_property_value_0.is_undefined()) {

    Optional<String> scope_value_0;

    if (!scope_property_value_0.is_undefined()) {
        if (!false || !scope_property_value_0.is_null())
            scope_value_0 = TRY(WebIDL::to_usv_string(vm, scope_property_value_0));
    }

    options.scope = scope_value_0;

    }

    auto type_property_value_1 = JS::js_undefined();
    if (arg1.is_object())
        type_property_value_1 = TRY(arg1.as_object().get("type"));

    WorkerType type_value_1 { WorkerType::Classic };

    if (!type_property_value_1.is_undefined()) {

    auto type_property_value_1_string = TRY(type_property_value_1.to_string(vm));

    if (type_property_value_1_string == "classic"sv)
        type_value_1 = WorkerType::Classic;

    else if (type_property_value_1_string == "module"sv)
        type_value_1 = WorkerType::Module;

    else
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidEnumerationValue, type_property_value_1_string, "WorkerType");

    }

    options.type = type_value_1;

    auto update_via_cache_property_value_2 = JS::js_undefined();
    if (arg1.is_object())
        update_via_cache_property_value_2 = TRY(arg1.as_object().get("updateViaCache"));

    ServiceWorkerUpdateViaCache update_via_cache_value_2 { ServiceWorkerUpdateViaCache::Imports };

    if (!update_via_cache_property_value_2.is_undefined()) {

    auto update_via_cache_property_value_2_string = TRY(update_via_cache_property_value_2.to_string(vm));

    if (update_via_cache_property_value_2_string == "imports"sv)
        update_via_cache_value_2 = ServiceWorkerUpdateViaCache::Imports;

    else if (update_via_cache_property_value_2_string == "all"sv)
        update_via_cache_value_2 = ServiceWorkerUpdateViaCache::All;

    else if (update_via_cache_property_value_2_string == "none"sv)
        update_via_cache_value_2 = ServiceWorkerUpdateViaCache::None;

    else
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidEnumerationValue, update_via_cache_property_value_2_string, "ServiceWorkerUpdateViaCache");

    }

    options.update_via_cache = update_via_cache_value_2;

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->register_(script_url, options); }));

        return retval;
    };

    auto maybe_retval = steps();

    // And then, if an exception E was thrown:
    // 1. If op has a return type that is a promise type, then return ! Call(%Promise.reject%, %Promise%, «E»).
    // 2. Otherwise, end these steps and allow the exception to propagate.
    // NOTE: We know that this is a Promise return type statically by the IDL.
    if (maybe_retval.is_throw_completion())
        return WebIDL::create_rejected_promise(realm, maybe_retval.error_value())->promise();

    auto retval = maybe_retval.release_value();

    return GC::Ref { as<JS::Promise>(*retval->promise()) };

}

JS_DEFINE_NATIVE_FUNCTION(ServiceWorkerContainerPrototype::get_registration)
{
    WebIDL::log_trace(vm, "ServiceWorkerContainerPrototype::get_registration");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto steps = [&realm, &vm]() -> JS::ThrowCompletionOr<GC::Ref<WebIDL::Promise>> {
        (void)realm;

    auto* impl = TRY(impl_from(vm));

    auto arg0 = vm.argument(0);

    String client_url;

    if (!arg0.is_undefined()) {
        if (!false || !arg0.is_null())
            client_url = TRY(WebIDL::to_usv_string(vm, arg0));
    } else {
        client_url = MUST(String::from_utf8(""sv));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->get_registration(client_url); }));

        return retval;
    };

    auto maybe_retval = steps();

    // And then, if an exception E was thrown:
    // 1. If op has a return type that is a promise type, then return ! Call(%Promise.reject%, %Promise%, «E»).
    // 2. Otherwise, end these steps and allow the exception to propagate.
    // NOTE: We know that this is a Promise return type statically by the IDL.
    if (maybe_retval.is_throw_completion())
        return WebIDL::create_rejected_promise(realm, maybe_retval.error_value())->promise();

    auto retval = maybe_retval.release_value();

    return GC::Ref { as<JS::Promise>(*retval->promise()) };

}

} // namespace Web::Bindings
