
#include <AK/Function.h>
#include <LibIDL/Types.h>
#include <LibJS/Runtime/Array.h>
#include <LibJS/Runtime/ArrayBuffer.h>
#include <LibJS/Runtime/DataView.h>
#include <LibJS/Runtime/Error.h>
#include <LibJS/Runtime/FunctionObject.h>
#include <LibJS/Runtime/GlobalObject.h>
#include <LibJS/Runtime/Iterator.h>
#include <LibJS/Runtime/PromiseConstructor.h>
#include <LibJS/Runtime/TypedArray.h>
#include <LibJS/Runtime/Value.h>
#include <LibJS/Runtime/ValueInlines.h>
#include <LibURL/Origin.h>
#include <LibWeb/Bindings/WorkerNavigatorPrototype.h>
#include <LibWeb/Bindings/ExceptionOrUtils.h>
#include <LibWeb/Bindings/Intrinsics.h>
#include <LibWeb/DOM/Element.h>
#include <LibWeb/DOM/Event.h>
#include <LibWeb/DOM/IDLEventListener.h>
#include <LibWeb/DOM/NodeFilter.h>
#include <LibWeb/DOM/Range.h>
#include <LibWeb/HTML/Numbers.h>
#include <LibWeb/HTML/Scripting/Agent.h>
#include <LibWeb/HTML/Scripting/Environments.h>
#include <LibWeb/HTML/Window.h>
#include <LibWeb/HTML/WindowProxy.h>
#include <LibWeb/Infra/Strings.h>
#include <LibWeb/WebIDL/AbstractOperations.h>
#include <LibWeb/WebIDL/Buffers.h>
#include <LibWeb/WebIDL/OverloadResolution.h>
#include <LibWeb/WebIDL/Promise.h>
#include <LibWeb/WebIDL/Tracing.h>
#include <LibWeb/WebIDL/Types.h>

#if __has_include(<LibWeb/Bindings/ObjectPrototype.h>)
#    include <LibWeb/Bindings/ObjectPrototype.h>
#endif


#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/WorkerNavigator.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/MediaCapabilitiesAPI/MediaCapabilities.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/EncryptedMediaExtensions/EncryptedMediaExtensions.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/StorageAPI/StorageManager.h>

// FIXME: This is a total hack until we can figure out the namespace for a given type somehow.
using namespace Web::Animations;
using namespace Web::Clipboard;
using namespace Web::CredentialManagement;
using namespace Web::Crypto;
using namespace Web::CSS;
using namespace Web::DOM;
using namespace Web::DOMURL;
using namespace Web::Encoding;
using namespace Web::EntriesAPI;
using namespace Web::EventTiming;
using namespace Web::Fetch;
using namespace Web::FileAPI;
using namespace Web::Geometry;
using namespace Web::HighResolutionTime;
using namespace Web::HTML;
using namespace Web::IndexedDB;
using namespace Web::Internals;
using namespace Web::IntersectionObserver;
using namespace Web::MediaCapabilitiesAPI;
using namespace Web::MediaSourceExtensions;
using namespace Web::NavigationTiming;
using namespace Web::PerformanceTimeline;
using namespace Web::RequestIdleCallback;
using namespace Web::ResizeObserver;
using namespace Web::Selection;
using namespace Web::ServiceWorker;
using namespace Web::StorageAPI;
using namespace Web::Streams;
using namespace Web::SVG;
using namespace Web::UIEvents;
using namespace Web::URLPattern;
using namespace Web::UserTiming;
using namespace Web::WebAssembly;
using namespace Web::WebAudio;
using namespace Web::WebGL;
using namespace Web::WebGL::Extensions;
using namespace Web::WebIDL;
using namespace Web::WebVTT;
using namespace Web::XHR;

namespace Web::Bindings {

GC_DEFINE_ALLOCATOR(WorkerNavigatorPrototype);

WorkerNavigatorPrototype::WorkerNavigatorPrototype([[maybe_unused]] JS::Realm& realm)
    : Object(ConstructWithPrototypeTag::Tag, realm.intrinsics().object_prototype())

{
}

WorkerNavigatorPrototype::~WorkerNavigatorPrototype()
{
}

void WorkerNavigatorPrototype::initialize(JS::Realm& realm)
{


    [[maybe_unused]] auto& vm = realm.vm();
    [[maybe_unused]] u8 default_attributes = JS::Attribute::Enumerable | JS::Attribute::Configurable | JS::Attribute::Writable;



    set_prototype(realm.intrinsics().object_prototype());


    define_native_accessor(realm, "mediaCapabilities", media_capabilities_getter, nullptr, default_attributes);

    define_native_accessor(realm, "serviceWorker", service_worker_getter, nullptr, default_attributes);

    define_native_accessor(realm, "appCodeName", app_code_name_getter, nullptr, default_attributes);

    define_native_accessor(realm, "appName", app_name_getter, nullptr, default_attributes);

    define_native_accessor(realm, "appVersion", app_version_getter, nullptr, default_attributes);

    define_native_accessor(realm, "platform", platform_getter, nullptr, default_attributes);

    define_native_accessor(realm, "product", product_getter, nullptr, default_attributes);

    define_native_accessor(realm, "productSub", product_sub_getter, nullptr, default_attributes);

    define_native_accessor(realm, "userAgent", user_agent_getter, nullptr, default_attributes);

    define_native_accessor(realm, "vendor", vendor_getter, nullptr, default_attributes);

    define_native_accessor(realm, "vendorSub", vendor_sub_getter, nullptr, default_attributes);

    define_native_accessor(realm, "onLine", on_line_getter, nullptr, default_attributes);

    define_native_accessor(realm, "storage", storage_getter, nullptr, default_attributes);

    define_native_accessor(realm, "language", language_getter, nullptr, default_attributes);

    define_native_accessor(realm, "languages", languages_getter, nullptr, default_attributes);

    define_native_accessor(realm, "hardwareConcurrency", hardware_concurrency_getter, nullptr, default_attributes);

    define_native_accessor(realm, "deviceMemory", device_memory_getter, nullptr, default_attributes);

    define_direct_property(vm.well_known_symbol_to_string_tag(), JS::PrimitiveString::create(vm, "WorkerNavigator"_string), JS::Attribute::Configurable);

    Base::initialize(realm);

}

[[maybe_unused]] static JS::ThrowCompletionOr<HTML::WorkerNavigator*> impl_from(JS::VM& vm)
{
    auto this_value = vm.this_value();
    JS::Object* this_object = nullptr;
    if (this_value.is_nullish())
        this_object = &vm.current_realm()->global_object();
    else
        this_object = TRY(this_value.to_object(vm));

    if (!is<HTML::WorkerNavigator>(this_object))
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "WorkerNavigator");
    return static_cast<HTML::WorkerNavigator*>(this_object);
}

JS_DEFINE_NATIVE_FUNCTION(WorkerNavigatorPrototype::media_capabilities_getter)
{
    WebIDL::log_trace(vm, "WorkerNavigatorPrototype::media_capabilities_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->media_capabilities(); }));

    return &const_cast<MediaCapabilities&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerNavigatorPrototype::service_worker_getter)
{
    WebIDL::log_trace(vm, "WorkerNavigatorPrototype::service_worker_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->service_worker(); }));

    return &const_cast<ServiceWorkerContainer&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerNavigatorPrototype::app_code_name_getter)
{
    WebIDL::log_trace(vm, "WorkerNavigatorPrototype::app_code_name_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->app_code_name(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerNavigatorPrototype::app_name_getter)
{
    WebIDL::log_trace(vm, "WorkerNavigatorPrototype::app_name_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->app_name(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerNavigatorPrototype::app_version_getter)
{
    WebIDL::log_trace(vm, "WorkerNavigatorPrototype::app_version_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->app_version(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerNavigatorPrototype::platform_getter)
{
    WebIDL::log_trace(vm, "WorkerNavigatorPrototype::platform_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->platform(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerNavigatorPrototype::product_getter)
{
    WebIDL::log_trace(vm, "WorkerNavigatorPrototype::product_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->product(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerNavigatorPrototype::product_sub_getter)
{
    WebIDL::log_trace(vm, "WorkerNavigatorPrototype::product_sub_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->product_sub(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerNavigatorPrototype::user_agent_getter)
{
    WebIDL::log_trace(vm, "WorkerNavigatorPrototype::user_agent_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->user_agent(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerNavigatorPrototype::vendor_getter)
{
    WebIDL::log_trace(vm, "WorkerNavigatorPrototype::vendor_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->vendor(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerNavigatorPrototype::vendor_sub_getter)
{
    WebIDL::log_trace(vm, "WorkerNavigatorPrototype::vendor_sub_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->vendor_sub(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerNavigatorPrototype::on_line_getter)
{
    WebIDL::log_trace(vm, "WorkerNavigatorPrototype::on_line_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->on_line(); }));

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerNavigatorPrototype::storage_getter)
{
    WebIDL::log_trace(vm, "WorkerNavigatorPrototype::storage_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->storage(); }));

    return &const_cast<StorageManager&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerNavigatorPrototype::language_getter)
{
    WebIDL::log_trace(vm, "WorkerNavigatorPrototype::language_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->language(); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(WorkerNavigatorPrototype::languages_getter)
{
    WebIDL::log_trace(vm, "WorkerNavigatorPrototype::languages_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->languages(); }));

    auto new_array0 = MUST(JS::Array::create(realm, 0));

    for (size_t i0 = 0; i0 < retval.size(); ++i0) {
        auto& element0 = retval.at(i0);

    auto wrapped_element0 = JS::PrimitiveString::create(vm, element0);

        auto property_index0 = JS::PropertyKey { i0 };
        MUST(new_array0->create_data_property(property_index0, wrapped_element0));
    }

    return new_array0;

}

JS_DEFINE_NATIVE_FUNCTION(WorkerNavigatorPrototype::hardware_concurrency_getter)
{
    WebIDL::log_trace(vm, "WorkerNavigatorPrototype::hardware_concurrency_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->hardware_concurrency(); }));

    return JS::Value(static_cast<double>(retval));

}

JS_DEFINE_NATIVE_FUNCTION(WorkerNavigatorPrototype::device_memory_getter)
{
    WebIDL::log_trace(vm, "WorkerNavigatorPrototype::device_memory_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->device_memory(); }));

    return JS::Value(retval);

}

} // namespace Web::Bindings
