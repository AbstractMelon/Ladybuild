
#pragma once

#include <LibJS/Forward.h>

namespace Web::Bindings {

void add_shadow_realm_exposed_interfaces(JS::Object&);

}

