
#pragma once

#include <LibJS/Runtime/Object.h>

namespace Web::Bindings {

class SVGMaskElementPrototype : public JS::Object {
    JS_OBJECT(SVGMaskElementPrototype, JS::Object);
    GC_DECLARE_ALLOCATOR(SVGMaskElementPrototype);
public:
    explicit SVGMaskElementPrototype(JS::Realm&);
    virtual void initialize(JS::Realm&) override;
    virtual ~SVGMaskElementPrototype() override;
private:


};


} // namespace Web::Bindings
    