
#include <AK/Function.h>
#include <LibIDL/Types.h>
#include <LibJS/Runtime/Array.h>
#include <LibJS/Runtime/ArrayBuffer.h>
#include <LibJS/Runtime/DataView.h>
#include <LibJS/Runtime/Error.h>
#include <LibJS/Runtime/FunctionObject.h>
#include <LibJS/Runtime/GlobalObject.h>
#include <LibJS/Runtime/Iterator.h>
#include <LibJS/Runtime/PromiseConstructor.h>
#include <LibJS/Runtime/TypedArray.h>
#include <LibJS/Runtime/Value.h>
#include <LibJS/Runtime/ValueInlines.h>
#include <LibURL/Origin.h>
#include <LibWeb/Bindings/InternalsPrototype.h>
#include <LibWeb/Bindings/ExceptionOrUtils.h>
#include <LibWeb/Bindings/Intrinsics.h>
#include <LibWeb/DOM/Element.h>
#include <LibWeb/DOM/Event.h>
#include <LibWeb/DOM/IDLEventListener.h>
#include <LibWeb/DOM/NodeFilter.h>
#include <LibWeb/DOM/Range.h>
#include <LibWeb/HTML/Numbers.h>
#include <LibWeb/HTML/Scripting/Agent.h>
#include <LibWeb/HTML/Scripting/Environments.h>
#include <LibWeb/HTML/Window.h>
#include <LibWeb/HTML/WindowProxy.h>
#include <LibWeb/Infra/Strings.h>
#include <LibWeb/WebIDL/AbstractOperations.h>
#include <LibWeb/WebIDL/Buffers.h>
#include <LibWeb/WebIDL/OverloadResolution.h>
#include <LibWeb/WebIDL/Promise.h>
#include <LibWeb/WebIDL/Tracing.h>
#include <LibWeb/WebIDL/Types.h>

#if __has_include(<LibWeb/Bindings/ObjectPrototype.h>)
#    include <LibWeb/Bindings/ObjectPrototype.h>
#endif


#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Internals/Internals.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/EventTarget.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Internals/InternalAnimationTimeline.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/AbortSignal.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/DOMStringMap.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/ElementInternals.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Element.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Animations/AnimationTimeline.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/CSSStyleDeclaration.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/ShadowRoot.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Attr.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/DOMTokenList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/NamedNodeMap.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Node.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/NodeList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMRect.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMRectList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLSlotElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Window.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Event.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/DocumentFragment.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Animations/Animation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Animations/KeyframeEffect.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Document.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/HTMLCollection.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMRectReadOnly.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Text.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/MediaQueryList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/Screen.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/VisualViewport.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/CustomElements/CustomElementRegistry.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/History.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Navigation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Navigator.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/StyleSheetList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Animations/AnimationEffect.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Animations/DocumentTimeline.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/FontFaceSet.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/CDATASection.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Comment.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/DOMImplementation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/DocumentType.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/NodeFilter.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/NodeIterator.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/ProcessingInstruction.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/Range.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/TreeWalker.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLAllCollection.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLHeadElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLScriptElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Location.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Selection/Selection.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/CharacterData.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/ScreenOrientation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/NavigationHistoryEntry.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/NavigationTransition.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Clipboard/Clipboard.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CredentialManagement/CredentialsContainer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/MimeTypeArray.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/PluginArray.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/UserActivation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/MediaCapabilitiesAPI/MediaCapabilities.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/ServiceWorker/ServiceWorkerContainer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/MessagePort.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Storage.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Crypto/Crypto.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Fetch/Request.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Fetch/Response.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HighResolutionTime/Performance.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/ImageBitmap.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/IndexedDB/IDBFactory.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/RequestIdleCallback/IdleDeadline.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/CSSStyleSheet.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/FontFace.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/XMLDocument.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOM/AbstractRange.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Scripting/Fetching.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/NavigationType.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CredentialManagement/Credential.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CredentialManagement/FederatedCredential.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CredentialManagement/PasswordCredential.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/MimeType.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Plugin.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/EncryptedMediaExtensions/EncryptedMediaExtensions.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Worker.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/ServiceWorker/ServiceWorkerRegistration.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/StorageAPI/StorageManager.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Crypto/SubtleCrypto.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Fetch/Headers.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/NavigationTiming/PerformanceNavigation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/NavigationTiming/PerformanceTiming.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/PerformanceTimeline/PerformanceEntry.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/UserTiming/PerformanceMark.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/UserTiming/PerformanceMeasure.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/FileAPI/Blob.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/ImageData.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/CanvasRenderingContext2D.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/CSSRule.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/CSSRuleList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/MediaList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/CSS/StyleSheet.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/ReadableStream.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/DOMURL/URLSearchParams.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/XHR/FormData.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/ServiceWorker/ServiceWorker.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Crypto/CryptoKey.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLCanvasElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Canvas/CanvasDrawPath.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Canvas/CanvasTextDrawingStyles.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLImageElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLVideoElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGImageElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/ReadableStreamBYOBReader.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/ReadableStreamDefaultReader.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/WritableStream.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/FileAPI/File.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLRenderingContext.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGL2RenderingContext.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/Path2D.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/CanvasGradient.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/CanvasPattern.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMPointReadOnly.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/TextMetrics.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMMatrix.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/HTMLMediaElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGGraphicsElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Streams/WritableStreamDefaultWriter.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMMatrixReadOnly.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/Geometry/DOMPoint.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/AudioTrackList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/MediaError.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/TextTrack.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/TextTrackList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/TimeRanges.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/VideoTrackList.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGAnimatedString.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLActiveInfo.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLBuffer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLFramebuffer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLObject.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLProgram.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLRenderbuffer.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLShader.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLShaderPrecisionFormat.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLTexture.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLUniformLocation.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLQuery.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLSampler.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLSync.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLTransformFeedback.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/WebGL/WebGLVertexArrayObject.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/AudioTrack.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/HTML/VideoTrack.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGSVGElement.h>

#include </run/media/kyles/Storage/Important/Projects/LadyBuild/ladybird/Libraries/LibWeb/SVG/SVGAnimatedRect.h>

// FIXME: This is a total hack until we can figure out the namespace for a given type somehow.
using namespace Web::Animations;
using namespace Web::Clipboard;
using namespace Web::CredentialManagement;
using namespace Web::Crypto;
using namespace Web::CSS;
using namespace Web::DOM;
using namespace Web::DOMURL;
using namespace Web::Encoding;
using namespace Web::EntriesAPI;
using namespace Web::EventTiming;
using namespace Web::Fetch;
using namespace Web::FileAPI;
using namespace Web::Geometry;
using namespace Web::HighResolutionTime;
using namespace Web::HTML;
using namespace Web::IndexedDB;
using namespace Web::Internals;
using namespace Web::IntersectionObserver;
using namespace Web::MediaCapabilitiesAPI;
using namespace Web::MediaSourceExtensions;
using namespace Web::NavigationTiming;
using namespace Web::PerformanceTimeline;
using namespace Web::RequestIdleCallback;
using namespace Web::ResizeObserver;
using namespace Web::Selection;
using namespace Web::ServiceWorker;
using namespace Web::StorageAPI;
using namespace Web::Streams;
using namespace Web::SVG;
using namespace Web::UIEvents;
using namespace Web::URLPattern;
using namespace Web::UserTiming;
using namespace Web::WebAssembly;
using namespace Web::WebAudio;
using namespace Web::WebGL;
using namespace Web::WebGL::Extensions;
using namespace Web::WebIDL;
using namespace Web::WebVTT;
using namespace Web::XHR;

namespace Web::Bindings {

GC_DEFINE_ALLOCATOR(InternalsPrototype);

InternalsPrototype::InternalsPrototype([[maybe_unused]] JS::Realm& realm)
    : Object(ConstructWithPrototypeTag::Tag, realm.intrinsics().object_prototype())

{
}

InternalsPrototype::~InternalsPrototype()
{
}

void InternalsPrototype::initialize(JS::Realm& realm)
{


    [[maybe_unused]] auto& vm = realm.vm();
    [[maybe_unused]] u8 default_attributes = JS::Attribute::Enumerable | JS::Attribute::Configurable | JS::Attribute::Writable;



    set_prototype(realm.intrinsics().object_prototype());


    define_native_accessor(realm, "headless", headless_getter, nullptr, default_attributes);

    auto constant_MOD_NONE_value = JS::Value(static_cast<WebIDL::UnsignedShort>(0));

    define_direct_property("MOD_NONE", constant_MOD_NONE_value, JS::Attribute::Enumerable);

    auto constant_MOD_ALT_value = JS::Value(static_cast<WebIDL::UnsignedShort>(1));

    define_direct_property("MOD_ALT", constant_MOD_ALT_value, JS::Attribute::Enumerable);

    auto constant_MOD_CTRL_value = JS::Value(static_cast<WebIDL::UnsignedShort>(2));

    define_direct_property("MOD_CTRL", constant_MOD_CTRL_value, JS::Attribute::Enumerable);

    auto constant_MOD_SHIFT_value = JS::Value(static_cast<WebIDL::UnsignedShort>(4));

    define_direct_property("MOD_SHIFT", constant_MOD_SHIFT_value, JS::Attribute::Enumerable);

    auto constant_MOD_SUPER_value = JS::Value(static_cast<WebIDL::UnsignedShort>(8));

    define_direct_property("MOD_SUPER", constant_MOD_SUPER_value, JS::Attribute::Enumerable);

    auto constant_MOD_KEYPAD_value = JS::Value(static_cast<WebIDL::UnsignedShort>(16));

    define_direct_property("MOD_KEYPAD", constant_MOD_KEYPAD_value, JS::Attribute::Enumerable);

    define_native_function(realm, "movePointerTo", move_pointer_to, 2, default_attributes);

    define_native_function(realm, "click", click, 2, default_attributes);

    define_native_function(realm, "sendText", send_text, 2, default_attributes);

    define_native_function(realm, "getEchoServerPort", get_echo_server_port, 0, default_attributes);

    define_native_function(realm, "simulateDragStart", simulate_drag_start, 4, default_attributes);

    define_native_function(realm, "doubleclick", doubleclick, 2, default_attributes);

    define_native_function(realm, "commitText", commit_text, 0, default_attributes);

    define_native_function(realm, "createInternalAnimationTimeline", create_internal_animation_timeline, 0, default_attributes);

    define_native_function(realm, "simulateDragMove", simulate_drag_move, 2, default_attributes);

    define_native_function(realm, "gc", gc, 0, default_attributes);

    define_native_function(realm, "hitTest", hit_test, 2, default_attributes);

    define_native_function(realm, "wheel", wheel, 4, default_attributes);

    define_native_function(realm, "expireCookiesWithTimeOffset", expire_cookies_with_time_offset, 1, default_attributes);

    define_native_function(realm, "signalTextTestIsDone", signal_text_test_is_done, 1, default_attributes);

    define_native_function(realm, "simulateDrop", simulate_drop, 2, default_attributes);

    define_native_function(realm, "setBrowserZoom", set_browser_zoom, 1, default_attributes);

    define_native_function(realm, "spoofCurrentURL", spoof_current_url, 1, default_attributes);

    define_native_function(realm, "mouseDown", mouse_down, 2, default_attributes);

    define_native_function(realm, "dispatchUserActivatedEvent", dispatch_user_activated_event, 2, default_attributes);

    define_native_function(realm, "getComputedLabel", get_computed_label, 1, default_attributes);

    define_native_function(realm, "middleClick", middle_click, 2, default_attributes);

    define_native_function(realm, "setTestTimeout", set_test_timeout, 1, default_attributes);

    define_native_function(realm, "sendKey", send_key, 2, default_attributes);

    define_native_function(realm, "enableCookiesOnFileDomains", enable_cookies_on_file_domains, 0, default_attributes);

    define_native_function(realm, "getComputedRole", get_computed_role, 1, default_attributes);

    define_direct_property(vm.well_known_symbol_to_string_tag(), JS::PrimitiveString::create(vm, "Internals"_string), JS::Attribute::Configurable);

    Base::initialize(realm);

}

[[maybe_unused]] static JS::ThrowCompletionOr<Internals::Internals*> impl_from(JS::VM& vm)
{
    auto this_value = vm.this_value();
    JS::Object* this_object = nullptr;
    if (this_value.is_nullish())
        this_object = &vm.current_realm()->global_object();
    else
        this_object = TRY(this_value.to_object(vm));

    if (!is<Internals::Internals>(this_object))
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "Internals");
    return static_cast<Internals::Internals*>(this_object);
}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::headless_getter)
{
    WebIDL::log_trace(vm, "InternalsPrototype::headless_getter");
    [[maybe_unused]] auto& realm = *vm.current_realm();
    [[maybe_unused]] auto* impl = TRY(impl_from(vm));

    auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->headless(); }));

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::signal_text_test_is_done)
{
    WebIDL::log_trace(vm, "InternalsPrototype::signal_text_test_is_done");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "signalTextTestIsDone");

    auto arg0 = vm.argument(0);

    String text;
    if (!false || !arg0.is_null()) {
        text = TRY(WebIDL::to_string(vm, arg0));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->signal_text_test_is_done(text); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::set_test_timeout)
{
    WebIDL::log_trace(vm, "InternalsPrototype::set_test_timeout");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "setTestTimeout");

    auto arg0 = vm.argument(0);

    double milliseconds = TRY(arg0.to_double(vm));

    if (isinf(milliseconds) || isnan(milliseconds)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "milliseconds");
    }
    
    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->set_test_timeout(milliseconds); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::gc)
{
    WebIDL::log_trace(vm, "InternalsPrototype::gc");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->gc(); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::hit_test)
{
    WebIDL::log_trace(vm, "InternalsPrototype::hit_test");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 2)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "hitTest", "2");

    auto arg0 = vm.argument(0);

    double x = TRY(arg0.to_double(vm));

    if (isinf(x) || isnan(x)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "x");
    }
    
    auto arg1 = vm.argument(1);

    double y = TRY(arg1.to_double(vm));

    if (isinf(y) || isnan(y)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "y");
    }
    
    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->hit_test(x, y); }));

    return JS::Value(const_cast<JS::Object*>(retval));

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::send_text)
{
    WebIDL::log_trace(vm, "InternalsPrototype::send_text");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 2)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "sendText", "2");

    auto arg0 = vm.argument(0);

    if (!arg0.is_object() || !is<HTMLElement>(arg0.as_object()))
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "HTMLElement");

    auto& target = static_cast<HTMLElement&>(arg0.as_object());

    auto arg1 = vm.argument(1);

    String text;
    if (!false || !arg1.is_null()) {
        text = TRY(WebIDL::to_string(vm, arg1));
    }

    auto arg2 = vm.argument(2);

    WebIDL::UnsignedShort modifiers;

    if (!arg2.is_undefined())

    modifiers = TRY(WebIDL::convert_to_int<WebIDL::UnsignedShort>(vm, arg2, WebIDL::EnforceRange::No, WebIDL::Clamp::No));

    else
        modifiers = static_cast<WebIDL::UnsignedShort>(0);

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->send_text(target, text, modifiers); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::send_key)
{
    WebIDL::log_trace(vm, "InternalsPrototype::send_key");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 2)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "sendKey", "2");

    auto arg0 = vm.argument(0);

    if (!arg0.is_object() || !is<HTMLElement>(arg0.as_object()))
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "HTMLElement");

    auto& target = static_cast<HTMLElement&>(arg0.as_object());

    auto arg1 = vm.argument(1);

    String key_name;
    if (!false || !arg1.is_null()) {
        key_name = TRY(WebIDL::to_string(vm, arg1));
    }

    auto arg2 = vm.argument(2);

    WebIDL::UnsignedShort modifiers;

    if (!arg2.is_undefined())

    modifiers = TRY(WebIDL::convert_to_int<WebIDL::UnsignedShort>(vm, arg2, WebIDL::EnforceRange::No, WebIDL::Clamp::No));

    else
        modifiers = static_cast<WebIDL::UnsignedShort>(0);

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->send_key(target, key_name, modifiers); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::commit_text)
{
    WebIDL::log_trace(vm, "InternalsPrototype::commit_text");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->commit_text(); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::click)
{
    WebIDL::log_trace(vm, "InternalsPrototype::click");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 2)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "click", "2");

    auto arg0 = vm.argument(0);

    double x = TRY(arg0.to_double(vm));

    if (isinf(x) || isnan(x)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "x");
    }
    
    auto arg1 = vm.argument(1);

    double y = TRY(arg1.to_double(vm));

    if (isinf(y) || isnan(y)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "y");
    }
    
    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->click(x, y); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::doubleclick)
{
    WebIDL::log_trace(vm, "InternalsPrototype::doubleclick");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 2)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "doubleclick", "2");

    auto arg0 = vm.argument(0);

    double x = TRY(arg0.to_double(vm));

    if (isinf(x) || isnan(x)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "x");
    }
    
    auto arg1 = vm.argument(1);

    double y = TRY(arg1.to_double(vm));

    if (isinf(y) || isnan(y)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "y");
    }
    
    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->doubleclick(x, y); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::middle_click)
{
    WebIDL::log_trace(vm, "InternalsPrototype::middle_click");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 2)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "middleClick", "2");

    auto arg0 = vm.argument(0);

    double x = TRY(arg0.to_double(vm));

    if (isinf(x) || isnan(x)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "x");
    }
    
    auto arg1 = vm.argument(1);

    double y = TRY(arg1.to_double(vm));

    if (isinf(y) || isnan(y)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "y");
    }
    
    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->middle_click(x, y); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::mouse_down)
{
    WebIDL::log_trace(vm, "InternalsPrototype::mouse_down");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 2)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "mouseDown", "2");

    auto arg0 = vm.argument(0);

    double x = TRY(arg0.to_double(vm));

    if (isinf(x) || isnan(x)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "x");
    }
    
    auto arg1 = vm.argument(1);

    double y = TRY(arg1.to_double(vm));

    if (isinf(y) || isnan(y)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "y");
    }
    
    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->mouse_down(x, y); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::move_pointer_to)
{
    WebIDL::log_trace(vm, "InternalsPrototype::move_pointer_to");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 2)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "movePointerTo", "2");

    auto arg0 = vm.argument(0);

    double x = TRY(arg0.to_double(vm));

    if (isinf(x) || isnan(x)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "x");
    }
    
    auto arg1 = vm.argument(1);

    double y = TRY(arg1.to_double(vm));

    if (isinf(y) || isnan(y)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "y");
    }
    
    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->move_pointer_to(x, y); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::wheel)
{
    WebIDL::log_trace(vm, "InternalsPrototype::wheel");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 4)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "wheel", "4");

    auto arg0 = vm.argument(0);

    double x = TRY(arg0.to_double(vm));

    if (isinf(x) || isnan(x)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "x");
    }
    
    auto arg1 = vm.argument(1);

    double y = TRY(arg1.to_double(vm));

    if (isinf(y) || isnan(y)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "y");
    }
    
    auto arg2 = vm.argument(2);

    double delta_x = TRY(arg2.to_double(vm));

    if (isinf(delta_x) || isnan(delta_x)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "deltaX");
    }
    
    auto arg3 = vm.argument(3);

    double delta_y = TRY(arg3.to_double(vm));

    if (isinf(delta_y) || isnan(delta_y)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "deltaY");
    }
    
    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->wheel(x, y, delta_x, delta_y); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::dispatch_user_activated_event)
{
    WebIDL::log_trace(vm, "InternalsPrototype::dispatch_user_activated_event");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 2)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "dispatchUserActivatedEvent", "2");

    auto arg0 = vm.argument(0);

    if (!arg0.is_object() || !is<EventTarget>(arg0.as_object()))
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "EventTarget");

    auto& target = static_cast<EventTarget&>(arg0.as_object());

    auto arg1 = vm.argument(1);

    if (!arg1.is_object() || !is<Event>(arg1.as_object()))
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "Event");

    auto& event = static_cast<Event&>(arg1.as_object());

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->dispatch_user_activated_event(target, event); }));

    return JS::Value(retval);

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::spoof_current_url)
{
    WebIDL::log_trace(vm, "InternalsPrototype::spoof_current_url");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "spoofCurrentURL");

    auto arg0 = vm.argument(0);

    String url;
    if (!false || !arg0.is_null()) {
        url = TRY(WebIDL::to_usv_string(vm, arg0));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->spoof_current_url(url); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::create_internal_animation_timeline)
{
    WebIDL::log_trace(vm, "InternalsPrototype::create_internal_animation_timeline");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->create_internal_animation_timeline(); }));

    return &const_cast<InternalAnimationTimeline&>(*retval);

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::simulate_drag_start)
{
    WebIDL::log_trace(vm, "InternalsPrototype::simulate_drag_start");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 4)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "simulateDragStart", "4");

    auto arg0 = vm.argument(0);

    double x = TRY(arg0.to_double(vm));

    if (isinf(x) || isnan(x)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "x");
    }
    
    auto arg1 = vm.argument(1);

    double y = TRY(arg1.to_double(vm));

    if (isinf(y) || isnan(y)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "y");
    }
    
    auto arg2 = vm.argument(2);

    String mime_type;
    if (!false || !arg2.is_null()) {
        mime_type = TRY(WebIDL::to_string(vm, arg2));
    }

    auto arg3 = vm.argument(3);

    String contents;
    if (!false || !arg3.is_null()) {
        contents = TRY(WebIDL::to_string(vm, arg3));
    }

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->simulate_drag_start(x, y, mime_type, contents); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::simulate_drag_move)
{
    WebIDL::log_trace(vm, "InternalsPrototype::simulate_drag_move");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 2)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "simulateDragMove", "2");

    auto arg0 = vm.argument(0);

    double x = TRY(arg0.to_double(vm));

    if (isinf(x) || isnan(x)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "x");
    }
    
    auto arg1 = vm.argument(1);

    double y = TRY(arg1.to_double(vm));

    if (isinf(y) || isnan(y)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "y");
    }
    
    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->simulate_drag_move(x, y); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::simulate_drop)
{
    WebIDL::log_trace(vm, "InternalsPrototype::simulate_drop");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 2)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountMany, "simulateDrop", "2");

    auto arg0 = vm.argument(0);

    double x = TRY(arg0.to_double(vm));

    if (isinf(x) || isnan(x)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "x");
    }
    
    auto arg1 = vm.argument(1);

    double y = TRY(arg1.to_double(vm));

    if (isinf(y) || isnan(y)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "y");
    }
    
    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->simulate_drop(x, y); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::enable_cookies_on_file_domains)
{
    WebIDL::log_trace(vm, "InternalsPrototype::enable_cookies_on_file_domains");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->enable_cookies_on_file_domains(); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::expire_cookies_with_time_offset)
{
    WebIDL::log_trace(vm, "InternalsPrototype::expire_cookies_with_time_offset");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "expireCookiesWithTimeOffset");

    auto arg0 = vm.argument(0);

    WebIDL::LongLong seconds;

    seconds = TRY(WebIDL::convert_to_int<WebIDL::LongLong>(vm, arg0, WebIDL::EnforceRange::No, WebIDL::Clamp::No));

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->expire_cookies_with_time_offset(seconds); }));

    return JS::js_undefined();

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::get_computed_role)
{
    WebIDL::log_trace(vm, "InternalsPrototype::get_computed_role");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "getComputedRole");

    auto arg0 = vm.argument(0);

    if (!arg0.is_object() || !is<Element>(arg0.as_object()))
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "Element");

    auto& element = static_cast<Element&>(arg0.as_object());

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->get_computed_role(element); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::get_computed_label)
{
    WebIDL::log_trace(vm, "InternalsPrototype::get_computed_label");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "getComputedLabel");

    auto arg0 = vm.argument(0);

    if (!arg0.is_object() || !is<Element>(arg0.as_object()))
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::NotAnObjectOfType, "Element");

    auto& element = static_cast<Element&>(arg0.as_object());

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->get_computed_label(element); }));

    return JS::PrimitiveString::create(vm, retval);

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::get_echo_server_port)
{
    WebIDL::log_trace(vm, "InternalsPrototype::get_echo_server_port");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->get_echo_server_port(); }));

    return JS::Value(static_cast<WebIDL::UnsignedShort>(retval));

}

JS_DEFINE_NATIVE_FUNCTION(InternalsPrototype::set_browser_zoom)
{
    WebIDL::log_trace(vm, "InternalsPrototype::set_browser_zoom");
    [[maybe_unused]] auto& realm = *vm.current_realm();

    auto* impl = TRY(impl_from(vm));

    if (vm.argument_count() < 1)
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::BadArgCountOne, "setBrowserZoom");

    auto arg0 = vm.argument(0);

    double factor = TRY(arg0.to_double(vm));

    if (isinf(factor) || isnan(factor)) {
        return vm.throw_completion<JS::TypeError>(JS::ErrorType::InvalidRestrictedFloatingPointParameter, "factor");
    }
    
    [[maybe_unused]] auto retval = TRY(throw_dom_exception_if_needed(vm, [&] { return impl->set_browser_zoom(factor); }));

    return JS::js_undefined();

}

} // namespace Web::Bindings
