
#pragma once

#include <LibJS/Runtime/Object.h>

namespace Web::Bindings {

class SVGTitleElementPrototype : public JS::Object {
    JS_OBJECT(SVGTitleElementPrototype, JS::Object);
    GC_DECLARE_ALLOCATOR(SVGTitleElementPrototype);
public:
    explicit SVGTitleElementPrototype(JS::Realm&);
    virtual void initialize(JS::Realm&) override;
    virtual ~SVGTitleElementPrototype() override;
private:


};


} // namespace Web::Bindings
    