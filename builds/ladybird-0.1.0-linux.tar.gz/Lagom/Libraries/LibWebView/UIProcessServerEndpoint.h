#pragma once
#include <AK/Error.h>
#include <AK/MemoryStream.h>
#include <AK/OwnPtr.h>
#include <AK/Result.h>
#include <AK/Utf8View.h>
#include <LibIPC/Connection.h>
#include <LibIPC/Decoder.h>
#include <LibIPC/Encoder.h>
#include <LibIPC/File.h>
#include <LibIPC/Message.h>
#include <LibIPC/Stub.h>

#if defined(AK_COMPILER_CLANG)
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdefaulted-function-deleted"
#endif

namespace Messages::UIProcessServer {

enum class MessageID : i32 {
    CreateNewTab = 1,
    CreateNewTabResponse = 2,
    CreateNewWindow = 3,
    CreateNewWindowResponse = 4,
};

class CreateNewTabResponse final : public IPC::Message {
public:

    CreateNewTabResponse(CreateNewTabResponse const&) = default;
    CreateNewTabResponse(CreateNewTabResponse&&) = default;
    CreateNewTabResponse& operator=(CreateNewTabResponse const&) = default;
    CreateNewTabResponse() {}

    virtual ~CreateNewTabResponse() override {}

    virtual u32 endpoint_magic() const override { return 1725039581; }
    virtual i32 message_id() const override { return (int)MessageID::CreateNewTabResponse; }
    static i32 static_message_id() { return (int)MessageID::CreateNewTabResponse; }
    virtual const char* message_name() const override { return "UIProcessServer::CreateNewTabResponse"; }

    static ErrorOr<NonnullOwnPtr<CreateNewTabResponse>> decode(Stream& stream, Queue<IPC::File>& files)
    {
        IPC::Decoder decoder { stream, files };

        return make<CreateNewTabResponse>();
    }

    virtual ErrorOr<IPC::MessageBuffer> encode() const override
    {
        IPC::MessageBuffer buffer;
        IPC::Encoder stream(buffer);
        TRY(stream.encode(endpoint_magic()));
        TRY(stream.encode((int)MessageID::CreateNewTabResponse));

        return buffer;
    }

private:

};

class CreateNewTab final : public IPC::Message {
public:

   typedef class CreateNewTabResponse ResponseType;

    CreateNewTab(CreateNewTab const&) = default;
    CreateNewTab(CreateNewTab&&) = default;
    CreateNewTab& operator=(CreateNewTab const&) = default;
    CreateNewTab(Vector<ByteString> urls) : m_urls(move(urls)) {}

    template <typename WrappedReturnType>
    requires(!SameAs<WrappedReturnType, Vector<ByteString>>)
    CreateNewTab(WrappedReturnType&& value)
        : m_urls(forward<WrappedReturnType>(value))
    {
    }

    virtual ~CreateNewTab() override {}

    virtual u32 endpoint_magic() const override { return 1725039581; }
    virtual i32 message_id() const override { return (int)MessageID::CreateNewTab; }
    static i32 static_message_id() { return (int)MessageID::CreateNewTab; }
    virtual const char* message_name() const override { return "UIProcessServer::CreateNewTab"; }

    static ErrorOr<NonnullOwnPtr<CreateNewTab>> decode(Stream& stream, Queue<IPC::File>& files)
    {
        IPC::Decoder decoder { stream, files };

        auto urls = TRY((decoder.decode<Vector<ByteString>>()));

        return make<CreateNewTab>(move(urls));
    }

    virtual ErrorOr<IPC::MessageBuffer> encode() const override
    {
        IPC::MessageBuffer buffer;
        IPC::Encoder stream(buffer);
        TRY(stream.encode(endpoint_magic()));
        TRY(stream.encode((int)MessageID::CreateNewTab));

        TRY(stream.encode(m_urls));

        return buffer;
    }

    const Vector<ByteString>& urls() const { return m_urls; }
    Vector<ByteString> take_urls() { return move(m_urls); }

private:

    Vector<ByteString> m_urls;

};

class CreateNewWindowResponse final : public IPC::Message {
public:

    CreateNewWindowResponse(CreateNewWindowResponse const&) = default;
    CreateNewWindowResponse(CreateNewWindowResponse&&) = default;
    CreateNewWindowResponse& operator=(CreateNewWindowResponse const&) = default;
    CreateNewWindowResponse() {}

    virtual ~CreateNewWindowResponse() override {}

    virtual u32 endpoint_magic() const override { return 1725039581; }
    virtual i32 message_id() const override { return (int)MessageID::CreateNewWindowResponse; }
    static i32 static_message_id() { return (int)MessageID::CreateNewWindowResponse; }
    virtual const char* message_name() const override { return "UIProcessServer::CreateNewWindowResponse"; }

    static ErrorOr<NonnullOwnPtr<CreateNewWindowResponse>> decode(Stream& stream, Queue<IPC::File>& files)
    {
        IPC::Decoder decoder { stream, files };

        return make<CreateNewWindowResponse>();
    }

    virtual ErrorOr<IPC::MessageBuffer> encode() const override
    {
        IPC::MessageBuffer buffer;
        IPC::Encoder stream(buffer);
        TRY(stream.encode(endpoint_magic()));
        TRY(stream.encode((int)MessageID::CreateNewWindowResponse));

        return buffer;
    }

private:

};

class CreateNewWindow final : public IPC::Message {
public:

   typedef class CreateNewWindowResponse ResponseType;

    CreateNewWindow(CreateNewWindow const&) = default;
    CreateNewWindow(CreateNewWindow&&) = default;
    CreateNewWindow& operator=(CreateNewWindow const&) = default;
    CreateNewWindow(Vector<ByteString> urls) : m_urls(move(urls)) {}

    template <typename WrappedReturnType>
    requires(!SameAs<WrappedReturnType, Vector<ByteString>>)
    CreateNewWindow(WrappedReturnType&& value)
        : m_urls(forward<WrappedReturnType>(value))
    {
    }

    virtual ~CreateNewWindow() override {}

    virtual u32 endpoint_magic() const override { return 1725039581; }
    virtual i32 message_id() const override { return (int)MessageID::CreateNewWindow; }
    static i32 static_message_id() { return (int)MessageID::CreateNewWindow; }
    virtual const char* message_name() const override { return "UIProcessServer::CreateNewWindow"; }

    static ErrorOr<NonnullOwnPtr<CreateNewWindow>> decode(Stream& stream, Queue<IPC::File>& files)
    {
        IPC::Decoder decoder { stream, files };

        auto urls = TRY((decoder.decode<Vector<ByteString>>()));

        return make<CreateNewWindow>(move(urls));
    }

    virtual ErrorOr<IPC::MessageBuffer> encode() const override
    {
        IPC::MessageBuffer buffer;
        IPC::Encoder stream(buffer);
        TRY(stream.encode(endpoint_magic()));
        TRY(stream.encode((int)MessageID::CreateNewWindow));

        TRY(stream.encode(m_urls));

        return buffer;
    }

    const Vector<ByteString>& urls() const { return m_urls; }
    Vector<ByteString> take_urls() { return move(m_urls); }

private:

    Vector<ByteString> m_urls;

};

} // namespace Messages::UIProcessServer

template<typename LocalEndpoint, typename PeerEndpoint>
class UIProcessServerProxy {
public:
    // Used to disambiguate the constructor call.
    struct Tag { };

    UIProcessServerProxy(IPC::Connection<LocalEndpoint, PeerEndpoint>& connection, Tag)
        : m_connection(connection)
    { }

    void create_new_tab(
Vector<ByteString> urls) {
        (void) m_connection.template send_sync<Messages::UIProcessServer::CreateNewTab>(move(urls));
    }

    void async_create_new_tab(
Vector<ByteString> urls) {
        MUST(m_connection.post_message(Messages::UIProcessServer::CreateNewTab { move(urls) }));

    }

    IPC::IPCErrorOr<void> try_create_new_tab(
Vector<ByteString> urls) {
        auto result = m_connection.template send_sync_but_allow_failure<Messages::UIProcessServer::CreateNewTab>(move(urls));
        if (!result) {
            m_connection.shutdown();
            return IPC::ErrorCode::PeerDisconnected;
        }
        return { };

    }

    void create_new_window(
Vector<ByteString> urls) {
        (void) m_connection.template send_sync<Messages::UIProcessServer::CreateNewWindow>(move(urls));
    }

    void async_create_new_window(
Vector<ByteString> urls) {
        MUST(m_connection.post_message(Messages::UIProcessServer::CreateNewWindow { move(urls) }));

    }

    IPC::IPCErrorOr<void> try_create_new_window(
Vector<ByteString> urls) {
        auto result = m_connection.template send_sync_but_allow_failure<Messages::UIProcessServer::CreateNewWindow>(move(urls));
        if (!result) {
            m_connection.shutdown();
            return IPC::ErrorCode::PeerDisconnected;
        }
        return { };

    }

private:
    IPC::Connection<LocalEndpoint, PeerEndpoint>& m_connection;
};

template<typename LocalEndpoint, typename PeerEndpoint>
class UIProcessServerProxy;
class UIProcessServerStub;

class UIProcessServerEndpoint {
public:
    template<typename LocalEndpoint>
    using Proxy = UIProcessServerProxy<LocalEndpoint, UIProcessServerEndpoint>;
    using Stub = UIProcessServerStub;

    static u32 static_magic() { return 1725039581; }

    static ErrorOr<NonnullOwnPtr<IPC::Message>> decode_message(ReadonlyBytes buffer, [[maybe_unused]] Queue<IPC::File>& files)
    {
        FixedMemoryStream stream { buffer };
        auto message_endpoint_magic = TRY(stream.read_value<u32>());

        if (message_endpoint_magic != 1725039581) {
            return Error::from_string_literal("Endpoint magic number mismatch, not my message!");
        }

        auto message_id = TRY(stream.read_value<i32>());


        switch (message_id) {

        case (int)Messages::UIProcessServer::MessageID::CreateNewTab:
            return TRY(Messages::UIProcessServer::CreateNewTab::decode(stream, files));
        case (int)Messages::UIProcessServer::MessageID::CreateNewTabResponse:
            return TRY(Messages::UIProcessServer::CreateNewTabResponse::decode(stream, files));
        case (int)Messages::UIProcessServer::MessageID::CreateNewWindow:
            return TRY(Messages::UIProcessServer::CreateNewWindow::decode(stream, files));
        case (int)Messages::UIProcessServer::MessageID::CreateNewWindowResponse:
            return TRY(Messages::UIProcessServer::CreateNewWindowResponse::decode(stream, files));
        default:
            return Error::from_string_literal("Failed to decode UIProcessServer message");
        }

        VERIFY_NOT_REACHED();
    }

};

class UIProcessServerStub : public IPC::Stub {
public:
    UIProcessServerStub() { }
    virtual ~UIProcessServerStub() override { }

    virtual u32 magic() const override { return 1725039581; }
    virtual ByteString name() const override { return "UIProcessServer"; }

    virtual ErrorOr<OwnPtr<IPC::MessageBuffer>> handle(const IPC::Message& message) override
    {
        switch (message.message_id()) {

        case (int)Messages::UIProcessServer::MessageID::CreateNewTab: {

            [[maybe_unused]] auto& request = static_cast<const Messages::UIProcessServer::CreateNewTab&>(message);
            create_new_tab(request.urls());
            auto response = Messages::UIProcessServer::CreateNewTabResponse { };
            return make<IPC::MessageBuffer>(TRY(response.encode()));

        }

        case (int)Messages::UIProcessServer::MessageID::CreateNewWindow: {

            [[maybe_unused]] auto& request = static_cast<const Messages::UIProcessServer::CreateNewWindow&>(message);
            create_new_window(request.urls());
            auto response = Messages::UIProcessServer::CreateNewWindowResponse { };
            return make<IPC::MessageBuffer>(TRY(response.encode()));

        }

        default:
            return Error::from_string_literal("Unknown message ID for UIProcessServer endpoint");
        }
    }

    virtual void create_new_tab(
[[maybe_unused]] Vector<ByteString> const& urls) = 0;

    virtual void create_new_window(
[[maybe_unused]] Vector<ByteString> const& urls) = 0;

private:
};

#if defined(AK_COMPILER_CLANG)
#pragma clang diagnostic pop
#endif
